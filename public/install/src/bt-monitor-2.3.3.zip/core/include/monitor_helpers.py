# -*- encoding: utf-8 -*-
#
# 云监控工具模块
# @author Zhj<2022-07-05>

import core.include.monitor_events as monitor_events
import core.include.monitor_db_manager as monitor_db_manager
from core.include.monitor_task import MonitorTask, MonitorTaskQueue
from core.include.basic_monitor import BasicMonitor
from core.include.warning import Warning as WarningClass

# monitor_events = public.import_via_loader('{}/core/include/monitor_events.py'.format(public.get_panel_path()))
# monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
# monitor_task_obj = public.import_via_loader('{}/core/include/monitor_task.py'.format(public.get_panel_path()))
# MonitorTaskQueue = monitor_task_obj.MonitorTaskQueue
# MonitorTask = monitor_task_obj.MonitorTask

# 被控在线状态更新队列
lower_detector_status_update_queue = MonitorTaskQueue().blocking().run(16)

# 云监控任务队列
monitor_task_queue = MonitorTaskQueue().run()

# 云监控消息推送队列
message_push_queue = MonitorTaskQueue().run()

# 云监控异步调用被控队列
async_call_queue = MonitorTaskQueue().run()

# BasicMonitor = public.import_via_loader('{}/core/include/basic_monitor.py'.format(public.get_panel_path())).BasicMonitor
# WarningClass = public.import_via_loader('{}/core/include/warning.py'.format(public.get_panel_path())).Warning

# 监控数据收集类
basic_monitor_obj = BasicMonitor()

# 云监控告警对象
warning_obj = WarningClass()

counters = {
    'connect': [],
    'systeminfo': [],
    'process': [],
    'firewall_info': [],
    'serverport': [],
    'loganalysis': [],
    'networktraffic': [],
    'sshandsoft': [],
    'raidcheck': [],
    'agentinfo': [],
    'nginxstats': [],
    'vul_scan': [],
    'intrusion_detection': [],
}
