# encoding: utf-8
from audioop import add
import core.include.public as public
import re, json, copy, os, time
import queue
from core.include.monitor_exceptions import BtMonitorException
import core.include.monitor_db_manager as monitor_db_manager
from core.include.basic_monitor import BasicMonitor
from modules.msgModule.main import main as MsgModule

# BasicMonitor = public.import_via_loader('{}/core/include/basic_monitor.py'.format(public.get_panel_path())).BasicMonitor
# MsgModule = public.import_via_loader('{}/modules/msgModule/main.py'.format(public.get_panel_path())).main

# 告警推送方式
_push_methods = {
    "dingding": "钉钉",
    "mail": "邮箱",
    "sms": "短信",
    "weixin": "企业微信",
    "feishu": "飞书",
}

# 告警推送方式排列顺序
_push_methods_arrange = ("mail", "dingding", "weixin", "feishu")

# 监控方式描述
_watch_type_describes = {
    "1": "监控百分比(高于)",
    "2": "监控百分比(低于)",
    "3": "监控数值(高于)",
    "4": "监控数值(低于)",
    "5": "监控动作"
}

# 监控方式描述V2
_watch_type_describes_v2 = {
    "1": "大于",
    "2": "小于",
    "3": "大于",
    "4": "小于",
    "5": "匹配"
}

## 告警校验规则与告警处理函数定义
_internal_settings = {
    "safety": {
        "__name": "安全",
        "bug": {
            "__name": "漏洞扫描",
            "percent": {
                "__name": "扫描结果",
                "handler": "core.include.warning_functions::handle_safety_bug",
                "watch_types": [5],
                "rule": "status_error"
            }
        },
        "mining": {
            "__name": "挖矿木马",
            "percent": {
                "__name": "扫描结果",
                "handler": "core.include.warning_functions::handle_safety_mining",
                "watch_types": [5],
                "rule": "status_error"
            }
        },
        "sacn": {
            "__name": "病毒扫描",
            "percent": {
                "__name": "扫描结果",
                "handler": "core.include.warning_functions::handle_safety_scan",
                "watch_types": [5],
                "rule": "status_error"
            }
        },
        "port": {
            "__name": "端口",
            "percent": {
                "__name": "端口检测",
                "handler": "core.include.warning_functions::handle_port_change",
                "watch_types": [5],
                "rule": "port_change"
            },
            # "connection": {
            #     "__name": "端口连接测试",
            #     "handler": "core.include.warning_functions::handle_port_connection",
            #     "watch_types": [5],
            #     "rule": "success_or_fail"
            # },
            # "faileds_in_last_hour": {
            #     "__name": "最近1小时内端口连接失败次数",
            #     "handler": "core.include.warning_functions::handle_port_faileds_in_last_hour",
            #     "watch_types": [3, 4],
            #     "rule": "integer"
            # },
            # "success_percent": {
            #     "__name": "端口连接成功率",
            #     "handler": "core.include.warning_functions::handle_port_success_percent",
            #     "watch_types": [1, 2],
            #     "rule": "percent"
            # },
        },
        "firewalld": {
            "__name": "防火墙",
            "percent": {
                "__name": "防火墙规则",
                "handler": "core.include.warning_functions::handle_firewall_rule_change",
                "watch_types": [5],
                "rule": "firewall_rule_change"
            }
        },
    },
    "resource": {
        "__name": "资源",
        "cpu": {
            "__name": "CPU",
            "percent": {
                "__name": "CPU使用率",
                "handler": "core.include.warning_functions::handle_resouce_cpu_percent",
                "watch_types": [1, 2],
                "rule": "percent"
            }
        },
        "mem": {
            "__name": "内存",
            "percent": {
                "__name": "内存占用率",
                "handler": "core.include.warning_functions::handle_resource_mem_percent",
                "watch_types": [1, 2],
                "rule": "percent"
            },
            "used": {
                "__name": "已占用内存",
                "handler": "core.include.warning_functions::handle_resouce_mem_used",
                "watch_types": [3, 4],
                "rule": "literal"
            }
        },
        "swap": {
            "__name": "swap",
            "percent": {
                "__name": "swap占用率",
                "handler": "core.include.warning_functions::handle_resource_swap_percent",
                "watch_types": [1, 2],
                "rule": "percent"
            }
        },
        "disk_[]": {
            "__name": "磁盘-[]",
            "used_percent": {
                "__name": "磁盘占用率",
                "handler": "core.include.warning_functions::handle_resource_disk_used_percent",
                "watch_types": [1, 2],
                "rule": "percent"
            },
            "inodes_used_percent": {
                "__name": "inode占用率",
                "handler": "core.include.warning_functions::handle_resource_disk_inodes_used_percent",
                "watch_types": [1, 2],
                "rule": "percent"
            },
            "io_percent": {
                "__name": "磁盘IO耗时占比",
                "handler": "core.include.warning_functions::handle_resource_disk_io_percent",
                "watch_types": [1, 2],
                "rule": "percent"
            },
            "read_per_second": {
                "__name": "磁盘读取速率",
                "handler": "core.include.warning_functions::handle_resource_disk_read_per_second",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "write_per_second": {
                "__name": "磁盘写入速率",
                "handler": "core.include.warning_functions::handle_resource_disk_write_per_second",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "raid_check": {
                "__name": "磁盘阵列硬盘离线检测",
                "handler": "core.include.warning_functions::handle_raid_check",
                "watch_types": [5],
                "rule": "on_off"
            }
        },
        "net_[]": {
            "__name": "网卡-[]",
            "sent": {
                "__name": "上传总流量",
                "handler": "core.include.warning_functions::handle_resource_net_sent",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "recv": {
                "__name": "下载总流量",
                "handler": "core.include.warning_functions::handle_resource_net_recv",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "sent_per_second": {
                "__name": "上传速率",
                "handler": "core.include.warning_functions::handle_resource_net_sent_per_second",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "recv_per_second": {
                "__name": "下载速率",
                "handler": "core.include.warning_functions::handle_resource_net_recv_per_second",
                "watch_types": [3, 4],
                "rule": "literal"
            }
        }
    },
    "service": {
        "__name": "常用服务",
        "proc_[]": {
            "__name": "进程-[]",
            "cpu.percent": {
                "__name": "CPU使用率",
                "handler": "core.include.warning_functions::handle_service_proc_cpu_percent",
                "watch_types": [1, 2],
                "rule": "percent"
            },
            "mem.percent": {
                "__name": "内存占用率",
                "handler": "core.include.warning_functions::handle_service_proc_mem_percent",
                "watch_types": [1, 2],
                "rule": "percent"
            },
            "disk.read_per_second": {
                "__name": "磁盘读取速率",
                "handler": "core.include.warning_functions::handle_service_proc_disk_read_per_second",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "disk.write_per_second": {
                "__name": "磁盘写入速率",
                "handler": "core.include.warning_functions::handle_service_proc_disk_write_per_second",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "net.sent_per_second": {
                "__name": "网络上传速率",
                "handler": "core.include.warning_functions::handle_service_proc_net_sent_per_second",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "net.recv_per_second": {
                "__name": "网络下载速率",
                "handler": "core.include.warning_functions::handle_service_proc_net_recv_per_second",
                "watch_types": [3, 4],
                "rule": "literal"
            },
            "status": {
                "__name": "进程状态",
                "handler": "core.include.warning_functions::handle_service_proc_status",
                "watch_types": [5],
                "rule": "process_status"
            },
        },
    },
    "log": {
        "__name": "日志",
        "ssh_login_logs": {
            "__name": "SSH登录日志",
            "user_[]": {
                "__name": "[]用户登录",
                "handler": "core.include.warning_functions::handle_log_ssh_login_logs_user",
                "watch_types": [5],
                "rule": "success_or_fail"
            },
            "ip_[]": {
                "__name": "IP[]登录",
                "handler": "core.include.warning_functions::handle_log_ssh_login_logs_ip",
                "watch_types": [5],
                "rule": "success_or_fail"
            },
            # "user_[].faileds": {
            #     "__name": "[]用户登录失败次数",
            #     "handler": "core.include.warning_functions::handle_log_ssh_login_logs_user_faileds",
            #     "watch_types": [3, 4],
            #     "rule": "integer"
            # },
            "user_[].faileds_in_last_hour": {
                "__name": "[]用户最近1小时登录失败次数",
                "handler": "core.include.warning_functions::handle_log_ssh_login_logs_user_faileds_in_last_hour",
                "watch_types": [3, 4],
                "rule": "integer"
            },
            # "faileds": {
            #     "__name": "所有用户登录失败次数",
            #     "handler": "core.include.warning_functions::handle_log_ssh_login_logs_faileds",
            #     "watch_types": [3, 4],
            #     "rule": "integer"
            # },
            "place_other": {
                "__name": "异地登录提醒",
                "handler": "core.include.warning_functions::handle_log_ssh_login_logs_place_other",
                "watch_types": [5],
                "rule": "on_off"
            }
        }
    },
    "client": {
        "__name": "主机",
        "status": {
            "__name": "主机状态",
            "on_off": {
                "__name": "主机上下线",
                "handler": "core.include.warning_functions::handle_client_status_on_off",
                "watch_types": [5],
                "rule": "online_offline",
            }
        }
    },
}

# 监控指标验证正则表达式
_validate_regex_rules = {
    "percent": {
        "regex": r"^(?:100(?:\.0{1,2})?|(?:[1-9]\d|\d)(?:\.\d{1,2})?)$",
        "err_msg": "该监控指标只能是0-100(保留两个小数点)",
        "type": "input",
        "values": [],
        "suffix": "%",
    },
    "integer": {
        "regex": r"^\d+$",
        "err_msg": "该监控指标只能是整数",
        "type": "input",
        "values": [],
        "suffix": "",
    },
    "zero_to_one_float": {
        "regex": r"^(?:0(?:\.\d{1,2})?|1(?:\.0{1,2})?)$",
        "err_msg": "该监控指标只能是0-1之间的浮点数(保留小数点后两位)",
        "type": "input",
        "values": [],
        "suffix": "",
    },
    "literal": {
        "regex": r"^\d+(?:\.\d{1,2})?(?:[kKmMgGtT]?[bB]?)?$",
        # "err_msg": "该监控指标只能是数值(B)或者数值+单位(B、KB、MB、GB、TB)",
        "err_msg": "该监控指标只能是数值(保留两个小数点)",
        "type": "unit",
        "values": [
            {"value": "B", "label": "B"},
            {"value": "KB", "label": "KB"},
            {"value": "MB", "label": "MB"},
            {"value": "GB", "label": "GB"},
            {"value": "TB", "label": "TB"},
        ],
        "suffix": "",
    },
    "success_or_fail": {
        "regex": r"^(?:success|fail)$",
        "err_msg": "该监控指标只能是success或者fail",
        "type": "select",
        "values": [
            {"value": "success", "label": "成功"},
            {"value": "fail", "label": "失败"},
        ],
        "suffix": "",
    },
    "online_offline": {
        "regex": r"^(?:online|offline)$",
        "err_msg": "该监控指标只能是online或者offline",
        "type": "select",
        "values": [
            {"value": "online", "label": "上线"},
            {"value": "offline", "label": "下线"},
        ],
        "suffix": "",
    },
    "process_status": {
        "regex": r"^(?:active|deactive)$",
        "err_msg": "该监控指标只能是active或者deactive",
        "type": "select",
        "values": [
            {"value": "active", "label": "活动"},
            {"value": "deactive", "label": "终止"},
        ],
        "suffix": "",
    },
    "on_off": {
        "regex": r"^(?:on|off)$",
        "err_msg": "该监控指标只能是on或者off",
        "type": "select",
        "values": [
            {"value": "on", "label": "开启"},
            {"value": "off", "label": "关闭"},
        ],
        "suffix": "",
    },
    "status_error": {
        "regex": r"^(?:status_error)$",
        "err_msg": "该监控指标只能是status_error",
        "type": "select",
        "values": [
            {"value": "status_error", "label": "状态异常"},
        ],
        "suffix": "",
    },
    "firewall_rule_change": {
        "regex": r"^(?:rule_change)$",
        "err_msg": "该监控指标只能是 rule_change",
        "type": "select",
        "values": [
            {"value": "rule_change", "label": "规则变更"},
            # {"value":"add","label":"添加规则"},
            # {"value":"del","label":"删除规则"},
        ],
        "suffix": "",
    },
    "port_change": {
        "regex": r"^(?:port_change)$",
        "err_msg": "port_change",
        "type": "select",
        "values": [
            {"value": "port_change", "label": "端口变更"},
        ],
        "suffix": "",
    },
    # "start_or_stop": {
    #     "regex": r"^(?:start|stop)$",
    #     "err_msg": "该监控指标只能是start或者stop",
    #     "type": "select",
    #     "values": ["start", "stop"],
    #     "suffix": "",
    # }
}

# 监控动作描述文本
_watch_action_describes = {
    'success': '成功',
    'fail': '失败',
    'online': '上线',
    'offline': '下线',
    'active': '活动',
    'deactive': '终止',
    'on': '开启',
    'off': '关闭',
    'status_error': '状态异常',
    'port_change': '端口变更',
    'add': '添加规则',
    'del': '删除规则',
    'rule_change': '规则变更',

}

# 告警限流规则 [[未处理告警数阈值, 告警间隔/分钟], ...]
_threshold_rules = [
    (12, 1440),
    (11, 600),
    (10, 540),
    (9, 480),
    (8, 420),
    (7, 360),
    (6, 300),
    (5, 240),
    (4, 120),
    (3, 60),
    (2, 30),
    (1, 10),
]


class Warning(BasicMonitor):
    '''
        @name 云监控告警类
        @author Zhj<2022-06-30>
    '''

    #  云监控告警消息队列
    __WARNING_INFO_QUEUE = queue.Queue()
    #  满足延时告警消息队列
    __WARNING_INFO_QUEUE_DELAY = queue.Queue()

    def __init__(self):
        # monitor数据库连接对象
        # self.__DB_MONITOR = None

        super(Warning, self).__init__()

    def check_rule(self, warning_rule):
        '''
            @name 校验告警规则
            @author Zhj<2022-06-30>
            @param warning_rule<dict> 告警模板或告警配置
            @return bool,err_msg
        '''
        setting = self.__get_setting(self.__build_setting_name(warning_rule))

        if setting is None:
            return False, '未找到对应的校验规则'

        if 'watch_type' not in warning_rule:
            return False, '无效的告警规则'

        if int(warning_rule['watch_type']) not in setting['watch_types']:
            return False, '监控方式错误：该目标的监控方式仅支持 %s' % (
                self.__get_watch_type_describe(setting['watch_types']))

        if 'watch_value' not in warning_rule:
            return False, '缺少关键信息：监控指标'

        if setting['rule'] not in _validate_regex_rules:
            return False, '无效的验证规则'

        if 'scores' in warning_rule and (int(warning_rule['scores']) < 0 or int(warning_rule['scores']) > 100):
            return False, '无效的告警级别'

        validate_rule = _validate_regex_rules[setting['rule']]

        if not re.match(validate_rule['regex'], str(warning_rule['watch_value'])):
            return False, validate_rule['err_msg']

        return True, ''

    def warn(self, warning_conf, cur_val=None, no_threshold=False):
        '''
            @name   检查告警规则并告警
            @author Zhj<2022-06-30>
            @param  warning_conf<dict>              告警规则
            @param  cur_val<?integer|float|string>  当前监控值
            @param  no_threshold<bool>              是否忽略告警限流
            @return bool
        '''
        # 过期不告警
        # if not self.check_monitor_endtime():
        #     return False

        # 检查该告警规则本次是否允许告警
        if not no_threshold and not self.warning_threshold(warning_conf):
            return False

        setting = self.__get_setting(self.__build_setting_name(warning_conf))

        if setting is None:
            return False

        m_f = setting['handler'].split('::', 1)

        if len(m_f) < 2:
            return False

        try:
            return public.invoke_func(m_f[0], m_f[1], [warning_conf, cur_val, self])

        except BaseException as e:
            # 记录异常堆栈
            public.print_exc_stack(e)

            return False

    def warn_all(self):
        '''
            @name 所有主机告警
            @author Zhj<2022-09-17>
            @return void
        '''
        try:
            # 获取所有主机告警规则
            warning_rules = self.get_warning_rules()

            # s = time.time()
            # public.print_log('--开始告警')
            for warning_rule in warning_rules:
                self.warn(warning_rule)
            # public.print_log('--告警结束 耗时：{}s'.format(time.time() - s))

        except BaseException as e:
            # 记录异常堆栈
            public.print_exc_stack(e)

            # public.print_log('--告警出现异常: {}'.format(str(e)))

    # 查找指定告警规则并告警
    def warn_assign(self, sid=None, p_type=None, sub_type=None, watch_target=None, cur_val=None, no_threshold=False):
        '''
            @name 查找指定告警规则并告警
            @author Zhj<2023-04-21>
            @author Zhj<2022-07-22>
            @param  sid<?integer>                   主机ID[可选]
            @param  p_type<?string>                 监控类型[可选]
            @param  sub_type<?string>               监控子类型[可选]
            @param  watch_target<?string>           监控对象[可选]
            @param  cur_val<?integer|float|string>  当前监控值
            @param  no_threshold<bool>              是否忽略告警限流
            @return None
        '''
        warning_rules = self.get_warning_rules(sid, p_type, sub_type, watch_target)
        for warning_rule in warning_rules:
            self.warn(warning_rule, cur_val, no_threshold=no_threshold)

    def get_warning_rules(self, sid=None, p_type=None, sub_type=None, watch_target=None):
        '''
            @name 获取告警规则
            @author Zhj<2022-07-22>
            @param  sid<?integer>           主机ID[可选]
            @param  p_type<?string>         监控类型[可选]
            @param  sub_type<?string>       监控子类型[可选]
            @param  watch_target<?string>   监控对象[可选]
            @return list
        '''
        sid_list_query = self.db_easy('servers') \
            .where('is_authorized = 1') \
            .where('allow_notify = 1') \
            .where_in('status', [0, 1])

        if sid is not None:
            sid_list_query.where('sid=?', sid)

        sid_list = sid_list_query.column('sid')

        query = self.db_easy('warning_configurations') \
            .where_in('sid', sid_list) \
            .field(
            'id',
            'sid',
            'title',
            'content',
            'type',
            'sub_type',
            'watch_target',
            'watch_type',
            'watch_value',
            'is_push',
            'push_methods',
            'duration',
            'add_source'
        )

        if p_type is not None:
            query.where('type=?', p_type)

        if sub_type is not None:
            query.where('sub_type=?', sub_type)

        if watch_target is not None:
            query.where('watch_target=?', watch_target)

        # public.print_log("ptype: {}/ sub type:{}/ watch target: {}".format(p_type, sub_type, watch_target))

        return query.select()

    def get_settings(self, sid=None):
        '''
            @name 获取告警设置规则
            @author Zhj<2022-07-01>
            @param  sid<?integer>   主机ID
            @return dict
        '''
        settings = copy.deepcopy(_internal_settings)
        server_info = None
        proc_list = None

        # 获取当前时间
        cur_time = int(time.time())

        if sid is not None:
            # 获取主机信息
            server_info = self.db_easy('server_details') \
                .field('disk_info', 'net_info', 'port_info') \
                .where('sid=?', int(sid)) \
                .find()

            # 获取进程列表
            pne_ids = self.db_memory('processes') \
                .where('sid=?', int(sid)) \
                .where('update_time > ?', cur_time - 120) \
                .field('pne_id') \
                .limit(500) \
                .column('pne_id')

            proc_list = self.db_easy('process_name_exe') \
                .where_in('id', pne_ids) \
                .field('name', 'exe as boot_command') \
                .select()

        extra = {
            'disk_list': [],
            'net_list': [],
            'port_list': [],
            'proc_list': []
        }

        if not self.is_empty_result(server_info):
            extra['disk_list'] = list(map(lambda i: i['mountpoint'], json.loads(server_info['disk_info'])))
            extra['net_list'] = list(map(lambda i: i['name'], json.loads(server_info['net_info'])))

            for port_info in json.loads(server_info['port_info']).values():
                if re.match(r'^(?:127|\[?::1\]?|localhost)', port_info['ip']) \
                        or int(port_info['port']) < 1 \
                        or int(port_info['port']) > 65535:
                    continue

                extra['port_list'].append(int(port_info['port']))

            extra['port_list'] = list(set(extra['port_list']))

        if not self.is_empty_result(proc_list):
            for proc_info in proc_list:
                if proc_info['name'] == '' or proc_info['boot_command'] in ['', 'exe']:
                    continue
                extra['proc_list'].append('{}|{}'.format(proc_info['name'], proc_info['boot_command']))

        for p_type in settings.keys():
            if p_type == '__name':
                continue

            for s_type in settings[p_type].keys():
                if s_type == '__name':
                    continue

                for m_target in settings[p_type][s_type].keys():
                    if m_target == '__name':
                        continue

                    del settings[p_type][s_type][m_target]['handler']

        return {
            'extra': extra,
            'watch_types': _watch_type_describes,
            'watch_types_v2': _watch_type_describes_v2,
            'validate_rules': _validate_regex_rules,
            'settings': settings,
            'push_methods': self.get_push_methods(),
            'push_methods_v2': self.get_push_methods_v2(),
            'watch_action_describes': _watch_action_describes,
        }

    def get_test_port_list(self):
        '''
            @name 获取待测试端口列表
            @author Zhj<2022-08-24>
            @return list
        '''
        # 获取已授权、允许告警、状态正常的主机ID列表
        sid_list = self.db_easy('servers') \
            .where('is_authorized = 1') \
            .where('allow_notify = 1') \
            .where_in('status', [0, 1]) \
            .column('sid')

        # 获取待测试端口
        ret = self.db_easy('server_ports') \
            .where_in('sid', sid_list) \
            .where('status=1') \
            .where('test_connection=1') \
            .where('last_test_time < ?', int(time.time()) - 60) \
            .field('id', 'sid', 'port') \
            .select()

        # 获取主机ip
        server_ip_map = self.db_easy('servers') \
            .where_in('sid', sid_list) \
            .field('sid', 'ip') \
            .column('ip', 'sid')

        for item in ret:
            item['server_ip'] = server_ip_map.get(item['sid'], '')

        return ret

    def test_ports(self):
        '''
            @name 测试端口
            @author Zhj<2022-08-24>
            @return void
        '''
        # 获取所有待测试端口
        port_list = self.get_test_port_list()

        # 插入数据
        insert_dict = {}

        # 获取当前时间
        cur_time = int(time.time())

        # 完成本次测试的端口ID列表
        success_list = []

        # 测试端口
        for item in port_list:
            ok, test_method = self.test_port_connection(item['server_ip'], item['port'])

            insert_data = {
                'sid': item['sid'],
                'port_id': item['id'],
                'port': item['port'],
                'test_method': test_method,
                'ok': int(ok),
            }

            if item['sid'] not in insert_dict:
                insert_dict[item['sid']] = [insert_data]
            else:
                insert_dict[item['sid']].append(insert_data)

            success_list.append(item['id'])

        # 写入数据
        for k, v in insert_dict.items():
            monitor_db_manager.MonitorDbManager(k).add('port_connection_logs', v)

        # 更新端口测试时间
        with monitor_db_manager.db_mgr('server_ports') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 更新端口测试时间
                db.query() \
                    .name('server_ports') \
                    .where_in('id', success_list) \
                    .update({
                    'update_time': cur_time,
                    'last_test_time': cur_time,
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

    def test_port_connection(self, address, port, method=None):
        '''
            @name 测试端口连通性
            @author Zhj<2022-07-04>
            @param address<string>  IP|域名
            @param port<integer>    端口号
            @param method<string>   测试方式 telnet|nc
            @return (端口是否连通<bool>, 测试方式<string>)
        '''
        if method is None:
            ok, _ = self.test_port_connection_via_telnet2(address, port)
            if ok:
                return True, 'telnet'

            ok, _ = self.test_port_connection_via_nc(address, port)
            if ok:
                return True, 'nc'

            return False, ''

        if method not in ['telnet', 'nc']:
            return False

        if method == 'telnet':
            return self.test_port_connection_via_telnet2(address, port), 'telnet'
        elif method == 'nc':
            return self.test_port_connection_via_nc(address, port), 'nc'

        return False, ''

    def test_port_connection_via_telnet2(self, address, port, timeout=2):
        '''
            @name 使用telnet的方式测试端口
            @author lx<2022-07-08>
            @param  address<string>  IP|域名
            @param  port<integer>    端口号
            @return bool
        '''
        import telnetlib
        try:
            telnetlib.Telnet(host=address, port=port, timeout=timeout)
            return True, "telnet"
        except:
            return False, 'telnet'

    def test_port_connection_via_telnet(self, address, port):
        '''
            @name 使用telnet的方式测试端口
            @author Zhj<2022-07-08>
            @param  address<string>  IP|域名
            @param  port<integer>    端口号
            @return bool
        '''
        res = public.ExecShell('telnet {} {}'.format(address, port))

        if len(res) < 1:
            return False

        if res[0].find('Connected') < 0:
            return False

        return True

    def test_port_connection_via_nc(self, address, port):
        '''
            @name 使用nc的方式测试端口
            @author Zhj<2022-07-08>
            @param  address<string>  IP|域名
            @param  port<integer>    端口号
            @return bool
        '''
        res = public.ExecShell('nc -w 1 {} {} && echo ok || echo no'.format(address, port))

        if len(res) < 1:
            return False

        if res[0].find('ok') < 0:
            return False

        return True

    def get_compare_operator(self, warning_conf):
        '''
            @name   获取对比操作符
            @author Zhj<2022-07-05>
            @param  warning_config<dict>        告警规则
            @param  cur_val<integer|string>     当前指标
            @return string|None
        '''
        setting = self.__get_setting(self.__build_setting_name(warning_conf))

        opt = '='

        if setting is None:
            return opt

        # 当前指标大于或等于规则设定指标
        if warning_conf['watch_type'] in [1, 3]:
            opt = '>='
        # 当前指标小于规则设定指标
        elif warning_conf['watch_type'] in [2, 4]:
            opt = '<'
        # 动作
        elif warning_conf['watch_type'] in [5]:
            opt = '='

        return opt

    def compare(self, warning_conf, cur_val):
        '''
            @name   匹配监控指标
            @author Zhj<2022-07-05>
            @param  warning_conf<dict>               告警规则
            @param  cur_val<integer|float|string>    当前监控指标
            @return bool
        '''
        opt = self.get_compare_operator(warning_conf)

        if opt == '>=':
            return float(self.format_watch_value(warning_conf['watch_value'])) <= float(
                self.format_watch_value(cur_val))

        if opt == '<':
            return float(self.format_watch_value(warning_conf['watch_value'])) > float(self.format_watch_value(cur_val))

        return self.format_watch_value(warning_conf['watch_value']) == self.format_watch_value(cur_val)

    def has_unhandled_task(self, warning_config, last_seconds=600):
        '''
            @name 检查是否存在未处理的告警任务
            @author Zhj<2022-07-05>
            @param  warning_config<dict>    告警规则
            @param  last_seconds<integer>   最近几秒钟内[可选 默认10分钟]
            @return bool
        '''
        # 查询是否存在未处理的告警任务
        return self.db_easy('warning_tasks') \
            .field('id') \
            .where('`sid` = ?', int(warning_config.get('sid', 0))) \
            .where('`conf_id` = ?', int(warning_config.get('id', 0))) \
            .where('`status` = 0') \
            .where('`create_time` >= ?', int(time.time()) - last_seconds) \
            .exists()

    def get_unhandled_task_num(self, warning_conf):
        '''
            @name 获取未处理的告警任务总数
            @author Zhj<2022-07-12>
            @param  warning_conf<dict>   告警规则
            @return integer
        '''
        unhandled_task_num = self.db_easy('warning_tasks') \
            .where('`sid` = ?', int(warning_conf.get('sid', 0))) \
            .where('`conf_id` = ?', int(warning_conf.get('id', 0))) \
            .where('`status` = 0') \
            .count()

        if self.is_empty_result(unhandled_task_num):
            return 0

        return int(unhandled_task_num)

    def add_task(self, warning_conf, prefix=None, title=None, content=None, notify_content=None, mail_title=None):
        '''
            @name 添加告警任务
            @author Zhj<2022-07-05>
            @param  warning_conf<dict>      告警规则
            @param  prefix<?string>         告警标题与告警内容的前缀[可选]
            @param  title<?string>          告警标题[可选]
            @param  content<?string>        告警内容[可选]
            @param  notify_content<?string> 告警通知内容[可选]
            @return bool
        '''
        # 没有设置告警标题与告警内容时
        # 尝试从缓存获取
        if title is None and content is None:
            # 获取告警标题和告警内容
            title, content = self.cache_task_title_and_content(warning_conf)

        # 没有设置告警标题与告警内容的前缀时
        # 尝试从缓存获取
        if prefix is None:
            prefix = self.cache_task_prefix(warning_conf)

        # 告警提示文本
        # warning_description = content if content is not None else self.__build_warning_description(warning_conf)

        # 格式化告警标题
        title = '【{}】主机[{}]{}'.format(
            title if title is not None else warning_conf['title'],
            self.get_server_describe(warning_conf['sid']),
            prefix if prefix is not None else '',
            # warning_description
        )

        # 格式化告警内容
        if content is None:
            content = '主机[{}]{}'.format(
                self.get_server_describe(warning_conf['sid']),
                prefix if prefix is not None else '',
                # warning_description
            )
        task_id = self.db_easy('warning_tasks').insert({
            'sid': warning_conf['sid'],
            'conf_id': warning_conf['id'],
            'title': title,
            'content': content,
        })

        # tmp_ip = self.get_server_describe(warning_conf['sid'])
        # server_ip = tmp_ip[:tmp_ip.rfind('（')] if tmp_ip.find('（') > -1 else tmp_ip
        # title_name = title[title.rfind('【') + 1:title.rfind('】')] if title else '任务名为空'
        # send_msg = [
        #     '> 告警消息：{}'.format(notify_content if notify_content is not None else content),
        #     '> 告警阈值: {}'.format(warning_conf['watch_value']),
        #     '> IP: {}'.format(server_ip),
        #     '> 备注: {}'.format(server_remark if server_remark else '无备注'),
        #     '> 推送时间: {}'.format(public.format_date()),
        #     '',
        #     '堡塔云监控告警提醒，请尽快处理',
        # ]
        send_msg = self.__send_msg_template(warning_conf, title, content, notify_content, prefix)
        tmp_ip = self.get_server_describe(warning_conf['sid'])
        server_ip = tmp_ip[:tmp_ip.rfind('（')] if tmp_ip.find('（') > -1 else tmp_ip

        if mail_title is None:
            mail_title = '服务器IP：{} {}'.format(server_ip, title)

        if isinstance(task_id, str):
            return False

        if int(task_id) == 0:
            return False

        # 推送告警信息(如果可以)
        self.notify(task_id, warning_conf, title, send_msg, mail_title)

        return True

    def __send_msg_template(self, warning_conf=None, title=None, content=None, notify_content=None, prefix=None):
        tmp_ip = self.get_server_describe(warning_conf['sid'])
        server_ip = tmp_ip[:tmp_ip.rfind('（')] if tmp_ip.find('（') > -1 else tmp_ip
        title_name = title[title.rfind('【') + 1:title.rfind('】')] if title else '任务名为空'
        # 获取主机备注
        server_remark = self.get_server_remark_by_sid(warning_conf['sid'])

        val_type = {
            '1': 'percent',
            '2': 'percent',
            '5': 'action',
        }.get(str(warning_conf['watch_type']), None)

        return [
            '{}'.format(prefix if prefix is not None else ''),
            '',
            '> 告警消息：{}'.format(notify_content if notify_content is not None else content),
            '> 告警阈值: {}'.format(self.transform_value(warning_conf['watch_value'], val_type=val_type)),
            '> IP: {}'.format(server_ip),
            '> 备注: {}'.format(server_remark if server_remark else '无备注'),
            '> 推送时间: {}'.format(public.format_date()),
            '',
            '堡塔云安全监控告警提醒，请尽快处理',
        ]

    def notify(self, task_id, warning_conf=None, title=None, content=None, mail_title=None):
        '''
            @name 推送告警信息
            @author Zhj<2022-07-05>
            @param  task_id<integer>        告警任务ID
            @param  warning_conf<?dict>     告警规则
            @param  title<?string>          告警标题[可选]
            @param  content<?string>        告警内容[可选]
            @param  mail_title<?string>     邮件标题[可选]
            @return bool
        '''
        # 没有传入告警规则
        # 获取告警规则

        if warning_conf is None:
            warning_task = self.db_easy('warning_tasks').where('id=?', int(task_id)).field('conf_id').find()

            if self.is_empty_result(warning_task):
                return False

            warning_conf = self.db_easy('warning_configurations') \
                .where('id=?', int(warning_task['conf_id'])) \
                .field(
                'id', 'sid', 'title', 'content', 'type', 'sub_type', 'watch_target',
                'watch_type', 'watch_value', 'is_push', 'push_methods', 'duration'
            ).find()

            if self.is_empty_result(warning_conf):
                return False

        title = title if title is not None else warning_conf['title']
        content = content if content is not None else warning_conf['content']

        # 检查是否本次告警是否推送信息
        if int(warning_conf['is_push']) == 0:
            return False

        # 推送告警消息
        self.push_message(content, push_methods=warning_conf['push_methods'], options={
            'mail_title': mail_title,
        })

        cur_time = int(time.time())

        # 更新告警任务推送状态
        self.db_easy('warning_tasks') \
            .where('id=?', int(task_id)) \
            .update({
            'is_pushed': 1,
            'push_time': cur_time,
            'update_time': cur_time,
        })

        return True

    def get_var(self, s):
        '''
            @name 获取规则变量
            @author Zhj<2022-07-05>
            @param  s<string> 含有[xxxx]的字符串
            @return string|None
        '''
        m = re.search(r'\[([^\[]+)\]', str(s))

        if not m:
            return None

        return m.group(1)

    def get_last_handled_task_handle_time(self, warning_config):
        '''
            @name 获取上一次已处理的告警任务的处理时间
            @author Zhj<2022-07>
            @param  warning_config<dict> 告警规则
            @return integer
        '''
        # 查询上一次已处理的告警任务的更新时间
        last_handled_task = self.db_easy('warning_tasks').field('handle_time').where(
            'sid = ? and conf_id=? and status=1',
            [int(warning_config.get('sid', 0)), int(warning_config.get('id', 0))]
        ).order('handle_time', 'desc').find()

        # 不存在已处理的告警任务
        if self.is_empty_result(last_handled_task):
            return 0

        return int(last_handled_task['handle_time'])

    def format_watch_value(self, watch_value):
        '''
            @name 格式化监控指标 主要针对xxKB这些格式
            @author Zhj<2022-07-05>
            @param  watch_value<string> 监控指标
            @return string
        '''
        m = re.match(r'^(\d+(?:\.\d{1,2})?)([bB]|[kKmMgGtT][bB]?)$', str(watch_value))

        if m:
            trans = {
                'b': 1,
                'kb': 1024,
                'mb': 1024 ** 2,
                'gb': 1024 ** 3,
                'tb': 1024 ** 4,
            }

            v1 = float(m.group(1))
            v2 = m.group(2).lower()

            if len(v2) == 1 and v2 != 'b':
                v2 += 'b'

            return round(v1 * trans.get(v2, 0))

        return watch_value

    def transform_value(self, val, val_type=None):
        '''
            @name   数值转换
            @author Zhj<2022-07-14>
            @param  val<integer|float|string>   数值
            @param  val_type<?string|intger>    数值类型[可选]
            @return string
        '''
        # 百分比
        if val_type == 'percent':
            return str(round(float(val), 2)) + '%'

        # 字节数
        elif val_type == 'bytes':
            return public.to_size(int(val))

        # 动作
        elif val_type == 'action' or val_type == 5:
            if val in _watch_action_describes:
                return _watch_action_describes[val]

        # 原样返回
        return val

    # def warning_threshold(self, warning_conf):
    #     '''
    #         @name 告警限流检查(检查本次是否进行告警)
    #         @author Zhj<2022-07-12>
    #         @param  warning_conf<dict> 告警规则
    #         @return bool
    #     '''
    #     # 缓存键名
    #     cache_key = 'BT_MONITOR_CACHE_WARNING_THRESHOLD__' + str(warning_conf['id'])
    #
    #     # 优先从缓存中获取
    #     if public.cache_get(cache_key):
    #         return False
    #
    #     # 获取未处理告警数量
    #     unhandled_num = self.get_unhandled_task_num(warning_conf)
    #
    #     # 匹配限流规则
    #     for threshold_rule in _threshold_rules:
    #         if threshold_rule[0] <= unhandled_num:
    #             # 查询是否存在未处理的告警任务
    #             if self.has_unhandled_task(warning_conf, threshold_rule[1] * 60):
    #                 # 写入缓存
    #                 public.cache_set(cache_key, 1, threshold_rule[1] * 60)
    #
    #                 return False
    #
    #             break
    #
    #     return True

    def warning_threshold(self, warning_conf):
        '''
            @name 告警限流检查(检查本次是否进行告警) 缓存替换数据库
            @author lotk<2023-02-20>
            @param  warning_conf<dict> 告警规则
            @return bool
        '''
        # 当通过其它路径添加告警时，不执行限流操作
        if int(warning_conf.get('add_source', 0)) > 0:
            return True

        conf_id = warning_conf['id']

        cur_time = int(time.time())

        # 获取未处理告警数量
        unhandled_num = self.get_unhandled_task_num(warning_conf)

        # 数据库查询
        query = self.db_memory('warning_threshold_logs') \
            .field('id', 'conf_id', 'threshold_rule_time', 'push_time', ) \
            .where('conf_id=?', conf_id) \
            .find()

        # 匹配限流规则
        for threshold_rule in _threshold_rules:
            if threshold_rule[0] <= unhandled_num:
                # 没有数据 插入一条
                if query is None:
                    self.db_memory('warning_threshold_logs') \
                        .insert({
                        'conf_id': conf_id,
                        'push_time': cur_time,
                        'threshold_rule_time': threshold_rule[1] * 60,
                    })
                    return True

                # 有数据 未到达下一次告警时间
                if cur_time < int(query['threshold_rule_time']) + int(query['push_time']):
                    return False

                # 查询是否存在未处理的告警任务
                if self.has_unhandled_task(warning_conf, threshold_rule[1] * 60):
                    # 有 修改数据库信息
                    self.db_memory('warning_threshold_logs') \
                        .where('conf_id=?', conf_id) \
                        .update({
                        'push_time': cur_time,
                        'threshold_rule_time': threshold_rule[1] * 60,
                    })
                    return False
                break
        return True

    def compare_resource_disk_helper(self, warning_config, field):
        '''
            @name 磁盘告警规则匹配帮助方法
            @author Zhj<2022-07-12>
            @param  warning_config<dict>    告警规则
            @param  field<string>           字段名
            @return bool
        '''
        # 获取监控的磁盘名称和挂载点
        # disk_name = self.get_var(warning_config['sub_type'])
        disk_name, mountpoint = self.__get_disk_name(warning_config)

        if disk_name is None:
            return False

        # 字段名 -> (描述, 类型)
        trans = {
            'used_percent': ('磁盘占用率', 'percent'),
            'inodes_used_percent': ('inode占用率', 'percent'),
            'iops': ('iops', None),
            'io_percent': ('IO耗时占比', 'percent'),
            'used': ('磁盘占用空间', 'bytes'),
            'inodes_used': ('inode占用空间', 'bytes'),
            'read_bytes_per_second': ('磁盘每秒读取速率', 'bytes'),
            'write_bytes_per_second': ('磁盘每秒写入速率', 'bytes'),
        }

        disk_list = self.db_easy('server_details') \
            .where('sid=?', warning_config.get('sid', 0)) \
            .value('disk_info')

        disk_list = json.loads(disk_list)

        total = ''
        free = ''
        for disk_txt in disk_list:
            mount = disk_txt.get('mountpoint', None)
            if mountpoint == mount:
                total = disk_txt.get('total', None)
                free = disk_txt.get('free', None)

        # 获取当前时间（结束时间）
        cur_time = int(time.time())

        tmp_ip = self.get_server_describe(warning_config['sid'])
        server_ip = tmp_ip[:tmp_ip.rfind('（')] if tmp_ip.find('（') > -1 else tmp_ip

        # 监控所有磁盘
        if disk_name == 'all':
            # 获取磁盘列表
            disk_info_list = self.cache_realtime_server_info(warning_config['sid']).get('disk_info', [])

            ok = False

            # 遍历磁盘列表 对比规则
            # disk_name = []
            for disk_info in disk_info_list:
                # 获取磁盘用户设置时间内平均占用率
                # disk_name.append(disk_info['mountpoint'])
                # public.print_log("++++{}".format(disk_name),_level='error')
                ret = self.db_memory('server_disk_info_list') \
                    .where(
                    '`sid` = ? AND `name` = ? AND `create_time` > ?',
                    [int(warning_config['sid']), disk_info['name'], cur_time - int(warning_config['duration'])]
                ).avg(field)

                # public.print_log("++++{}".format(disk_info['mountpoint']),_level='error')
                # all_mount = disk_info.get('mountpoint', None)
                # if mountpoint == all_mount:
                all_total = disk_info.get('total', 0)
                all_free = disk_info.get('free', 0)

                if self.is_empty_result(ret):
                    continue

                if self.compare(warning_config, ret):
                    ok = True

                    # 添加告警任务
                    v, t = trans.get(field, ('', None))
                    # public.print_log("++++++++{}".format(trans.get(field, ('', None))), _level='error')
                    if field == 'used_percent':
                        # for temp in disk_name:
                        content = '磁盘[{}] 占用率为[{}] 剩余空间[{}GB]'.format(
                            disk_info['mountpoint'],
                            self.transform_value(ret, t),
                            round(all_free / 1024 ** 3), 2)
                        mail_title = "{}磁盘[{}] 占用率为[{}] 剩余[{}GB]可用".format(
                            server_ip,
                            disk_info['mountpoint'],
                            self.transform_value(ret, t),
                            round(all_free / 1024 ** 3), 2)
                        prefix = '磁盘[{}]占用率超过阈值'.format(self.transform_value(ret, t))
                        title = content
                        # public.print_log("++++++++{}".format(content), _level='error')
                        self.add_task(warning_config, content=content, mail_title=mail_title, title=title,
                                      prefix=prefix)
                    else:
                        mail_title = "{}磁盘[{}] 当前{}为[{}]".format(
                            server_ip,
                            disk_info['mountpoint'],
                            v,
                            self.transform_value(ret, t))
                        self.add_task(warning_config, '磁盘[{}] 当前{}为[{}]'.format(
                            disk_info['mountpoint'],
                            v,
                            self.transform_value(ret, t)),
                                      mail_title=mail_title)

            return ok

        # 监控单个磁盘
        # 获取磁盘用户设置时间内平均占用率
        ret = self.db_memory('server_disk_info_list') \
            .where(
            '`sid` = ? AND `name` = ? AND `create_time` > ?',
            [int(warning_config['sid']), disk_name, cur_time - int(warning_config['duration'])]
        ).avg(field)

        if self.is_empty_result(ret):
            return False

        if not self.compare(warning_config, ret):
            return False

        # 添加告警任务
        v, t = trans.get(field, ('', None))
        if field == 'used_percent':
            content = '磁盘[{}] 占用率为[{}] 剩余空间[{}GB]'.format(
                mountpoint,
                self.transform_value(ret, t),
                round(free / 1024 ** 3), 2)
            mail_title = "{}磁盘[{}] 占用率为[{}] 剩余[{}GB]可用".format(
                server_ip,
                mountpoint,
                self.transform_value(ret, t),
                round(free / 1024 ** 3), 2)
            prefix = '磁盘[{}]占用率超过阈值'.format(mountpoint)
            title = content
            self.add_task(warning_config, content=content, mail_title=mail_title, title=title, prefix=prefix)
            return True
        else:
            mail_title = "{}磁盘[{}] 当前{}为[{}]".format(
                server_ip,
                mountpoint,
                v,
                self.transform_value(ret, t))
            self.add_task(warning_config, '磁盘[{}] 当前{}为[{}]'.format(
                mountpoint,
                v,
                self.transform_value(ret, t)),
                          mail_title=mail_title)
        return True

    def compare_resource_net_helper(self, warning_config, field):
        '''
            @name 网卡告警规则匹配帮助方法
            @author Zhj<2022-07-12>
            @param  warning_config<dict> 告警规则
            @param  field<string>        字段名
            @return bool
        '''
        # 获取监控的网卡名称
        net_name = self.get_var(warning_config['sub_type'])

        if net_name is None:
            return False

        # 字段名 -> (描述, 类型)
        trans = {
            'sent_per_second': ('网卡每秒上传速率', 'bytes'),
            'recv_per_second': ('网卡每秒下载速率', 'bytes'),
        }

        # 获取当前时间
        cur_time = int(time.time())
        tmp_ip = self.get_server_describe(warning_config['sid'])
        server_ip = tmp_ip[:tmp_ip.rfind('（')] if tmp_ip.find('（') > -1 else tmp_ip
        # 监控所有网卡
        if net_name == 'all':
            # 获取网卡列表
            net_info_list = self.cache_realtime_server_info(warning_config['sid']).get('net_info', [])

            ok = False

            # 遍历网卡列表 对比规则
            for net_info in net_info_list:
                # 获取网卡用户设置时间内平均信息
                ret = self.db_memory('server_net_info_list') \
                    .where(
                    '`sid` = ? AND `name` = ? AND `create_time` > ?',
                    [int(warning_config['sid']), net_info['name'], cur_time - int(warning_config['duration'])]
                ).avg(field)

                if self.is_empty_result(ret):
                    continue

                if self.compare(warning_config, ret):
                    ok = True
                    # 添加告警任务
                    v, t = trans.get(field, ('', None))
                    mail_title = "{}网卡[{}] 当前{}为[{}]".format(server_ip, net_info['name'], v,
                                                                  self.transform_value(ret, t))
                    self.add_task(
                        warning_config,
                        '网卡[{}] 当前{}为[{}]'.format(net_info['name'], v, self.transform_value(ret, t),
                                                       mail_title=mail_title)
                    )

            return ok

        # 监控单个网卡
        # 获取网卡用户设置时间内平均信息
        ret = self.db_memory('server_net_info_list') \
            .where(
            '`sid` = ? AND `name` = ? AND `create_time` > ?',
            [int(warning_config['sid']), net_name, cur_time - int(warning_config['duration'])]
        ).avg(field)

        if self.is_empty_result(ret):
            return False

        if not self.compare(warning_config, ret):
            return False

        # 添加告警任务
        v, t = trans.get(field, ('', None))
        mail_title = "{}网卡[{}] 当前{}为[{}]".format(server_ip, net_name, v, self.transform_value(ret, t))
        self.add_task(warning_config, '网卡[{}] 当前{}为[{}]'.format(net_name, v, self.transform_value(ret, t)),
                      mail_title=mail_title)

        return True

    def compare_service_process_helper(self, warning_config, table_name, field):
        # 获取进程名称
        proc_name = self.get_var(warning_config['sub_type'])

        if proc_name is None:
            return False

        # 字段名 -> (描述, 类型)
        trans = {
            'process_cpu_info_list.percent': ('CPU使用率', 'percent'),
            'process_mem_info_list.percent': ('内存占用率', 'percent'),
            'process_disk_io_info_list.read_bytes_per_second': ('磁盘每秒读取速率', 'bytes'),
            'process_disk_io_info_list.write_bytes_per_second': ('磁盘每秒写入速率', 'bytes'),
            'process_network_io_info_list.sent_bytes_per_second': ('网络每秒上传速率', 'bytes'),
            'process_network_io_info_list.recv_bytes_per_second': ('网络每秒下载速率', 'bytes'),
        }

        # 获取当前时间
        cur_time = int(time.time())

        tmp_ip = self.get_server_describe(warning_config['sid'])
        server_ip = tmp_ip[:tmp_ip.rfind('（')] if tmp_ip.find('（') > -1 else tmp_ip
        # 监控所有进程
        if proc_name == 'all':
            # 获取所有进程
            proc_list = self.db_memory('processes').where(
                '`sid` = ? AND `update_time` > ?',
                [int(warning_config['sid']), cur_time - 120]
            ).field('id', 'pne_id').select()

            if self.is_empty_result(proc_list):
                return False

            pnes = self.db_easy('process_name_exe') \
                .where_in('id', list(set(map(lambda x: x['pne_id'], proc_list)))) \
                .field('id', 'name', 'exe') \
                .column(None, 'id')

            for item in proc_list:
                pne = pnes.get(item['pne_id'], {})
                item['name'] = pne.get('name', '')
                item['boot_command'] = pne.get('exe', '')
                del (item['pne_id'])

            ok = False

            for proc_info in proc_list:
                # 获取最近用户设置时间内的平均值
                ret = self.db_memory(table_name) \
                    .where(
                    '`process_id` = ? and `create_time` > ?',
                    [proc_info['id'], cur_time - int(warning_config['duration'])]
                ).avg(field)

                if self.is_empty_result(ret):
                    continue

                if self.compare(warning_config, ret):
                    ok = True
                    # 添加告警任务
                    v, t = trans.get('{}.{}'.format(table_name, field), ('', None))
                    if field == 'percent':
                        mail_title = '[{}]进程[{}] 当前CPU使用率[{}]'.format(server_ip, proc_info['name'], v)
                        self.add_task(
                            warning_config,
                            '进程[{}] 当前{}为[{}]'.format('{}|{}'.format(
                                proc_info['name'],
                                proc_info['boot_command']),
                                v,
                                self.transform_value(ret, t)),
                            mail_title=mail_title
                        )
                    else:
                        mail_title = '[{}]进程[{}] 当前[{}]为[{}]'.format(server_ip, proc_info['name'], v,
                                                                          self.transform_value(ret, t))
                        self.add_task(
                            warning_config,
                            '进程[{}] 当前{}为[{}]'.format('{}|{}'.format(
                                proc_info['name'],
                                proc_info['boot_command']),
                                v,
                                self.transform_value(ret, t)),
                            mail_title=mail_title
                        )

            return ok

        # 监控单个进程
        # 查询进程信息
        proc_name, boot_command = proc_name.split('|', 1)
        pne_id = self.get_pne_id(proc_name, boot_command)
        proc_info = self.db_memory('processes').where(
            '`sid` = ? AND `pne_id` = ?',
            [warning_config['sid'], pne_id]
        ).field('id').find()

        if self.is_empty_result(proc_info):
            return False

        # 获取最近用户设置时间内的平均值
        ret = self.db_memory(table_name) \
            .where(
            '`process_id` = ? and `create_time` > ?',
            [proc_info['id'], cur_time - int(warning_config['duration'])]
        ).avg(field)

        if self.is_empty_result(ret):
            return False

        if not self.compare(warning_config, ret):
            return False

        # 添加告警任务
        v, t = trans.get('{}.{}'.format(table_name, field), ('', None))
        if field == 'percent':
            mail_title = '进程[{}] 当前CPU使用率[{}]'.format(proc_info['name'], v)
            self.add_task(warning_config, '进程[{}] 当前{}为[{}]'.format('{}|{}'.format(proc_name, boot_command), v,
                                                                         self.transform_value(ret, t)),
                          mail_title=mail_title)
        else:
            mail_title = '[{}]进程[{}] 当前[{}]为[{}]'.format(server_ip, proc_info['name'], v,
                                                              self.transform_value(ret, t))
            self.add_task(warning_config, '进程[{}] 当前{}为[{}]'.format('{}|{}'.format(proc_name, boot_command), v,
                                                                         self.transform_value(ret, t)),
                          mail_title=mail_title)
        return True

    def cache_task_title_and_content(self, warning_config, title=None, content=None):
        '''
            @name   缓存告警任务标题和告警内容
            @author Zhj<2022-07-13>
            @param  warning_config<dict>    告警规则
            @param  title<string>           告警标题
            @param  content<string>         告警内容
            @return (title<?string>, content<?string>)
        '''
        cache_key = 'BT_MONITOR_CACHE_WARNING_TASK_TITLE_AND_CONTENT__{}'.format(warning_config['id'])

        # 从缓存中获取
        if title is None and content is None:
            cached_title_and_content = public.cache_get(cache_key)

            if not cached_title_and_content:
                return None, None

            try:
                cached_title_and_content = json.loads(cached_title_and_content)

                # 删除缓存
                public.cache_remove(cache_key)

                return cached_title_and_content.get('title', None), cached_title_and_content.get('content', None)
            except:
                return None, None

        d = {
            'title': warning_config['title'],
            'content': warning_config['content'],
        }

        if title is not None:
            d['title'] = title

        if content is not None:
            d['content'] = content

        # 写入缓存
        public.cache_set(cache_key, json.dumps(d), 60)

        return d.get('title', None), d.get('content', None)

    def cache_task_prefix(self, warning_config, prefix=None):
        '''
            @name   缓存告警标题与告警内容前缀
            @author Zhj<2022-07-14>
            @param  warning_config<dict>    告警规则
            @param  prefix<?string>         告警前缀
            @return string|None
        '''
        cache_key = 'BT_MONITOR_CACHE_WARNING_TASK_PREFIX__{}'.format(prefix)

        cached_prefix = public.cache_get(cache_key)

        # 从缓存中获取
        if prefix is None:
            if not cached_prefix:
                return None

            # 删除缓存
            public.cache_remove(cache_key)

            return cached_prefix

        public.cache_set(cache_key, prefix, 60)

        return prefix

    def init_default_template(self):
        '''
            @name 初始化默认告警模板
            @author Zhj<2022-07-06>
            @return bool
        '''
        # 云监控需完成初始化
        if not self.the_project_is_initialized():
            return False

        cache_key = 'BT_MONITOR_CACHE_DEFAULT_WARNING_TEMPLATES_INITIALIZED'

        # 模板包为空时创建
        if public.cache_get(cache_key) or self.db_easy('warning_template_packages').where('id>0').field('id').exists():
            return True

        s_time = time.time()
        public.print_log('--正在初始化默认告警模板--')

        # 告警模板规则
        default_templates = [
            {
                "title": "CPU使用率超过阈值",
                "content": "CPU使用率已超过阈值，请及时处理",
                "type": "resource",
                "sub_type": "cpu",
                "watch_target": "percent",
                "watch_type": 1,
                "watch_value": "80",
                "is_push": 1,
                "scores": 80,
            },
            {
                "title": "进程CPU占用率超过阈值",
                "content": "进程CPU占用率已超过阈值，请及时处理",
                "type": "service",
                "sub_type": "proc_[all]",
                "watch_target": "cpu.percent",
                "watch_type": 1,
                "watch_value": "80",
                "is_push": 1,
                "scores": 80,
            },
            {
                "title": "进程内存占用率超过阈值",
                "content": "进程内存占用率已超过阈值，请及时处理",
                "type": "service",
                "sub_type": "proc_[all]",
                "watch_target": "mem.percent",
                "watch_type": 1,
                "watch_value": "80",
                "is_push": 1,
                "scores": 80,
            },
            {
                "title": "磁盘占用率超过阈值",
                "content": "磁盘占用率超过阈值，请及时处理",
                "type": "resource",
                "sub_type": "disk_[all]",
                "watch_target": "used_percent",
                "watch_type": 1,
                "watch_value": "80",
                "is_push": 1,
                "scores": 31,
            },
            {
                "title": "磁盘Inodes占用率超过阈值",
                "content": "磁盘Inodes占用率超过阈值，请及时处理",
                "type": "resource",
                "sub_type": "disk_[all]",
                "watch_target": "inodes_used_percent",
                "watch_type": 1,
                "watch_value": "80",
                "is_push": 1,
                "scores": 31,
            },
            {
                "title": "SSH最近1小时内连续登录失败次数达到阈值",
                "content": "近一小时内有用户通过SSH登录该主机失败次数达到阈值，请及时处理",
                "type": "log",
                "sub_type": "ssh_login_logs",
                "watch_target": "user_[all].faileds_in_last_hour",
                "watch_type": 3,
                "watch_value": "5",
                "is_push": 1,
                "scores": 31,
            },
            {
                "title": "主机上线",
                "content": "主机已上线",
                "type": "client",
                "sub_type": "status",
                "watch_target": "on_off",
                "watch_type": 5,
                "watch_value": "online",
                "is_push": 1,
                "scores": 0,
            },
            {
                "title": "主机下线",
                "content": "主机已下线",
                "type": "client",
                "sub_type": "status",
                "watch_target": "on_off",
                "watch_type": 5,
                "watch_value": "offline",
                "is_push": 30,
                "scores": 0,
            },
            {
                "title": "SSH异地登录提醒",
                "content": "该主机发生SSH异地登录",
                "type": "log",
                "sub_type": "ssh_login_logs",
                "watch_target": "place_other",
                "watch_type": 5,
                "watch_value": "on",
                "is_push": 60,
                "scores": 31,
            },
        ]

        # 打开数据库
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 默认告警包
                package_id = db.query() \
                    .name('warning_template_packages') \
                    .insert({
                    'name': '默认模板',
                })

                for default_template in default_templates:
                    default_template['package_id'] = package_id

                # 批量插入告警模板
                db.query() \
                    .name('warning_templates') \
                    .insert_all(default_templates)

                # 提交事务
                db.commit()

                public.print_log('--默认告警模板初始化完成-- 耗时：{}秒'.format(time.time() - s_time))
            except BaseException as e:
                # 回滚事务
                db.rollback()

                public.print_log('--默认告警模板初始化失败--')

                # 记录异常堆栈
                public.print_exc_stack(e)

                return False

        # 将初始化标识写入缓存
        public.cache_set(cache_key, 1)

        return True

    def __get_setting(self, setting_name):
        '''
            @name 获取告警预设校验规则与告警处理函数
            @author Zhj<2022-06-30>
            @param setting_name<string> 名称(一级分类.二级分类.三级分类)
            @return dict|None
        '''
        l = setting_name.split('.', 2)

        if len(l) < 3:
            return None

        if l[0] not in _internal_settings:
            return None

        if not isinstance(_internal_settings[l[0]], dict) or l[1] not in _internal_settings[l[0]]:
            return None

        if not isinstance(_internal_settings[l[0]][l[1]], dict) or l[2] not in _internal_settings[l[0]][l[1]]:
            return None

        if not isinstance(_internal_settings[l[0]][l[1]][l[2]], dict):
            return None

        return _internal_settings[l[0]][l[1]][l[2]]

    def __build_setting_name(self, warning_rule):
        '''
            @name 构建告警校验规则名称
            @author Zhj<2022-06-30>
            @param warning_rule<dict> 告警模板或告警配置
            @return string
        '''
        if 'type' not in warning_rule:
            return ''

        if 'sub_type' not in warning_rule:
            return ''

        if 'watch_target' not in warning_rule:
            return ''

        return '%s.%s.%s' % (warning_rule['type'], re.sub(r'\[[^\]]+\]', '[]', warning_rule['sub_type']),
                             re.sub(r'\[[^\]]+\]', '[]', warning_rule['watch_target']))

    def __get_watch_type_describe(self, watch_types):
        '''
            @name 获取监控方式描述文本
            @author Zhj<2022-06-30>
            @param watch_types<list|integer> 监控方式
            @return string
        '''
        if isinstance(watch_types, list) and len(watch_types) > 0:
            ret = ''
            for watch_type in watch_types:
                if str(watch_type) not in _watch_type_describes:
                    continue
                ret += _watch_type_describes[str(watch_type)] + '、'
            return ret[:-1]

        return _watch_type_describes.get(str(watch_types), '')

    def __build_warning_description(self, warning_config):
        '''
            @name 生成告警规则提示文本
            @author Zhj<2022-07-21>
            @param  warning_config<dict>    告警规则
            @return string
        '''
        # 获取告警规则设置
        setting = self.__get_setting(self.__build_setting_name(warning_config))

        if setting is None:
            return ''

        m = {
            '1': '高于',
            '2': '低于',
            '3': '高于',
            '4': '低于',
            '5': '匹配'
        }

        return '{} 监控阈值[{}]'.format(
            m.get(str(warning_config['watch_type']), '匹配'),
            self.transform_value(warning_config['watch_value'],
                                 5 if warning_config['watch_type'] == 5 else setting.get('rule', None))
        )

    # 获取告警推送方式(内部方法)
    def __get_push_methods(self):
        filename = '{}/data/msg_push.json'.format(public.get_panel_path())
        if not os.path.exists(filename):
            return {}

        msg_push_conf = {}

        try:
            msg_push_conf = json.loads(public.readFile(filename))
        except:
            pass

        d = {}

        if 'dingding' in msg_push_conf and len(msg_push_conf['dingding'].get('dingding_url', '').strip()) == 0:
            msg_push_conf.pop('dingding', None)

        if 'weixin' in msg_push_conf and len(msg_push_conf['weixin'].get('weixin_url', '').strip()) == 0:
            msg_push_conf.pop('weixin', None)

        if 'feishu' in msg_push_conf and len(msg_push_conf['feishu'].get('feishu_url', '').strip()) == 0:
            msg_push_conf.pop('feishu', None)

        if not self.__check_push_method_mail_setting(msg_push_conf):
            msg_push_conf.pop('mail', None)

        for push_method in msg_push_conf.keys():
            if push_method not in _push_methods:
                continue
            d[push_method] = _push_methods[push_method]

        # public.cache_set(cache_key, json.dumps(d), 60)

        return d

    # 获取告警推送方式V1
    def get_push_methods(self):
        '''
            @name 获取可用的告警推送方式
            @author Zhj<2022-07-28>
            @return dict
        '''
        return self.__get_push_methods()

    # 获取告警推送方式V2
    def get_push_methods_v2(self):
        """
            @name 获取告警推送方式V2
            @author Zhj<2023-7-04>
            @return list
        """
        push_methods = self.__get_push_methods()
        push_methods_v2 = []

        for push_method in _push_methods_arrange:
            push_methods_v2.append({
                'type': push_method,
                'name': _push_methods.get(push_method, '--'),
                'is_setup': push_method in push_methods,
            })

        return push_methods_v2

    # 检查告警推送方式-邮件是否设置
    def __check_push_method_mail_setting(self, msg_push_conf):
        '''
            @name 检查告警推送方式-邮件是否设置
            @author Zhj<2023-06-28>
            @param msg_push_conf<dict> 告警推送方式配置
            @return bool
        '''
        if 'mail' not in msg_push_conf:
            return False

        if 'send' not in msg_push_conf['mail']:
            return False

        if 'qq_mail' not in msg_push_conf['mail']['send'] or len(msg_push_conf['mail']['send']['qq_mail']) == 0:
            return False

        if 'hosts' not in msg_push_conf['mail']['send'] or len(msg_push_conf['mail']['send']['hosts']) == 0:
            return False

        if 'port' not in msg_push_conf['mail']['send'] or int(msg_push_conf['mail']['send']['port']) < 1 or int(
                msg_push_conf['mail']['send']['port']) > 65535:
            return False

        if 'receive' not in msg_push_conf['mail']:
            return False

        return True

    def __get_disk_name(self, warning_conf):
        '''
            @name 获取磁盘分区名称和挂载点
            @author Zhj<2022-08-26>
            @param  warning_conf<dict> 告警规则
            @return (string|None, string|None)
        '''
        # 获取磁盘分区名称或挂载点
        disk_name_or_mountpoint = self.get_var(warning_conf.get('sub_type', ''))

        if disk_name_or_mountpoint is None:
            return None, None

        if disk_name_or_mountpoint == 'all':
            return 'all', None

        k = 'mountpoint'

        # 磁盘分区名称
        if re.match(r'^\/dev\/', str(disk_name_or_mountpoint)):
            k = 'name'

        # 磁盘挂载点
        disk_list = self.db_easy('server_details') \
            .where('sid=?', warning_conf.get('sid', 0)) \
            .value('disk_info')

        try:
            disk_list = json.loads(disk_list)
        except:
            return None, None

        for disk_info in disk_list:
            if disk_info.get(k, None) == disk_name_or_mountpoint:
                return disk_info.get('name', None), disk_info.get('mountpoint', None)

        return None, None

    def get_server_ip_by_sid(self, sid):
        '''
            @name   通过获取主机ID获取主机IP
            @author Zhj<2022-07-13>
            @param  sid<integer> 主机ID
            @return string
        '''
        cache_key = 'BT_MONITOR_CACHE_SERVER_IP__{}'.format(str(sid))

        # 优先从缓存中读取
        server_ip = public.cache_get(cache_key)

        if server_ip:
            return server_ip

        server_ip = self.db_easy('servers').where('`sid` = ?', int(sid)).value('ip')

        if server_ip is None:
            return ''

        # 将主机IP写入缓存
        public.cache_set(cache_key, server_ip, 120)

        return server_ip

    def get_server_remark_by_sid(self, sid):
        '''
            @name   通过获取主机ID获取主机备注
            @author Zhj<2022-08-24>
            @param  sid<integer> 主机ID
            @return string
        '''
        cache_key = 'BT_MONITOR_CACHE_SERVER_REMARK__{}'.format(str(sid))

        # 优先从缓存中读取
        server_remark = public.cache_get(cache_key)

        if server_remark:
            return server_remark

        server_remark = self.db_easy('servers').where('`sid` = ?', int(sid)).value('remark')

        if server_remark is None:
            return ''

        # 将主机备注写入缓存
        public.cache_set(cache_key, server_remark, 120)

        return server_remark

    def set_server_port_test_state(self, sid, ports, test_connection=True):
        '''
            @name 设置主机端口连接测试状态
            @author Zhj<2022-08-25>
            @param  sid<integer>                主机ID
            @param  ports<integer|string|list>  端口列表或单个端口
            @param  test_connection<?bool>       是否开启连接测试[可选]
            @return bool
        '''
        # 转为列表
        if not isinstance(ports, list):
            ports = [ports]

        ret = True

        # 更新端口状态
        with monitor_db_manager.db_mgr('server_ports') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('server_ports') \
                    .where('sid=?', sid) \
                    .where_in('port', ports) \
                    .where('status=1') \
                    .update({
                    'test_connection': 1 if test_connection else 0,
                    'update_time': int(time.time()),
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                ret = False

        return ret

    def set_server_port_test_state_with_warning_rules(self, warning_rules, test_connection=True, check_rule=True):
        '''
            @name 根据告警规则设置主机端口连接测试状态
            @author Zhj<2022-08-25>
            @param  warning_rules<dict|list>    告警规则列表或单个告警规则
            @param  test_connection<?bool>      是否开启连接测试[可选]
            @param  check_rule<?bool>           是否检查规则[可选]
            @return bool
        '''
        # 转为列表
        if not isinstance(warning_rules, list):
            warning_rules = [warning_rules]

        # 主机ID => 端口列表
        d = {}

        try:
            for warning_rule in warning_rules:
                if check_rule:
                    # 检查告警规则
                    ok, _ = self.check_rule(warning_rule)

                    if not ok:
                        continue

                # 检查是否端口告警规则
                if warning_rule['type'] != 'port':
                    continue

                # 获取端口号
                port_num = self.get_var(warning_rule['sub_type'])

                # 关闭端口连接测试时
                # 需要检查该端口是否存在告警规则
                # 存在则跳过
                if not test_connection:
                    rule_exists = self.db_easy('warning_configurations') \
                        .where('sid=?', warning_rule['sid']) \
                        .where('type=?', warning_rule['type']) \
                        .where('sub_type=?', warning_rule['sub_type']) \
                        .field('id') \
                        .exists()

                    if rule_exists:
                        continue

                if warning_rule['sid'] not in d:
                    d[warning_rule['sid']] = [port_num]
                    continue

                d[warning_rule['sid']].append(port_num)
        except BaseException as e:
            # 记录异常堆栈
            public.print_exc_stack(e)

            return False

        # 设置主机端口连接测试状态
        for k, v in d.items():
            self.set_server_port_test_state(k, v, test_connection)

        return True

    def get_domain_cert_info(self, domain):
        '''
            @name 获取域名证书信息
            @author Zhj<2023-02-27>
            @param domain<string> 域名
            @return dict
        '''
        import ssl
        import socket

        match_http_scheme = re.compile(r'^https?://', flags=re.IGNORECASE)
        if match_http_scheme.match(domain):
            domain = match_http_scheme.sub('', domain)

        try:
            sock_obj = socket.socket()
            sock_obj.settimeout(5)
            skt = ssl.create_default_context().wrap_socket(sock_obj, server_hostname=domain)
            skt.connect((domain, 443))
            cert_info = skt.getpeercert()
            skt.close()
            sock_obj.close()

            # 获取域名解析IP
            addrinfo = None
            try:
                addrinfo = socket.getaddrinfo(domain, None)[0][-1][0]
            except BaseException:
                pass

            # domain 域名
            # ip 域名解析IP
            # subject 证书信息(字典)
            # subject.commonName 公用名
            # subject.organizationName 组织名
            # issuer 证书签发信息(字典)
            # issuer.commonNane 公用名
            # issuer.organizationName 组织名
            # start_time 证书生效时间(Unix时间戳)
            # end_time 证书失效时间(Unix时间戳)
            return {
                'domain': domain,
                'ip': addrinfo,
                'subject': public.tuple2dict(cert_info['subject']),
                'issuer': public.tuple2dict(cert_info['issuer']),
                'version': cert_info['version'],
                'serial_number': cert_info['serialNumber'],
                'start_time': int(time.mktime(time.strptime(cert_info['notBefore'], '%b %d %H:%M:%S %Y GMT'))),
                'end_time': int(time.mktime(time.strptime(cert_info['notAfter'], '%b %d %H:%M:%S %Y GMT'))),
            }
        except BaseException as e:
            return None

    def push_message(self, content, title=None, push_methods=None, options=None):
        '''
            @name 推送告警消息
            @author Zhj<2023-03-13>
            @param  content<list>               告警内容
            @param  title<?string>              告警标题
            @param  push_methods<?list|string>  告警方式
            @param  options<?dict>              额外选项
            @return bool
        '''
        from core.include.monitor_helpers import message_push_queue
        message_push_queue.add_task_easy(self.__push_message, content, title=title, push_methods=push_methods,
                                         options=options)
        return True

    def __push_message(self, content, title=None, push_methods=None, options=None):
        '''
            @name 推送告警消息
            @author Zhj<2023-03-13>
            @param  content<list>               告警内容
            @param  title<?string>              告警标题
            @param  push_methods<?list|string>  告警方式
            @param  options<?dict>              额外选项
            @return bool
        '''
        if isinstance(content, list) and len(content) == 0:
            raise Exception('参数content必须是list类型，且不能为空')

        msg_obj = MsgModule()
        _args = public.dict_obj()
        _args['title'] = title

        # 获取当前服务器内外网IP
        internal_ips, published_ip = self.get_server_ip()

        # 添加标题
        content.insert(0, '')

        # 添加云监控IP信息
        content.insert(-2, '> 主控IP地址：{}(外) {}(内)'.format(published_ip, internal_ips[0]))

        if push_methods is None or len(push_methods) == 0:
            _args['msg'] = '\n'.join(content)
            res = msg_obj.auto_send(_args)

            if not res or not isinstance(res, dict) or not res.get('status', False):
                return False

            return True

        # 获取可用的推送方式
        possible_push_methods = self.get_push_methods().keys()

        push_res_list = []

        if isinstance(push_methods, str):
            push_methods = push_methods.split(',')

        # 使用不同推送方式推送告警
        for push_method in push_methods:
            if push_method not in possible_push_methods:
                continue

            args_dup = public.dict_obj()
            args_dup['title'] = _args['title']
            args_dup['msg'] = _args['msg']
            args_dup['msg_type'] = push_method

            # 兼容不同推送方式的换行符
            if args_dup['msg_type'] == 'mail':
                # 邮件标题
                if options and 'mail_title' in options and isinstance(options['mail_title'], str) and len(
                        options['mail_title']) > 0:
                    args_dup['title'] = options['mail_title']
                args_dup['msg'] = '<pre style="margin: 0;">{}</pre>'.format('\n'.join(content))
            elif args_dup['msg_type'] == 'dingding':
                args_dup['msg'] = '\n\n'.join(content)
            else:
                args_dup['msg'] = '\n'.join(content)

            # 推送消息
            res = msg_obj.send(args_dup)

            if not res or not isinstance(res, dict) or not res.get('status', False):
                push_res_list.append(False)
                continue

            push_res_list.append(True)

        # 所有推送方式全部推送失败
        if len(list(filter(lambda i: i, push_res_list))) < 1:
            return False

        return True

    # 获取队列里的告警信息 并进行延时分组处理
    def get_warning_info(self):
        """
            @name 获取队列里的告警信息
            @author lt<2023-06-26>
            @return None
        """
        from core import cache
        delay_cache_key = "WARNING_INFO_CONVERGENCE_DELAY"
        # 队列里的告警信息
        queue_warning_info = []
        # 即时告警列表 --直接推送
        nodelay_warning_list = []
        # 非首次告警列表 --判断最近一次告警时间是否超过两分钟
        not_first_warning_list = []
        # 延时告警列表 --两分钟内有告警放入
        delay_warning_list = []
        # 两分钟前的时间戳
        two_minutes_ago = int(time.time()) - 120

        # 获取队列里的告警信息
        try:
            while True:
                item = self.__WARNING_INFO_QUEUE.get(False)
                if item:
                    queue_warning_info.extend(item)
        except queue.Empty:
            pass

        # 空队列退出
        if not isinstance(queue_warning_info, list) or len(queue_warning_info) < 1:
            return False

        # 首次告警判断 (首次不延时 放入队列)
        first_sid, _ = self.warning_first(queue_warning_info)

        # 队列里的告警信息
        for warning in queue_warning_info:
            # 首次告警不延时 放即时
            if warning['host_sid'] in first_sid:
                nodelay_warning_list.append(warning)
            else:
                # 非首次告警的主机
                not_first_warning_list.append(warning)

        # 非首次告警的 分组
        warning_list = self.warning_group(not_first_warning_list)

        no_delay_sid = []  # 满足等待的sid
        delay_sid = []  # 需要延时的sid

        # 非首次告警的    查看sid中的最大时间是否超过了两分钟前
        for key, v in warning_list.items():
            # v 中的最大时间戳
            max_time = max([item['create_time'] for item in v])
            # 两分钟内都没有告警
            if max_time < two_minutes_ago:
                no_delay_sid.append(key)
                # 放入即时告警列表
                nodelay_warning_list.extend(v)

            else:  # 需要延时的
                delay_sid.append(key)
                # 延时告警列表
                delay_warning_list.extend(v)

        # 延时缓存里的告警信息
        cache_warning_info = cache.get(delay_cache_key)
        if cache_warning_info:
            for warning in cache_warning_info:
                # 在缓存里查找: 首次告警的sid 和 不需要延时的sid
                if warning['host_sid'] in first_sid or warning['host_sid'] in no_delay_sid:
                    nodelay_warning_list.append(warning)
                else:
                    delay_warning_list.append(warning)

        # 删除之前的延时告警缓存
        cache.delete(delay_cache_key)
        # 新的延时告警信息放入缓存
        cache.set(delay_cache_key, delay_warning_list, 120)

        # 分组
        nodelay_warning_list = self.warning_group(nodelay_warning_list)
        # 需要告警的信息放入队列
        # nodelay_warning_list = {78:[], 88:[]}
        self.__WARNING_INFO_QUEUE_DELAY.put(nodelay_warning_list)

        # # 检验--- 测试后删除
        # info = cache.get(cache_key)
        # public.print_log('即时告警---{}'.format(info), )
        # public.print_log('即时告警类型---{}'.format(type(info)), )
        return True

    def warning_group(self, warning_info):
        '''
            @name 根据host_sid分组
            @author lt<2023-06-26>
            @param warning_info<list> 告警信息列表
            @return list   分组后的告警信息列表
        '''
        # 根据host_sid分组
        from collections import defaultdict
        # warning_info = [{'host_sid': 75,'rules': {},'cur_val': None,'create_time': 1687683953},
        #                 {'host_sid': 75,'rules': {},'cur_val': None,'create_time': 1687683953},
        #                 {'host_sid': 88,'rules': {},'cur_val': None,'create_time': 1687683953},]
        # 分组后
        # warning_info = {75: [{'host_sid': 75, 'rules': {}, 'cur_val': None, 'create_time': 1687683953},
        #                      {'host_sid': 75, 'rules': {}, 'cur_val': None, 'create_time': 1687683953}],
        #                 88: [{'host_sid': 88, 'rules': {}, 'cur_val': None, 'create_time': 1687683953}]}

        # public.print_log('2222222222222warning_info---{}'.format(warning_info), )
        warning_list = defaultdict(list)
        for item in warning_info:
            warning_list[item['host_sid']].append(item)
        lists = dict(warning_list)

        return lists

    # 首次告警判断
    def warning_first(self, warning_info):
        '''
            @name 首次告警判断 返回非首次告警的sid列表
            @author lt<2023-06-26>
            @param warning_info<list> 告警信息列表
            @return tuple   (首次告警sid列表, 非首次告警sid列表)
        '''
        # 当天零点时间戳
        today_zero = int(time.mktime(time.strptime(time.strftime('%Y-%m-%d 00:00:00'), '%Y-%m-%d %H:%M:%S')))
        # 所有告警sid 去重后的列表
        sid_list = list(set(warning_info[i]['host_sid'] for i in range(len(warning_info))))

        # 告警日志查询有无当天的告警记录 有则记录 需要延时
        warned_sid = self.db_easy('warning_tasks') \
            .field('id', 'sid', 'create_time') \
            .where_in('sid', sid_list) \
            .where('create_time >?', today_zero) \
            .column('sid')
        # 无当天告警记录 则为首次告警
        first_warn_sid = [i for i in sid_list if i not in warned_sid]
        return first_warn_sid, warned_sid

    # 生成告警规则名称
    def build_rule_name(self, warning_rule):
        setting = self.__get_setting(self.__build_setting_name(warning_rule))
        if setting is None:
            return '--'

        return setting['__name']

    # 获取告警规则对应的主机Ip
    def get_host_ip(self, warning_conf):
        '''
             @param  warning_config<dict>   告警规则
             @return string  符合告警规则的主机ip
        '''
        server_info = self.db_easy('servers').field('sid', 'ip', 'remark').where('sid', warning_conf['sid']).find()

        if server_info is None:
            return '云安全监控告警'

        return server_info['ip']

    # def __enter__(self):
    #     return self
    #
    # def __exit__(self, exc_type, exc_val, exc_tb):
    #     self.db_close()
    #
    # def __del__(self):
    #     self.db_close()
    #
    # def db_autocommit(self, autocommit = True):
    #     '''
    #         @name 设置自动提交事务状态
    #         @author Zhj<2022-07-21>
    #         @param  autocommit<?bool>   是否自动提交事务
    #         @return self
    #     '''
    #     if isinstance(self.__DB_MONITOR, Db):
    #         self.__DB_MONITOR.autocommit(autocommit)
    #
    #     return self
    #
    # def db_commit(self):
    #     '''
    #         @name 提交事务
    #         @author Zhj<2022-07-21>
    #         @return bool
    #     '''
    #     # 提交事务
    #     if isinstance(self.__DB_MONITOR, Db):
    #         return self.__DB_MONITOR.commit()
    #
    #     return False
    #
    # def db_rollback(self):
    #     '''
    #         @name 回滚事务
    #         @author Zhj<2022-07-21>
    #         @return bool
    #     '''
    #     # 回滚事务
    #     if isinstance(self.__DB_MONITOR, Db):
    #         return self.__DB_MONITOR.rollback()
    #
    #     return False
    #
    # def db_close(self):
    #     '''
    #         @name 将数据库连接放回连接池
    #         @author Zhj<2022-07-21>
    #         @return self
    #     '''
    #     # 将数据库连接放回连接池
    #     if isinstance(self.__DB_MONITOR, Db):
    #         self.__DB_MONITOR.close()
    #         self.__DB_MONITOR = None
    #
    #     return self
    #
    # def db_easy(self, table_name = None):
    #     '''
    #         @name 重写父类db_easy()方法
    #         @author Zhj<2022-07-21>
    #         @param  table_name<?string> 表名[可选]
    #         @return core.include.sqlite_easy.SqliteEasy
    #     '''
    #     # 获取数据库连接对象
    #     if not isinstance(self.__DB_MONITOR, Db):
    #         self.__DB_MONITOR = public.sqlite_easy('monitor')
    #
    #     # 获取查询构造器对象
    #     query = self.__DB_MONITOR.query()
    #
    #     # 设置表名
    #     if table_name is not None:
    #         query.name(table_name)
    #
    #     return query
