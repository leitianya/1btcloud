# encoding: utf-8
import re, time, json, os, copy, random
from core import g, cache
import core.include.public as public
from core.include.monitor_helpers import monitor_db_manager, basic_monitor_obj, warning_obj
from concurrent.futures import ThreadPoolExecutor
import datetime
from collections import defaultdict

class main:
    '''
        @name 安全监控
        @author Zhj<2023-03-21>
    '''

    # 获取服务器列表 (简易数据) 只有授权的 linux
    def get_server_list_simple(self, args):
        '''
            @name   获取服务器列表 (简易数据) 只有授权的 linux
            @return list
        '''
        servers = warning_obj.db_easy('servers') \
            .field('sid', 'ip', 'remark') \
            .where('is_authorized', 1) \
            .where('type', 0) \
            .select()

        # 组装主机在线状态
        for server_info in servers:
            _, _, server_info['status'] = basic_monitor_obj.cache_server_status(server_info['sid'])

        return public.success(servers)

    # 获取服务器列表
    def get_server_list(self, args):
        '''
            @name 获取主机列表
            @author Zhj<2023-01-10>
            @param args<dict> 请求参数列表
            @return dict
        '''
        server_authorized = g.get("server_list", [])

        if not server_authorized:
            return public.success({
                'total': 0,
                'list': [],
            })

        group_id = args.get('group_id', None)
        server_type = args.get('type', None)

        query = basic_monitor_obj.db_easy('servers s') \
            .left_join('server_group sg', 's.group_id=sg.id') \
            .left_join('server_warning_template_package_merge m', 's.sid=m.sid') \
            .left_join('warning_template_packages p', 'm.package_id=p.id') \
            .left_join('server_details sys', 's.sid = sys.sid') \
            .where_in('s.sid', server_authorized) \
            .where('s.type', 0) \
            .order('s.sid', 'desc') \
            .field('s.sid', 'sg.name as group_name', 's.ip', 's.remark', 's.is_authorized', 's.status',
                   'ifnull(p.name, \'\') as cur_template', 's.type', 'sys.host_info','s.ssh_info')

        if server_type is not None:
            query.where('s.type', int(server_type))

        if group_id is not None and re.match(r'^\d+(?:,\d+)*$', str(group_id)):
            query.where_in('group_id', str(group_id).split(','))

        def query_handler(query, keyword):
            k = '%{}%'.format(keyword)

            # 主机IP与主机备注模糊搜索
            query.where('s.remark like ? OR s.ip like ?', (k, k,))

        public.add_retrieve_keyword_query(query, args, query_handler)

        ret = public.simple_page(query, args)

        for item in ret['list']:
            # 更新主机状态
            _, _, item['status'] = basic_monitor_obj.cache_server_status(item['sid'])
            item['host_info'] = json.loads(item['host_info'])

        return public.success(ret)

    # 获取漏洞扫描列表
    def get_bug_list(self, args):
        '''
            @name 获取漏洞扫描列表
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        bug_type = args.get('bug_type', None)
        level = args.get('level', None)
        status = args.get('status', None)
        usable = args.get('usable', None)


        if sid is None:
            return public.error('缺少参数：sid')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            query = db.query().name('server_bugs')

            if status is not None and len(str(status)) > 0:
                query.where('status', int(status))

            if level is not None:
                query.where('level', int(level))

            if bug_type is not None:
                query.where('type', bug_type)

            if usable is not None:
                query.where('usable', int(usable))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询cve编号
                if re.match(r'^cve-\d+-\d+', keyword, flags=re.IGNORECASE):
                    query.where('`cve_id` like ?', '{}%'.format(keyword))
                    return

                # 查询标题 OR 软件名称或工具名称 OR 文件路径 OR 漏洞特征 OR 漏洞描述 OR 修复建议 OR 处理人备注
                where_or = [
                    '`vuln_name` like ?',
                    '`soft_name` like ?',
                    '`file_path` like ?',
                    '`tag` like ?',
                    '`suggestions` like ?',
                    '`fix_remark` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 添加排序
            public.add_retrieve_sort_query(query, args)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        ignore_operators = None  # 忽略人
        handled_operators = None  # 处理人

        with monitor_db_manager.db_mgr('safety') as db:
            ignore_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['ignore_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['ignore_operator_username'] = ignore_operators.get(item['ignore_operator'], '--')
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')
            try:
                item['tag'] = json.loads(item['tag'])
            except:
                item['tag'] = []

        return public.success(ret)

    # 忽略漏洞
    def ignore_bug(self, args):
        '''
            @name 忽略漏洞
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if ignored is None:
            return public.error('缺少参数：ignored')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')
        num = len(vuln_id)

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            # 查询原来漏洞等级
            level_num = db.query() \
                .name('server_bugs') \
                .where_in('vuln_id', vuln_id) \
                .field('level', 'count(*) as `level_num`') \
                .group('level') \
                .select()

            db.query() \
                .name('server_bugs') \
                .where_in('vuln_id', vuln_id) \
                .update({
                    'status': int(ignored),
                    'ignore_operator': uid,
                    'ignore_time': int(time.time()),
                })

        with monitor_db_manager.db_mgr('server_bug_total') as db:
            # 开启事务
            db.autocommit(False)
            query = db.query() \
                .name('server_bug_total') \
                .where('sid', sid)
            if ignored == '1':
                query.increment('ignored', num)
                for i in level_num:
                    query.decrement('level_{}'.format(i['level']), i['level_num'])

            else:  # 撤回忽略
                query.decrement('ignored', num)
                for i in level_num:
                    query.increment('level_{}'.format(i['level']), i['level_num'])
            query.update()

            db.commit()

        # 记录日志
        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            sss = db.query() \
                .name('server_bugs') \
                .where_in('vuln_id', vuln_id) \
                .field('vuln_name') \
                .select()
        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()

        for i in sss:
            public.WriteLog('安全监控漏洞扫描',
                            '忽略【%s（%s）】下的【%s】' % (server_info['ip'], server_info['remark'], i['vuln_name']))

        return public.success('操作成功')

    # 处理漏洞
    def handle_bug(self, args):
        '''
            @name 处理漏洞
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        remark = args.get('remark', '')
        handled = args.get('handled', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if handled is None:
            return public.error('缺少参数：handled')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')
        num = len(vuln_id)

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            db.query() \
                .name('server_bugs') \
                .where_in('vuln_id', vuln_id) \
                .update({
                'status': 2 if int(handled) == 1 else 0,
                'handle_operator': uid,
                'fix_remark': remark,
                'handled_time': int(time.time()),
            })

        # 同步统计表
        with monitor_db_manager.db_mgr('server_bug_total') as db:
            # 开启事务
            db.autocommit(False)

            query = db.query() \
                .name('server_bug_total') \
                .where('sid', sid)

            if int(handled) == 1:  # 处理   handled已处理数量增加
                query.increment('handled', num)
            else:  # 撤回处理 已处理数量减少
                query.decrement('handled', num)
            query.update()

            db.commit()

        # 记录日志
        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            sss = db.query() \
                .name('server_bugs') \
                .where_in('vuln_id', vuln_id) \
                .field('vuln_name') \
                .select()

        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()

        for i in sss:  # 忽略【服务器IP(备注)】下的【漏洞名】
            public.WriteLog('安全监控漏洞扫描',
                            '处理【%s（%s）】下的【%s】' % (server_info['ip'], server_info['remark'], i['vuln_name']))

        return public.success('操作成功')

    # 重新扫描漏洞
    def re_scan_bug(self, args):
        '''
            @name 重新扫描漏洞
            @author Zhj<2023-03-22>
            @param  args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')

        server_id = public.get_serverid_bysid(sid)

        ret = []

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for v in vuln_id:
                params = {
                    'vuln_id': v,
                }
                f = t.submit(self.__re_scan_bug_helper, server_id, params)
                fs.append(f)

            for f in fs:
                if ret is None:
                    continue
                ret.append(f.result())

        if len(ret) == 0:
            return public.error('扫描失败，请重试~')

        new_ret = []
        for item in ret:
            if isinstance(item, str):
                try:
                    item = json.loads(item)
                except:
                    continue

            if 'body' not in item or not isinstance(item['body'], list) or len(item['body']) < 1:
                continue

            new_ret.extend(item['body'])

        if len(new_ret) > 0:
            # 更新主机漏洞列表
            basic_monitor_obj.update_server_bugs(sid, new_ret)

        # 记录日志
        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()
        public.WriteLog('安全监控漏洞扫描', '重新扫描【%s（%s）】的漏洞 扫描漏洞数量 %d 个' %
                        (server_info['ip'], server_info['remark'], len(vuln_id)))

        return public.success('扫描成功')

    # 重新扫描漏洞(全部)
    def re_scan_bug_all(self, args):
        '''
            @name 重新扫描漏洞(全部)
            @author Zhj<2023-03-22>
            @param  args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            'vul_scan',
            'VulScan',
            timeout=60)

        data = public.get_agent_msg(res)

        if not data:
            return public.error('扫描失败，请重试~')

        # 更新主机漏洞列表
        basic_monitor_obj.update_server_bugs(sid, data.get('body', []))
        # 记录日志
        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()
        public.WriteLog('安全监控漏洞扫描', '重新扫描【%s（%s）】下的全部漏洞' %
                        (server_info['ip'], server_info['remark']))
        return public.success('扫描成功')


    # 重新扫描漏洞(子线程处理函数)
    def __re_scan_bug_helper(self, server_id, params):
        res = public.send_agent_msg(
            server_id,
            'vul_scan',
            'ScanOne',
            timeout=60,
            pdata=public.g_pdata(params))

        data = public.get_agent_msg(res)

        if not data:
            return None

        return data

    # 挖矿木马扫描
    # 获取主机挖矿木马列表
    def get_mining_list(self, args):
        '''
            @name 获取主机挖矿木马列表
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        mining_type = args.get('mining_type', None)
        status = args.get('status', None)
        usable = args.get('usable', None)

        if sid is None:
            return public.error('缺少参数：sid')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            query = db.query().name('server_minings')

            if status is not None and len(str(status)) > 0:
                query.where('status', int(status))

            if mining_type is not None:
                query.where('type', mining_type)

            if usable is not None:
                query.where('usable', int(usable))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询标题 OR 软件名称或工具名称 OR 文件路径 OR 漏洞特征 OR 漏洞描述 OR 修复建议 OR 处理人备注
                where_or = [
                    '`title` like ?',
                    '`ps` like ?',
                    '`suggestions` like ?',
                    '`fix_remark` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 添加排序
            public.add_retrieve_sort_query(query, args)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        ignore_operators = None
        handled_operators = None

        with monitor_db_manager.db_mgr('safety') as db:
            ignore_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['ignore_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['ignore_operator_username'] = ignore_operators.get(item['ignore_operator'], '--')
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')
            try:
                item['process_info'] = json.loads(item['process_info'])
            except:
                item['process_info'] = None

        return public.success(ret)

    # 忽略主机挖矿木马
    def ignore_mining(self, args):
        '''
            @name 忽略主机挖矿木马
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if ignored is None:
            return public.error('缺少参数：ignored')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：vuln_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            db.query() \
                .name('server_minings') \
                .where_in('vuln_id', vuln_id) \
                .update({
                'status': int(ignored),
                'ignore_operator': uid,
                'ignore_time': int(time.time()),
            })

        # 记录日志
        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            sss = db.query() \
                .name('server_minings') \
                .where_in('vuln_id', vuln_id) \
                .field('title') \
                .select()

        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()
        for i in sss:
            public.WriteLog('安全监控挖矿木马',
                            '忽略【%s（%s）】下的【%s】' % (server_info['ip'], server_info['remark'], i['title']))

        return public.success('操作成功')

    # 处理主机挖矿木马
    def handle_mining(self, args):
        '''
            @name 处理主机挖矿木马
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        remark = args.get('remark', '')
        handled = args.get('handled', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if handled is None:
            return public.error('缺少参数：handled')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：vuln_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            db.query() \
                .name('server_minings') \
                .where_in('vuln_id', vuln_id) \
                .update({
                'status': 2 if int(handled) == 1 else 0,
                'handle_operator': uid,
                'fix_remark': remark,
                'handled_time': int(time.time()),
            })

        # 记录日志
        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            sss = db.query() \
                .name('server_minings') \
                .where_in('vuln_id', vuln_id) \
                .field('title') \
                .select()

        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()
        for i in sss:
            public.WriteLog('安全监控挖矿木马',
                            '处理【%s（%s）】下的【%s】' % (server_info['ip'], server_info['remark'], i['title']))

        return public.success('操作成功')

    # 重新扫描主机挖矿木马
    def re_scan_mining_all(self, args):
        '''
            @name 重新扫描主机挖矿木马
            @author Zhj<2023-03-28>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            'detect_mining',
            'VulScan',
            timeout=60)

        data = public.get_agent_msg(res)

        if not data:
            return public.error('扫描失败，请重试~')

        # 更新主机挖矿木马列表
        basic_monitor_obj.update_server_minings(sid, data.get('body', []))
        # 记录日志
        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()
        public.WriteLog('安全监控挖矿木马', '重新扫描【%s（%s）】的挖矿木马 ' %
                        (server_info['ip'], server_info['remark']))
        return public.success('扫描成功')

##########################################################
    # 病毒扫描帮助函数
    def __scan_task_help(self, sid, action, params=None):
        '''
            @name 病毒扫描帮助函数
            @author Zhj<2023-04-03>
            @param sid<int>         主机ID
            @param action<string>   接口名称
            @param params<?dict>    请求参数
            @return None|dict
        '''
        return self.__send_agent_msg(sid, 'scanning', action, params)

    # 向Agent端发送请求
    def __send_agent_msg(self, sid, plugin_name, action, params=None):
        pdata = {}

        if params is not None and isinstance(params, dict):
            pdata.update(params)

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            plugin_name,
            action,
            timeout=60,
            pdata=public.g_pdata(pdata))

        if not res:
            return None

        # public.print_log(res, _level='error')

        if not isinstance(res.get('body', {}), dict):
            return res['body']

        return res.get('body', {}).get('body', None)

    # 检查客户端返回的操作是否成功
    def __check_agent_response_success(self, res):
        '''
            @name 检查客户端返回的操作是否成功
            @author Zhj<2023-04-27>
            @param  res<dict> 客户端响应的数据
            @return bool
        '''
        if 'success' not in res:
            return True

        return bool(res['success'])

    # 打印日志
    def __log(self, content):
        with open('/www/server/bt-monitor/logs/ppp.log', 'a') as fp:
            fp.write('{}\n'.format(content))

    # 更新扫描任务进度
    def __update_scan_task_progress(self, task_id, sid_list=None):
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 没有传主机ID列表时从数据库获取
            if sid_list is None:
                sid_list = db.query() \
                    .name('server_malicious_scan_task') \
                    .where('task_id', task_id) \
                    .column('sid')

            total_progress = db.query() \
                .name('server_malicious_scan_task') \
                .where('task_id', task_id) \
                .where_in('sid', sid_list) \
                .where('status > ?', 0) \
                .value('ifnull(sum(`progress`), 0)')

            if total_progress is None:
                total_progress = 0

            sid_list_len = len(sid_list)
            sid_list = db.query() \
                .name('server_malicious_scan_task') \
                .where('task_id', task_id) \
                .where_in('sid', sid_list) \
                .where('status', 0) \
                .column('sid')

        # 扫描任务已经完成
        if not sid_list or len(sid_list) == 0:
            return

        cur_time = int(time.time())
        update_data = {}
        finished_count = sid_list_len - len(sid_list)
        latest_finished_time = 0
        result_insert_data = []
        malicious_file_set = set()
        malicious_dir_set = set()
        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []
            fs2 = []

            # 获取任务进度
            for sid in sid_list:
                fs.append((t.submit(self.__scan_task_help, sid, 'GetIDInfo', {
                    'id': str(task_id),
                }), sid))

            for (f, sid) in fs:
                res = f.result()

                if not res:
                    continue

                # self.__log('>>> get_progress[{}]: {}'.format(sid, res))

                update_data[sid] = {
                    'scan_pid': res['scan_pid'],
                    'scan_process_exists': int(res['pid_status']),
                    'progress': 0 if int(res['count']) == 0 else round(res['scan_count'] / res['count'] * 10000),
                    'start_time': res['start_time'],
                    'finish_time': 0 if res['pid_status'] else res['end_time'],
                }

                total_progress += update_data[sid]['progress']

                if update_data[sid]['finish_time'] > latest_finished_time:
                    latest_finished_time = update_data[sid]['finish_time']

                # 当扫描完成时，获取扫描结果
                if not res['pid_status']:
                    if int(res['scan_count']) >= int(res['count']):
                        update_data[sid]['status'] = 1
                        if int(res['count']) == 0:
                            update_data[sid]['progress'] = 10000
                            total_progress += 10000
                    else:
                        update_data[sid]['status'] = 2

                    finished_count += 1
                    fs2.append((t.submit(self.__scan_task_help, sid, 'GetRe', {
                        'id': str(task_id),
                    }), sid, update_data[sid]['finish_time'] or cur_time))

            fs = None
            del (fs,)

            for (f, sid, finish_time) in fs2:
                res = f.result()
                # public.print_log('病毒!!!!!!!!!!!!!!------{}', _level='error')
                # public.print_log('病毒!!!!!!!!!!!!!!------{}', _level='error')
                # public.print_log('病毒!!!!!!!!!!!!!!------{}', _level='error')
                # public.print_log('病毒!!!!!!!!!!!!!!------{}', _level='error')
                # public.print_log('病毒!!!!!!!!!!!!!!------{}'.format(res), _level='error')

                if not res or 'data' not in res:
                    continue

                # self.__log('>>> get_result[{}]: {}'.format(sid, res))

                # 恶意文件集合
                malicious_files = set()

                for item in res.get('data', '').split('\n'):
                    try:
                        malicious_file = json.loads(item.strip())
                    except:
                        continue

                    if 'path' not in malicious_file or len(malicious_file['path']) == 0:
                        continue

                    malicious_files.add(malicious_file['path'])

                for malicious_file in malicious_files:
                    malicious_dir = os.path.dirname(malicious_file)
                    result_insert_data.append({
                        'sid': sid,
                        'task_id': task_id,
                        'level': 2,
                        'file_path': malicious_file,
                        'file_dir': malicious_dir,
                        'create_time': finish_time,
                    })
                    malicious_file_set.add(malicious_file)
                    malicious_dir_set.add(malicious_dir)

            fs2 = None
            del (fs2,)

        # self.__log('>>> total_progress: {}  server_count: {}'.format(total_progress, sid_list_len))

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 关闭事务自动提交
            db.autocommit(False)

            try:
                # 扫描任务状态
                task_status = 0
                task_finish_time = 0
                if finished_count == sid_list_len:
                    task_status = 1 if round(total_progress / sid_list_len) > 0 else 2
                    task_finish_time = latest_finished_time

                # 更新扫描任务状态与进度
                db.query() \
                    .name('malicious_scan_tasks') \
                    .where('id', task_id) \
                    .where('status', 0) \
                    .update({
                    'status': task_status,
                    'scan_progress': round(total_progress / sid_list_len),
                    'finish_time': task_finish_time,
                })

                for (sid, up_data) in update_data.items():
                    db.query() \
                        .name('server_malicious_scan_task') \
                        .where('task_id', task_id) \
                        .where('sid', sid) \
                        .where('status', 0) \
                        .update(up_data)

                # 新增扫描结果
                if len(result_insert_data) > 0:
                    # 检查白名单
                    white_list_file = db.query() \
                        .name('malicious_white_lists') \
                        .where('is_dir', 0) \
                        .where_in('file_path', list(malicious_file_set)) \
                        .field('id', 'file_path') \
                        .column('id', 'file_path')


                    # # 使用白名单MD5检查
                    # white_list_file_md5 = db.query() \
                    #     .name('malicious_white_lists') \
                    #     .where('is_dir', 0) \
                    #     .field('id', 'file_md5') \
                    #     .column('id', 'file_md5')

                    white_list_dir = db.query() \
                        .name('malicious_white_lists') \
                        .where('is_dir', 1) \
                        .where_in('file_path', list(malicious_dir_set)) \
                        .field('id', 'file_path') \
                        .column('id', 'file_path')

                    # self.__log(white_list_file)
                    # self.__log(white_list_dir)

                    for item in result_insert_data:

                        # self.__log(item)
                        try:
                            # 检查目录
                            if item['file_dir'] in white_list_dir:
                                item['white_list_id'] = white_list_dir[item['file_dir']]
                                item['status'] = 2
                                continue

                            # 检查文件
                            if item['file_path'] in white_list_file:
                                item['white_list_id'] = white_list_file[item['file_path']]
                                item['status'] = 2
                                continue

                            # # 检查文件MD5  todo: 优化 改MD5判断
                            # if item['file_md5'] in white_list_file_md5:
                            #     item['white_list_id'] = white_list_file_md5[item['file_md5']]
                            #     continue

                            # 没有在白名单内
                            item['white_list_id'] = 0
                        finally:
                            del (item['file_dir'],)

                    # 批量插入扫描结果
                    db.query() \
                        .name('malicious_scan_results') \
                        .insert_all(result_insert_data, option='replace')

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

    # 统计病毒扫描
    def get_scan_dashboard(self, args):
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 统计扫描任务
            task_statistics = db.query() \
                .name('malicious_scan_tasks') \
                .field('sum(case `status` when 0 then 1 else 0 end) as `scanning`',
                       'sum(case `status` when 1 then 1 else 0 end) as `finish`',
                       'sum(case `status` when 2 then 1 else 0 end) as `fail`',
                       'max(`create_time`) as `last_time`') \
                .find()

            # 统计扫描结果
            result_statistics = db.query() \
                .name('malicious_scan_results') \
                .field('count(*) as `total`',
                       'sum(case when `level` = 3 and `status` = 0 and `white_list_id` = 0 then 1 else 0 end) as `danger`',
                       'sum(case when `level` = 2 and `status` = 0 and `white_list_id` = 0 then 1 else 0 end) as `high`',
                       'sum(case when `level` = 1 and `status` = 0 and `white_list_id` = 0 then 1 else 0 end) as `middle`',
                       'sum(case when `level` = 0 and `status` = 0 and `white_list_id` = 0 then 1 else 0 end) as `low`',
                       'sum(case when `status` = 2 and `white_list_id` = 0 then 1 else 0 end) as `ignored`',
                       'sum(case when `status` = 1 and `white_list_id` = 0 then 1 else 0 end) as `handled`',
                       'sum(case when `status` = 0 and `white_list_id` = 0 then 1 else 0 end) as `unhandled`',
                       'sum(case when `white_list_id` > 0 then 1 else 0 end) as `in_white`') \
                .find()

            # 统计白名单数量
            whites = db.query() \
                .name('malicious_white_lists') \
                .count()

            # 统计隔离箱数量
            sub_query = db.query() \
                .name('malicious_scan_results') \
                .where('isolate_id=?', 1) \
                .field('min(`id`) as `id`', 'file_path', 'status', 'create_time', 'isolate_id',
                       'sid', 'handle_operator', 'ignore_operator') \
                .group('sid,file_path') \
                .build_sql(True)

            isolators = db.query() \
                .from_sub_query(sub_query) \
                .count()

        ret = {
            'whites': whites,
            'isolators': isolators
        }

        ret.update(task_statistics)
        ret.update(result_statistics)

        return public.success(ret)

    # 添加扫描任务
    def add_scan_task(self, args):
        '''
            @name 添加扫描任务
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''

        return self.add_scan_task_v2(args)

        sid = args.get('sid', None)
        scan_dir = args.get('scan_dir', None)  # 扫描目录
        scan_type = args.get('scan_type', 0)  # 扫描类型 0-全盘扫描 1-快速扫描 2-指定目录扫描
        name = args.get('name', None)  # 任务名称
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if name is None:
            return public.error('缺少参数：name')

        if len(name) == 0:
            return public.error('任务名称不能为空')

        if scan_dir is None or len(scan_dir) == 0:
            if int(scan_type) == 0:
                scan_dir = '/'
            elif int(scan_type) == 1:
                scan_dir = '/www'
            else:
                return public.error('缺少参数：scan_dir')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
            return public.error('参数：sid格式错误')

        sid = str(sid).split(',')

        # 添加扫描任务
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            if db.query().name('malicious_scan_tasks').where('name', name).exists():
                return public.error('任务名称【{}】已经存在'.format(name))

            # 关闭事务自动提交
            db.autocommit(False)

            try:
                task_id = db.query().name('malicious_scan_tasks').insert({
                    'creator': uid,
                    'scan_dir': scan_dir,
                    'scan_type': int(scan_type),
                    'name': name,
                })

                insert_data = []

                for item in sid:
                    insert_data.append({
                        'task_id': task_id,
                        'sid': item,
                    })

                db.query().name('server_malicious_scan_task').insert_all(insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for item in sid:
                fs.append(t.submit(self.__scan_task_help, item, 'ScanDir', {
                    'dir': scan_dir,
                    'id': str(task_id),
                }))

            for f in fs:
                f.result()

        # 记录日志
        public.WriteLog('安全监控病毒扫描', '添加扫描任务【%s】扫描目录【%s】' % (name, scan_dir))

        return public.success('添加扫描任务成功')

    # 添加任务与快速扫描任务
    def add_scan_task_v2(self, args):
        '''
            @name 添加扫描任务
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        scan_dir = args.get('scan_dir', None)  # 扫描目录
        scan_type = args.get('scan_type', 0)  # 扫描类型 0-全盘扫描 1-快速扫描 2-指定目录扫描
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
            return public.error('参数：sid格式错误')

        if sid == '-1':
            # sid = self.__get_server_sid()
            # sid = warning_obj.db_easy('servers') \
            #     .field('sid', ) \
            #     .where('is_authorized', 1) \
            #     .where('type', 0) \
            #     .where('status', 1) \
            #     .column('sid')

            servers = warning_obj.db_easy('servers') \
                .field('sid', 'ip', 'remark') \
                .where('is_authorized', 1) \
                .where('type', 0) \
                .select()

            # 组装主机在线状态
            for server_info in servers:
                _, _, server_info['status'] = basic_monitor_obj.cache_server_status(server_info['sid'])

            # 过滤掉离线的主机
            sid = [info['sid'] for info in servers if info['status'] == 1]


        else:
            sid = str(sid).split(',')

        if sid is None or len(sid) == 0:
            return public.error('没有可用的主机')

        if scan_dir is None or len(scan_dir) == 0:
            if int(scan_type) == 0:
                scan_dir = '/'
            elif int(scan_type) == 1:
                # scan_dir = '/www'
                scan_dir = ['/www', '/root', '/tmp', '/home']
            else:
                return public.error('缺少参数：scan_dir')

        # 停止之前的扫描任务
        self.stop_scan_task_v2()

        # 添加扫描任务
        task_ids = self.__add_scan_help(sid, scan_dir, scan_type, uid, 0)
        # public.print_log('添加扫描任务, 即将调用被控执行', _level='error')

        # 推到队列 -- 调用被控执行
        from core.include.monitor_helpers import async_call_queue
        async_call_queue.add_task_easy(self.__exec_task_help, sid, task_ids)

        public.WriteLog('安全监控病毒扫描', '添加扫描任务, 扫描目录【%s】' % scan_dir)

        return public.success('添加扫描任务成功')

    # 添加扫描任务
    def __add_scan_help(self, sid, scan_dir, scan_type, uid, is_automatic):
        """
            @name 添加扫描任务,主机任务关联表
            @param sid<list> sid列表
            @param scan_dir<list?> 扫描目录
            @param scan_type<int> 扫描类型
            @param uid<int> 用户id
            @param is_automatic<int> 是否自动扫描任务
            @return list  task_dirs列表  [(task_id, scan_dir单目录),(task_id, scan_dir), ...]
        """
        # 随机数字4位
        random_int = random.randint(1000, 9999)

        # sid = str(sid).split(',')

        if isinstance(scan_dir, str):
            scan_dir = [scan_dir]

        # 添加扫描任务
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # sql_sid = db.query().name('server_malicious_scan_task').column('sid')
            # diff = list(set(servers) - set(sql_sid))
            # flags = False
            # if len(diff) > 0 or not flags:
                # 关闭事务自动提交
            db.autocommit(False)
            try:
                task_dirs = []
                for temp in scan_dir:
                    task_id = db.query().name('malicious_scan_tasks').insert({
                        'creator': uid,
                        'scan_dir': temp,
                        'scan_type': int(scan_type),
                        'name': '任务{}_{}'.format(time.strftime('%Y_%m_%d'), random_int),
                        'is_automatic': int(is_automatic),
                    })
                    task_dirs.append((task_id, temp))

                insert_data = []

                for item in sid:
                    for task, _ in task_dirs:
                        insert_data.append({
                            'task_id': task,
                            'sid': item,
                        })

                db.query().name('server_malicious_scan_task').insert_all(insert_data)

                # 提交事务
                db.commit()
                # flags = True
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        return task_dirs

    # 执行扫描任务
    def __exec_task_help(self, sid, task_ids):
        # public.print_log('执行扫描任务开始', _level='error')

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            id_list = []
            for item in sid:
                for ids, dirs in task_ids:
                    fs.append(t.submit(self.__scan_task_help, item, 'ScanDir', {
                        'dir': dirs,
                        'id': str(ids),
                    }))

                    id_list.append(ids)

            for f in fs:
                f.result()

        # public.print_log('执行扫描任务结束', _level='error')

    # 查看扫描任务进度 最新任务(非自动扫描)
    def get_scan_task_progress(self, args):
        '''
            @name 查看扫描任务进度 最新任务(非自动扫描)
            @author lt<2023-07-10>
            @return dict
        '''
        # task_id = args.get('task_id', None)
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            max_id = db.query().name('malicious_scan_tasks')\
                .where('is_automatic', 0)\
                .field('id', 'name')\
                .order('id', 'desc')\
                .find()
            # ids = db.query() \
            #     .name('malicious_scan_tasks') \
            #     .where('name', max_id['name']) \
            #     .field('id', 'name') \
            #     .value('id')

            query = db.query() \
                .name('malicious_scan_tasks') \
                .field('id', 'status', 'scan_dir', 'scan_progress / 100 as scan_progress',
                       'finish_time',) \
                .where('name', max_id['name']) \
                .select()

            # 如果全部扫描状态都完成,返回扫描完成
            if all(item['status'] != 0 for item in query):
                return public.success('扫描完成')
            # 如果全部扫描状态都完成,返回扫描完成
            if all(item['scan_progress'] == 100 for item in query):
                return public.success('扫描完成')

        return public.success(query)




    # 病毒扫描-删除扫描任务
    def remove_scan_task(self, args):
        '''
           @author law<2023-06-02>
           @param args<dict> 请求参数列表
           @return dict
       '''
        id = args.get('id', None)
        name = args.get('task_name',None)
        name_list = name.split(',')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            db.query() \
                .name('malicious_scan_tasks') \
                .where_in('id', str(id).split(',')) \
                .delete()

            db.query() \
                .name('server_malicious_scan_task') \
                .where_in('task_id', str(id).split(',')) \
                .delete()

            db.query() \
                .name('malicious_scan_results') \
                .where_in('task_id', str(id).split(',')) \
                .delete()

        # 记录日志
        for item in name_list:
            public.WriteLog('安全监控病毒扫描', '删除扫描任务【%s】' % item)

        return public.success('删除扫描任务成功')


    def get_scan_task_list(self, args):
        '''
            @name 获取扫描任务列表
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        status = args.get('status', None)
        id = args.get('id', None)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 第一次查询出任务ID
            query = db.query() \
                .name('malicious_scan_tasks') \
                .field('id', 'scan_type', 'creator', 'status', 'scan_progress / 100 as scan_progress',
                       'finish_time', 'create_time', 'scan_dir', 'name', 'is_automatic')
            if status is not None:
                query.where('status', status)

            if id is not None:
                query.where('id', id)

            if sid is not None:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
                    return public.error('参数：sid格式错误')
                query.where_in('smst.sid', db.query() \
                               .name('server_malicious_scan_task') \
                               .where_in('sid', str(sid).split(',')) \
                               .column('distinct `task_id`'))

            # 添加关键字查询
            def query_handler(query, keyword):
                tmp = '%{}%'.format(keyword)
                query.where('name like ? OR scan_dir like ?', [tmp, tmp])

            public.add_retrieve_keyword_query(query, args, query_handler)

            query.order('create_time', 'desc')

            # 添加时间范围查询
            if query_date is not None and len(query_date) > 0:
                query.where('create_time >= ? and create_time <= ?', public.get_query_timestamp(query_date))

            # 分页查询
            ret = public.simple_page(query, args)

            # 任务ID
            task_id_list = list(set(map(lambda x: x['id'], ret['list'])))

            # 查询任务下主机数
            server_count = db.query() \
                .name('server_malicious_scan_task') \
                .where_in('task_id', task_id_list) \
                .field('task_id', 'count(*) as cnt') \
                .group('task_id') \
                .column('cnt', 'task_id')

            scan_count = db.query() \
                .name('malicious_scan_results') \
                .where_in('task_id', task_id_list) \
                .where('white_list_id=0') \
                .where('isolate_id=0') \
                .field('task_id', 'count(*) as cnt') \
                .group('task_id') \
                .column('cnt', 'task_id')

        # 查询操作人信息
        uid_list = list(set(map(lambda x: x['creator'], ret['list'])))

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        # 组装服务器信息和操作人信息
        for item in ret['list']:
            item['creator_username'] = users.get(item['creator'], '')
            item['server_count'] = server_count.get(item['id'], 0)
            item['scan_count'] = scan_count.get(item['id'], 0)

        return public.success(ret)

    # 病毒扫描-重新扫描
    def rescan_task(self, args):
        '''
           @name 病毒扫描-重新扫描
           @author law<2023-05-10>
           @param args<dict> 请求参数列表
           @return dict
       '''
        task_id = args.get('id', None)
        uid = public.bt_auth('uid')
        cur_time = int(time.time())

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            if db.query().name('malicious_scan_tasks').where('id', task_id).exists():
                query = db.query() \
                    .name('malicious_scan_tasks') \
                    .field('scan_dir', 'name') \
                    .where('id', task_id) \
                    .select()

                # 重置扫描任务状态与进度
                db.query() \
                    .name('malicious_scan_tasks') \
                    .where('id', task_id) \
                    .update({
                    'status': 0,
                    'scan_progress': 0,
                    'finish_time': 0,
                    'create_time': cur_time
                })

                scan_dir = query[0].get('scan_dir', None)
                name = query[0].get('name', None)

                db.query() \
                    .name('server_malicious_scan_task') \
                    .where('task_id', task_id) \
                    .update({
                    'progress': 0,
                    'status': 0
                })

                sid = db.query() \
                    .name('server_malicious_scan_task') \
                    .field('sid') \
                    .where('task_id', task_id) \
                    .column('sid')

        # 开始扫描
        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for item in sid:
                fs.append(t.submit(self.__scan_task_help, item, 'ScanDir', {
                    'dir': scan_dir,
                    'id': str(task_id),
                }))

            for f in fs:
                f.result()

        self.__update_scan_task_progress(task_id, sid)

        # 记录日志
        public.WriteLog('安全监控病毒扫描', '重新扫描任务【%s】扫描目录【%s】' % (name, scan_dir))

        return public.success('重新扫描任务成功')

    # 病毒扫描-清空扫描结果
    def clear_scan_result(self, args):
        '''
           @name 病毒扫描-清空扫描结果
           @author law<2023-05-24>
           @param args<dict> 请求参数列表
           @return dict
       '''
        id = args.get('id', None)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 获取任务id
            query = db.query() \
                .name('malicious_scan_results') \
                .where_in('id', str(id).split(',')) \
                .field('task_id') \
                .select()

            # 任务id列表组成
            task_list = []
            for temp in query:
                task_list.append(temp['task_id'])

            ret = db.query() \
                .name('malicious_scan_tasks') \
                .field('name') \
                .where_in('id', task_list) \
                .select()

            # 记录日志
            for items in ret:
                # public.print_log('安全监控病毒扫描', '删除任务[%s]扫描结果 成功' % (items['name']))
                public.WriteLog('安全监控病毒扫描', '删除任务[%s]扫描结果 成功' % (items['name']))

            # 删除数据操作
            db.query() \
                .name('malicious_scan_results') \
                .where_in('id', str(id).split(',')) \
                .delete()

        return public.success('删除结果成功')

    # 获取扫描任务下的主机列表
    def get_server_scan_task_list(self, args):
        '''
            @name 获取扫描任务下的主机列表
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        task_id = args.get('task_id', None)

        if task_id is None:
            return public.error('缺少参数：task_id')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            server_tasks = db.query() \
                .name('server_malicious_scan_task') \
                .where('task_id', int(task_id)) \
                .field('sid', 'scan_pid', 'scan_process_exists', 'progress / 100 as progress', 'start_time',
                       'status', 'finish_time', 'stop_operator', 'stop_time') \
                .select()

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], server_tasks))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        # 查询操作人信息
        uid_list = list(set(map(lambda x: x['stop_operator'], server_tasks)))

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        # 组装服务器信息和操作人信息
        for item in server_tasks:
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            item['stop_operator_username'] = users.get(item['stop_operator'], '')

        return public.success(server_tasks)

    # 获取扫描结果
    def get_scan_task_result(self, args):
        '''
            @name 获取扫描结果
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''

        return self.get_scan_task_result_v2(args)

        task_id = args.get('task_id', None)
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        in_white = args.get('in_white', None)
        in_isolate = args.get('in_isolate', None)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            query = db.query() \
                .name('malicious_scan_results') \
                .alias('msr') \
                .join('malicious_scan_tasks as mst', 'msr.task_id=mst.id', 'left') \
                .field('msr.id', 'sid', 'task_id', 'mst.name as task_name', 'msr.status', 'level', 'white_list_id',
                       'isolate_id',
                       'handle_operator', 'handled_time', 'ignore_operator', 'ignore_time', 'msr.create_time',
                       'file_path', 'fix_remark', 'scan_dir')

            if task_id is not None:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(task_id)):
                    return public.error('参数：task_id格式错误')
                query.where_in('task_id', str(task_id).split(','))

            if sid is not None:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
                    return public.error('参数：sid格式错误')
                query.where_in('sid', str(sid).split(','))

            if in_white is not None and int(in_white) == 1:
                query.where('`white_list_id` > 0')
            else:
                query.where('white_list_id', 0)

            if in_isolate is not None and int(in_isolate) == 1:
                query.where('`isolate_id` > 0')
            else:
                query.where('isolate_id', 0)

            # 添加关键字查询
            def query_handler(query, keyword):
                tmp = '%{}%'.format(keyword)
                query.where('file_path like ?', [tmp])

            public.add_retrieve_keyword_query(query, args, query_handler)

            query.order('msr.create_time', 'desc')

            # 添加时间范围查询
            if query_date is not None and len(query_date) > 0:
                query.where('msr.create_time >= ? and msr.create_time <= ?', public.get_query_timestamp(query_date))

            # 分页查询
            ret = public.simple_page(query, args)

        # 查询操作人信息
        uid_list = []
        map(lambda x: uid_list.extend([x['handle_operator'], x['ignore_operator']]), ret['list'])
        uid_list = list(set(uid_list))

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret['list']))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['handle_operator_username'] = users.get(item['handle_operator'], '')
            item['ignore_operator_username'] = users.get(item['ignore_operator'], '')
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')

        return public.success(ret)

    # 获取扫描结果
    def get_scan_task_result_v2(self, args):
        '''
            @name 获取扫描结果 2种  自动扫描和手动扫描  手动展示最近一次 自动展示全部
            @param args<dict> 请求参数列表
            @param sid<dict> 服务器 非必填
            @param query_date<dict> 日期 非必填
            @param is_automatic<dict> 是否是自动任务 非必填
            @return dict
        '''
        # public.print_log('@扫描结果列表  进入   获取结果~~~ -'.format(), _level='error')
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        is_automatic = args.get('is_automatic', None)  # 是否自动 1是 0否

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # query = db.query() \
            #     .name('malicious_scan_results') \
            #     .alias('msr') \
            #     .join('malicious_scan_tasks as mst', 'msr.task_id=mst.id', 'left') \
            #     .field('msr.id', 'sid', 'task_id', 'mst.name as task_name', 'msr.status', 'level', 'white_list_id',
            #            'isolate_id',
            #            'handle_operator', 'handled_time', 'ignore_operator', 'ignore_time', 'msr.create_time',
            #            'file_path', 'fix_remark', 'scan_dir')
            task_query = db.query().name('malicious_scan_tasks').field('id', 'name')

            query = db.query()\
                .name('malicious_scan_results')\
                .where('white_list_id', 0)\
                .where('isolate_id', 0)\
                .where('status', 0)

            # 自动扫描
            if is_automatic is not None and int(is_automatic) == 1:
                ids = task_query.where('is_automatic', 1).column('id')
                query.where_in('task_id', ids)
                # public.print_log('@0自动扫描  任务id ~~~ ---{}'.format(ids), _level='error')
            else:
                max_id = task_query.where('is_automatic', 0).order('id', 'desc').find()
                # public.print_log('@手动扫描 当前最大id ---{}'.format(max_id), _level='error')
                if max_id is None:
                    data = {'total': 0, 'list': []}
                    return public.success(data)

                ids = db.query()\
                    .name('malicious_scan_tasks')\
                    .where('name', max_id['name'])\
                    .field('id', 'name')\
                    .column('id')

                # public.print_log('@手动扫描 所有任务id---{}'.format(ids), _level='error')
                # query.where('is_automatic', 0)
                if ids is not None:
                    query.where_in('task_id', ids)
                else:

                    # 当前无手动任务 空结果
                    data = {'total': 0, 'list': []}
                    # public.print_log('当前无手动任务 空结果', _level='error')
                    return public.success(data)

            if sid is not None and len(sid) > 0:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
                    return public.error('参数：sid格式错误')
                query.where_in('sid', str(sid).split(','))

            # 添加关键字查询
            def query_handler(query, keyword):
                tmp = '%{}%'.format(keyword)
                query.where('file_path like ?', [tmp])

            public.add_retrieve_keyword_query(query, args, query_handler)

            query.order('create_time', 'desc')
            # query.order('msr.create_time', 'desc')

            # 添加时间范围查询
            if query_date is not None and len(query_date) > 0:
                query.where('create_time >= ? and create_time <= ?', public.get_query_timestamp(query_date))

            # 分页查询
            ret = public.simple_page(query, args)
            # public.print_log('@3---{}'.format(ret), _level='error')
        # 查询操作人信息
        uid_list = []
        map(lambda x: uid_list.extend([x['handle_operator'], x['ignore_operator']]), ret['list'])
        uid_list = list(set(uid_list))

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret['list']))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['handle_operator_username'] = users.get(item['handle_operator'], '')
            item['ignore_operator_username'] = users.get(item['ignore_operator'], '')
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')

        return public.success(ret)


    def stop_scan_task(self, args):
        '''
            @name 结束扫描任务
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        return self.stop_scan_task_v2()

        task_id = args.get('task_id', None)
        sid = args.get('sid', None)
        uid = public.bt_auth('uid')
        cur_time = int(time.time())

        if task_id is None:
            return public.error('缺少参数：task_id')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(task_id)):
            return public.error('参数：task_id格式错误')

        # 获取正在扫描中的任务
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            query = db.query() \
                .name('server_malicious_scan_task') \
                .field('id', 'task_id', 'sid', 'status') \
                .where('status', 0) \
                .where_in('task_id', str(task_id).split(','))

            if sid is not None:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
                    return public.error('参数：sid格式错误')
                query.where_in('sid', str(sid).split(','))

            tasks = query.select()

            task_id_set = set()
            id_set = set()

            task_id_set.add(int(task_id))

            for item in tasks:
                task_id_set.add(item['task_id'])
                id_set.add(item['id'])

            # 关闭事务自动提交
            db.autocommit(False)

            # 更新扫描任务状态
            db.query() \
                .name('server_malicious_scan_task') \
                .where('status', 0) \
                .where_in('id', list(id_set)) \
                .update({
                'status': 2,
                'scan_process_exists': 0,
                'stop_operator': uid,
                'stop_time': cur_time,
                'finish_time': cur_time,
            })

            db.query() \
                .name('malicious_scan_tasks') \
                .where('status', 0) \
                .where_in('id', list(task_id_set)) \
                .update({
                'status': 2,
                'stop_operator': uid,
                'stop_time': cur_time,
                'finish_time': cur_time,
            })

            # 提交事务
            db.commit()

        # 停止扫描任务
        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for task in tasks:
                fs.append(t.submit(self.__scan_task_help, task['sid'], 'Kill', {'id': str(task['task_id'])}))

            for f in fs:
                f.result()

        # 记录日志
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            task_ = db.query().name('malicious_scan_tasks').where('id', task_id.split(',')).field('name').select()
        for i in task_:
            public.WriteLog('安全监控病毒扫描', '结束扫描任务【{}】'.format(i['name']))

        return public.success('操作成功')

    # 结束扫描任务帮助
    def __stop_scan_task_help(self, tasks):
        # 停止扫描任务
        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for task in tasks:
                fs.append(t.submit(self.__scan_task_help, task['sid'], 'Kill', {'id': str(task['task_id'])}))

            for f in fs:
                f.result()

    # 结束扫描任务  全部正在扫描的--手动任务
    def stop_scan_task_v2(self):
        '''
            @name 结束扫描任务
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        # task_id = args.get('task_id', None)
        # sid = args.get('sid', None)
        uid = public.bt_auth('uid')
        cur_time = int(time.time())

        # if task_id is None:
        #     return public.error('缺少参数：task_id')

        # if not re.match(r'^-?\d+(?:,-?\d+)*$', str(task_id)):
        #     return public.error('参数：task_id格式错误')

        # 获取正在扫描中的任务
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # # 最新任务ID
            # max_id = db.query().name('malicious_scan_tasks')\
            #     .where('is_automatic', 0)\
            #     .field('id', 'name')\
            #     .order('id', 'desc')\
            #     .find()
            ids = db.query() \
                .name('malicious_scan_tasks') \
                .where('is_automatic', 0) \
                .where('status', 0) \
                .field('id', 'name') \
                .column('id')
            if not ids or len(ids) == 0:
                return

            query = db.query() \
                .name('server_malicious_scan_task') \
                .field('id', 'task_id', 'sid', 'status') \
                .where('status', 0) \
                .where_in('task_id', ids)

            # if sid is not None:
            #     if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
            #         return public.error('参数：sid格式错误')
            #     query.where_in('sid', str(sid).split(','))

            tasks = query.select()

            if tasks is None:
                return

            task_id_set = set()
            id_set = set()

            # task_id_set.add(int(task_id))

            for item in tasks:
                task_id_set.add(item['task_id'])
                id_set.add(item['id'])

            # 关闭事务自动提交
            db.autocommit(False)

            # 更新扫描任务状态
            db.query() \
                .name('server_malicious_scan_task') \
                .where('status', 0) \
                .where_in('id', list(id_set)) \
                .update({
                    'status': 2,
                    'scan_process_exists': 0,
                    'stop_operator': uid,
                    'stop_time': cur_time,
                    'finish_time': cur_time,
            })

            db.query() \
                .name('malicious_scan_tasks') \
                .where('status', 0) \
                .where_in('id', list(task_id_set)) \
                .update({
                    'status': 2,
                    'stop_operator': uid,
                    'stop_time': cur_time,
                    'finish_time': cur_time,
                })

            # 提交事务
            db.commit()

        # 推到队列 -- 调用被控执行
        from core.include.monitor_helpers import async_call_queue
        async_call_queue.add_task_easy(self.__stop_scan_task_help, tasks)

        # 记录日志
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            task_ = db.query().name('malicious_scan_tasks').where_in('id', ids).field('name').select()
        for i in task_:
            public.WriteLog('安全监控病毒扫描', '结束扫描任务【{}】'.format(i['name']))

        return public.success('操作成功')


    def ignore_scan_task_result(self, args):
        '''
            @name 忽略扫描结果
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        result_id = args.get('result_id', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')
        cur_time = int(time.time())

        if result_id is None:
            return public.error('缺少参数：result_id')

        if ignored is None:
            return public.error('缺少参数：ignored')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(result_id)):
            return public.error('参数：result_id格式错误')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            db.query() \
                .name('malicious_scan_results') \
                .where_in('id', str(result_id).split(',')) \
                .update({
                'status': 2 if int(ignored) == 1 else 0,
                'ignore_operator': uid,
                'ignore_time': cur_time,
            })

        # 记录日志
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            query = db.query() \
                .name('malicious_scan_results') \
                .where_in('id', str(result_id).split(',')) \
                .field('sid', 'file_path', ) \
                .select()
        # 拿到主机id
        sids = list(set([q['sid'] for q in query]))
        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where_in('sid', sids).column(None,
                                                                                                               'sid')

        for w in query:
            w['ip'] = server_info[w['sid']]['ip']
            w['remark'] = server_info[w['sid']]['remark']
        for i in query:
            public.WriteLog('安全监控病毒扫描', '忽略【%s（%s）】下的【%s】' % (i['ip'], i['remark'], i['file_path']))

        return public.success('操作成功')

    def handle_scan_task_result(self, args):
        '''
            @name 处理扫描结果
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        result_id = args.get('result_id', None)
        handled = args.get('handled', None)
        remark = args.get('remark', '')
        uid = public.bt_auth('uid')
        cur_time = int(time.time())

        if result_id is None:
            return public.error('缺少参数：result_id')

        if handled is None:
            return public.error('缺少参数：handled')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(result_id)):
            return public.error('参数：result_id格式错误')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            db.query() \
                .name('malicious_scan_results') \
                .where_in('id', str(result_id).split(',')) \
                .update({
                'status': 1 if int(handled) == 1 else 0,
                'handle_operator': uid,
                'handled_time': cur_time,
                'fix_remark': remark,
            })

        # 记录日志
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            query = db.query() \
                .name('malicious_scan_results') \
                .where_in('id', str(result_id).split(',')) \
                .field('sid', 'file_path', ) \
                .select()
        # 拿到主机id
        sids = list(set([q['sid'] for q in query]))
        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where_in('sid', sids).column(None,
                                                                                                               'sid')

        for w in query:
            w['ip'] = server_info[w['sid']]['ip']
            w['remark'] = server_info[w['sid']]['remark']
        for i in query:
            public.WriteLog('安全监控病毒扫描', '处理【%s（%s）】下的【%s】' % (i['ip'], i['remark'], i['file_path']))
        return public.success('操作成功')

    def add_white_list(self, args):
        '''
            @name 目录/文件 加入白名单
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        name = args.get('name', '')
        ps = args.get('ps', '')
        file_path = args.get('file_path', None)
        only_dir = args.get('only_dir', 0)
        uid = public.bt_auth('uid')
        # file_md5 = args.get('file_md5', None)

        # if name is None:
        #     return public.error('缺少参数：name')

        if file_path is None:
            return public.error('缺少参数：file_path')

        if int(only_dir) == 1:
            file_path = os.path.dirname(file_path)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # if db.query().name('malicious_white_lists').where('name', name).exists():
            #     return public.error('名称【{}】已存在'.format(name))

            # 关闭事务自动提交
            db.autocommit(False)

            try:
                # todo 添加md5字段值
                white_id = db.query() \
                    .name('malicious_white_lists') \
                    .insert({
                    'file_path': file_path,
                    'is_dir': int(only_dir),
                    'creator': uid,
                    'name': name,
                    'ps': ps,
                })

                opt = 'like' if int(only_dir) == 1 else '='

                # 检查结果，将符合条件的结果放入白名单中
                db.query() \
                    .name('malicious_scan_results') \
                    .where('white_list_id', 0) \
                    .where('`file_path` {} ?'.format(opt), file_path + ('%' if int(only_dir) == 1 else '')) \
                    .update({
                    'white_list_id': white_id,
                    'status': 3
                })

                # # 检查结果，将MD5相符的放入白名单中
                # db.query() \
                #     .name('malicious_scan_results') \
                #     .where('white_list_id', 0) \
                #     .where('file_md5', file_md5) \
                #     .update({
                #     'white_list_id': white_id,
                #     'status': 3
                # })


                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

                return public.error('添加失败：{}'.format(str(e)))

        # 记录日志
        public.WriteLog('安全监控病毒扫描', '将路径【%s】加入白名单' % (file_path))

        return public.success('操作成功')

    def remove_white_list(self, args):
        '''
            @name 删除白名单
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        white_id = args.get('white_id', None)

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(white_id)):
            return public.error('参数：white_id格式错误')

        white_id = white_id.split(',')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 关闭事务自动提交
            db.autocommit(False)

            try:
                white_info = db.query() \
                    .name('malicious_white_lists') \
                    .field('file_path') \
                    .where('id > 0') \
                    .where_in('id', white_id) \
                    .select()

                db.query() \
                    .name('malicious_white_lists') \
                    .where('id > 0') \
                    .where_in('id', white_id) \
                    .delete()

                db.query() \
                    .name('malicious_scan_results') \
                    .where('white_list_id > 0') \
                    .where_in('white_list_id', white_id) \
                    .update({
                    'white_list_id': 0,
                    'status': 0
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

                return public.error('删除失败：{}'.format(str(e)))

        # 记录日志
        for i in white_info:
            public.WriteLog('安全监控病毒扫描', '将白名单【%s】删除' % i['file_path'])

        return public.success('操作成功')

    def get_white_list(self, args):
        '''
            @name 获取白名单列表
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        query_date = args.get('query_date', None)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            query = db.query().name('malicious_white_lists') \

            # 添加关键字查询
            def query_handler(query, keyword):
                tmp = '%{}%'.format(keyword)
                query.where('`file_path` like ? OR `ps` like ?', [tmp, tmp])

            public.add_retrieve_keyword_query(query, args, query_handler)

            query.order('create_time', 'desc')

            # 添加时间范围查询
            if query_date is not None and len(query_date) > 0:
                query.where('create_time >= ? and create_time <= ?', public.get_query_timestamp(query_date))

            # 分页查询
            ret = public.simple_page(query, args)

        # 查询操作人信息
        uid_list = list(set(map(lambda x: x['creator'], ret['list'])))

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        # 组装服务器信息和操作人信息
        for item in ret['list']:
            item['creator_username'] = users.get(item['creator'], '')

        return public.success(ret)

    # 更新扫描任务进度
    def update_scan_task_progress(self, args=None):
        task_id = None

        if args is not None:
            task_id = args.get('task_id', None)

        task_id_list = None

        if task_id is not None and re.match(r'^-?\d+(?:,-?\d+)*$', str(task_id)):
            task_id_list = str(task_id).split(',')

        if task_id_list is None:
            with monitor_db_manager.db_mgr('malicious_scan') as db:
                # 获取扫描中的任务ID
                task_id_list = db.query() \
                    .name('malicious_scan_tasks') \
                    .where('status', 0) \
                    .column('id')

        for item in task_id_list:
            self.__update_scan_task_progress(int(item))

        return public.success('更新成功')

    def get_isolators_list(self, args):
        '''
            @name 获取隔离箱列表
            @author law<2023-04-19>
            @return dict
        '''
        query_date = args.get('query_date', None)

        with monitor_db_manager.db_mgr('malicious_scan') as db:

            sub_query = db.query() \
                .name('malicious_scan_results') \
                .where('isolate_id=?', 1) \
                .field('min(`id`) as `id`', 'file_path', 'status', 'create_time', 'isolate_id',
                       'sid', 'handle_operator', 'ignore_operator') \
                .group('sid,file_path') \
                .build_sql(True)

            query = db.query() \
                .from_sub_query(sub_query)

            # 添加关键字查询
            def query_handler(query, keyword):
                tmp = '%{}%'.format(keyword)
                query.where('file_path like ? ', [tmp])

            public.add_retrieve_keyword_query(query, args, query_handler)

            query.order('create_time', 'desc')

            # 添加时间范围查询
            if query_date is not None and len(query_date) > 0:
                query.where('create_time >= ? and create_time <= ?', public.get_query_timestamp(query_date))

            # 分页查询
            ret = public.simple_page(query, args)

        # 查询操作人信息
        uid_list = []
        map(lambda x: uid_list.extend([x['handle_operator'], x['ignore_operator']]), ret['list'])
        uid_list = list(set(uid_list))

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret['list']))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        # 组装服务器信息和操作人信息
        for item in ret['list']:
            item['handle_operator_username'] = users.get(item['handle_operator'], '')
            item['ignore_operator_username'] = users.get(item['ignore_operator'], '')
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')

        return public.success(ret)

    def join_isolatore(self, args):
        '''
            @name 拉入隔离箱
            @author law<2023-04-19>
            @return  bool  成功/失败
        '''
        result_id = args.get('result_id', None)

        if result_id is None:
            return public.return_error('缺少参数: result_id')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(result_id)):
            return public.error('参数：result_id格式错误')

        # 拉入隔离箱成功的ID
        success_ids = []
        # 拉入隔离箱失败的文件
        error_file = []
        try:
            with monitor_db_manager.db_mgr('malicious_scan') as db:
                id_list = db.query() \
                    .name('malicious_scan_results') \
                    .where_in('id', str(result_id).split(',')) \
                    .field('id', 'sid', 'file_path') \
                    .select()

            with ThreadPoolExecutor(max_workers=10) as t:
                fs = []

                for item in id_list:
                    fs.append((t.submit(self.__scan_task_help, item['sid'], 'MvRecycle', {
                        'path': json.dumps([item['file_path']])
                    }), item['id']))

                for f, r_id in fs:
                    res = f.result()
                    if self.__check_agent_response_success(res):
                        success_ids.append(r_id)
                        continue

                    # public.print_log(res, _level='error')

                    # return public.error('文件隔离失败：请检查目标文件是否存在或是否加锁')

            with monitor_db_manager.db_mgr('malicious_scan') as db:
                # 开启事务
                db.autocommit(False)

                for item in id_list:
                    if item['id'] not in success_ids:
                        continue

                    db.query() \
                        .name('malicious_scan_results') \
                        .where('sid', item['sid']) \
                        .where('file_path', item['file_path']) \
                        .update({
                        'isolate_id': 1,
                        'status': 4,
                    })
                    error_file.append(item['file_path'])

                # 提交事务
                db.commit()
        except BaseException as e:
            public.print_exc_stack(e)
            public.WriteLog('安全监控病毒扫描', '文件隔离失败: 请检查目标文件是否存在或是否加锁')
            return public.success("隔离失败")

        # 隔离失败
        if len(success_ids) == 0:
            public.WriteLog('安全监控病毒扫描', '文件隔离失败: 请检查目标文件是否存在或是否加锁')
            return public.error('隔离失败')

        # 记录日志
        # 拿到主机id
        sids = []
        for item in id_list:
            if item['id'] not in success_ids or item['sid'] in sids:
                continue
            sids.append(item['sid'])

        server_info = warning_obj.db_easy('servers') \
            .field('sid', 'ip', 'remark') \
            .where_in('sid', sids) \
            .column(None, 'sid')

        for item in id_list:
            if item['id'] not in success_ids:
                continue
            s_info = server_info.get(item['sid'], {})
            public.WriteLog('安全监控病毒扫描', '将【%s（%s）】下的【%s】拉入隔离箱' % (
                s_info.get('ip', ''), s_info.get('remark', ''), item['file_path']))

        if len(success_ids) != len(id_list):
            for i in error_file:
                public.WriteLog('安全监控病毒扫描', '文件【%s】隔离失败' % i)
            return public.success('部分文件隔离成功，请检查隔离失败的文件是否存在或者是否加锁')

        return public.success("隔离成功")

    def restore_files(self, args):
        '''
            @name 恢复文件
            @author law<2023-04-19>
            @return  bool  成功/失败
        '''
        result_id = args.get('result_id', None)

        if result_id is None:
            return public.return_error('缺少参数: result_id')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(result_id)):
            return public.error('参数：result_id格式错误')

        # 恢复成功的ID
        success_ids = []

        try:
            with monitor_db_manager.db_mgr('malicious_scan') as db:
                id_list = db.query() \
                    .name('malicious_scan_results') \
                    .where_in('id', str(result_id).split(',')) \
                    .field('id', 'sid', 'file_path') \
                    .select()

            with ThreadPoolExecutor(max_workers=10) as t:
                fs = []

                for item in id_list:
                    fs.append((t.submit(self.__scan_task_help, item['sid'], 'ReRecycle', {
                        'path': json.dumps([item['file_path']])
                    }), item['id']))

                for f, r_id in fs:
                    res = f.result()
                    if self.__check_agent_response_success(res):
                        success_ids.append(r_id)
                        continue

                    # public.print_log(res, _level='error')
                    # return public.error('文件恢复失败：文件可能已经从隔离箱中移除')

            with monitor_db_manager.db_mgr('malicious_scan') as db:
                # 开启事务
                db.autocommit(False)

                for temp in id_list:
                    if temp['id'] not in success_ids:
                        continue

                    db.query() \
                        .name('malicious_scan_results') \
                        .where('sid', temp['sid']) \
                        .where('file_path', temp['file_path']) \
                        .update({
                        'isolate_id': 0,
                        'status': 0,
                    })

                # 提交事务
                db.commit()
        except:
            # 记录日志
            # 拿到主机id
            sids = list(set([q['sid'] for q in id_list]))
            server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where_in('sid', sids).column(None,
                                                                                                                   'sid')

            for w in id_list:
                w['ip'] = server_info[w['sid']]['ip']
                w['remark'] = server_info[w['sid']]['remark']
            for i in id_list:
                public.WriteLog('安全监控病毒扫描',
                                '将【%s（%s）】下的【%s】隔离文件恢复 --失败' % (i['ip'], i['remark'], i['file_path']))
            return public.success("恢复失败")

        # 文件恢复失败
        if len(success_ids) == 0:
            return public.error('恢复失败')

        # 记录日志
        # 拿到主机id
        sids = []
        for item in id_list:
            if item['id'] not in success_ids or item['sid'] in sids:
                continue
            sids.append(item['sid'])

        server_info = warning_obj.db_easy('servers') \
            .field('sid', 'ip', 'remark') \
            .where_in('sid', sids) \
            .column(None, 'sid')

        for item in id_list:
            if item['id'] not in success_ids:
                continue
            s_info = server_info.get(item['sid'], {})
            public.WriteLog('安全监控病毒扫描', '将【%s（%s）】下的【%s】隔离文件恢复 --成功' % (
                s_info.get('ip', ''), s_info.get('remark', ''), item['file_path']))

        if len(success_ids) != len(id_list):
            return public.success('部分文件恢复成功，恢复失败的文件可能已从隔离箱中移除')

        return public.success("恢复成功")

    # 病毒扫描添加告警规则
    def add_virus_scan_rule(self, args):
        """
        @name 添加病毒扫描告警规则
        @param open: 是否开启
        @param push_methods: 推送方式
        @return:
        """
        open = args.get('open', None)
        push_methods = args.get('push_methods', None)

        rule_data = {"type": "safety", "sub_type": "sacn", "watch_target": "percent", "watch_type": 5,
                     "watch_value": "status_error", "scores": 0, "duration": 60, "remark": "", "is_push": int(open),
                     "linked_all_server": 1,'push_methods': push_methods,}

        # 查看是否有相同的规则
        with monitor_db_manager.db_mgr() as db:
            query = db.query()\
                .name('warning_templates')\
                .where('type', rule_data['type'])\
                .where('sub_type', rule_data['sub_type'])\
                .where('linked_all_server', 1)\
                .where('watch_target', rule_data['watch_target'])

            # 有规则就不添加 修改为启用(开启推送告警 更新推送方式为当前的推送方式)
            if query.fork().exists():
                query.update({
                    'is_push': int(open),
                    'push_methods': push_methods
                })

            else:
                # 没有规则就添加
                ok, err_msg = warning_obj.check_rule(rule_data)
                if not ok:
                    return public.return_error(err_msg)
                # servers = []
                # 关联主机
                # if 'linked_servers' in rule_data:
                #     if re.match(r'^\d+(?:,\d+)*$', str(rule_data['linked_servers'])):
                #         servers = str(rule_data['linked_servers']).split(',')
                #     rule_data.pop('linked_servers', None)


                # # 关联主机分组
                # if 'linked_server_groups' in rule_data and re.match(r'^\d+(?:,\d+)*$', str(rule_data['linked_server_groups'])):
                #     group_ids = tuple(sorted(map(lambda x: int(x), str(rule_data['linked_server_groups']).split(','))))
                #     servers = warning_obj.db_easy('servers s') \
                #         .join('server_group sg', 's.group_id=sg.id')\
                #         .where('s.is_authorized=1') \
                #         .where_in('sg.id', group_ids)\
                #         .column('s.sid')
                #     rule_data['linked_server_groups'] = ','.join(map(lambda x: str(x), group_ids))

                # 关联所有主机
                # if 'linked_all_server' in rule_data and int(rule_data['linked_all_server']) == 1:
                servers = warning_obj.db_easy('servers') \
                    .where('is_authorized=1') \
                    .column('sid')

                with monitor_db_manager.db_mgr() as db:
                    try:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        template_id = db.query() \
                            .name('warning_templates') \
                            .insert(rule_data)

                        insert_data = []
                        if len(servers) > 0:
                            for sid in servers:
                                tmp = copy.deepcopy(rule_data)
                                tmp.pop('linked_server_groups', None)
                                tmp.pop('linked_all_server', None)
                                tmp.pop('remark', None)
                                tmp['template_id'] = template_id
                                tmp['sid'] = int(sid)
                                tmp['add_source'] = 3
                                insert_data.append(tmp)

                        if len(insert_data) > 0:
                            db.query()\
                                .name('warning_configurations')\
                                .insert_all(insert_data)

                        # 提交事务
                        db.commit()
                    except BaseException as e:
                        # 回滚事务
                        db.rollback()

                        # 记录异常堆栈
                        public.print_exc_stack(e)

                        return public.error('操作失败')

        return public.success('设置成功')

    def get_virus_scan_rule(self, args):
        """查看是否有病毒扫描的告警规则"""
        data = {}
        # 查看是否有病毒扫描的告警规则
        # rule_data = {"type": "safety", "sub_type": "sacn", "watch_target": "percent", "watch_type": 5,
        #              "watch_value": "status_error", "scores": 0, "duration": 60, "remark": "", "is_push": int(open),
        #              "linked_all_server": 1, 'push_methods': push_methods, }

        with monitor_db_manager.db_mgr() as db:
            sss = db.query()\
                .name('warning_templates')\
                .where('type', 'safety')\
                .where('sub_type', 'sacn')\
                .where('linked_all_server', 1)\
                .where('watch_target', 'percent')\
                .where('watch_type', 5)\
                .where('watch_value', 'status_error')\
                .order('id', 'desc')

            # sss = db.query()\
            #     .name('warning_templates') \
            #     .where(
            #     'type=? and sub_type=? and watch_target=? and watch_type=? and watch_value=? and linked_all_server=?',
            #     ('safety', 'sacn', 'percent', 5, 'status_error', 1))

            if sss.fork().exists():
                w = sss.find()
                # public.print_log('qqq病毒扫描的告警规则----- {}'.format(w))
                data['open'] = w['is_push']
                data['push_methods'] = w['push_methods']
            else:
                data['open'] = 0
                data['push_methods'] = None
        return public.success(data)


    def get_bug_count(self, args):
        '''
            @name 漏洞统计数据
            @author lt<2023-05-29>
            @param args<dict> 请求参数列表
            @return dict
        '''

        sids = warning_obj.db_easy('servers') \
            .field('sid', 'ip', 'remark') \
            .where('is_authorized', 1) \
            .where('type', 0) \
            .column('sid')

        # 查询主机漏洞数      'SUM(`fixed`) AS `fixed_num`',
        server_bugs = basic_monitor_obj.db_easy('server_bug_total') \
            .where_in('sid', sids) \
            .field('count(*) as `server_num`',
                   'SUM(`bugs` - `ignored` - `fixed`-`handled`) AS `unhandled_num`',
                   'SUM(`bugs`- `fixed`) AS `bugs_num`',
                   'SUM(`ignored`) AS `ignored_num`',
                   'SUM(`handled`) AS `handled_num`',
                   'SUM(`level_0`) AS `level_0`',
                   'SUM(`level_1`) AS `level_1`',
                   'SUM(`level_2`) AS `level_2`',
                   'SUM(`level_3`) AS `level_3`',
                   'max(last_scan_time) AS `last_scan_time`') \
            .find()

        return public.success(server_bugs)

    # 漏洞列表 整合
    def get_bug_list_merge(self, args):
        '''
            @name 获取漏洞扫描列表
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
            status 三种类型  0. 未处理漏洞    1. 已忽略漏洞    2. 已处理漏洞
        '''
        sids = args.get('sid', None)
        bug_type = args.get('bug_type', None)
        status = args.get('status', None)
        level = args.get('level', None)
        keyword = args.get('keyword', None)

        if sids is None:
            return public.error('缺少参数：sid')
        if sids == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sids.split(',')
            sids = [int(sid) for sid in sids]

        # 添加服务器信息 多个服务器
        server_infos = warning_obj.db_easy('servers') \
            .field('ip', 'remark', 'sid') \
            .where_in('sid', sids) \
            .column(None, 'sid')

        if status is None:
            return public.error('缺少参数: status')


        bugs_data = []
        # 遍历sid 获取漏洞信息
        # 测试先去掉条件 .where('usable', 1) \

        for sid in sids:
            with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
                query = db.query().name('server_bugs') \
                    .where('status', int(status))\
                    .where('usable', 1)

                if bug_type is not None and bug_type != '-1':
                    query.where('type', bug_type)
                if level and len(level) > 0:
                    query.where('level', int(level))

                # 添加关键字查询
                def query_handler(query, keyword):
                    # 查询cve编号
                    if re.match(r'^cve-\d+-\d+', keyword, flags=re.IGNORECASE):
                        query.where('`cve_id` like ?', '{}%'.format(keyword))
                        return

                    # 查询标题 OR 软件名称或工具名称 OR 文件路径 OR 漏洞特征 OR 漏洞描述 OR 修复建议 OR 处理人备注
                    where_or = [
                        '`vuln_name` like ?',
                        '`soft_name` like ?',
                        '`file_path` like ?',
                        '`tag` like ?',
                        '`suggestions` like ?',
                        '`fix_remark` like ?',
                    ]

                    query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

                public.add_retrieve_keyword_query(query, args, query_handler)

                ret_sid = query.select()
                for item in ret_sid:
                    item['server_info'] = server_infos.get(sid, {})
                    item['sid'] = sid

                bugs_data.extend(ret_sid)

        # 添加操作人信息
        ignore_operators = None  # 忽略人
        handled_operators = None  # 处理人

        with monitor_db_manager.db_mgr('safety') as db:
            ignore_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['ignore_operator'], bugs_data)))) \
                .field('uid', 'username') \
                .column('username', 'uid')

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], bugs_data)))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in bugs_data:
            item['ignore_operator_username'] = ignore_operators.get(item['ignore_operator'], '--')
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')
            try:
                item['tag'] = json.loads(item['tag'])
            except:
                item['tag'] = []

        # 添加排序
        for sort_key, sort_reverse in public.get_sort_params(args).items():
            bugs_data.sort(key=lambda x: x.get(sort_key, 0), reverse=sort_reverse)

        # 分页
        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(bugs_data),
            'list': bugs_data[(p - 1) * p_size:p * p_size],
        })

    # 忽略漏洞 整合
    def ignore_bug_merge(self, args):
        '''
            @name 忽略漏洞
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        # sid = args.get('sid', None)
        # vuln_id = args.get('vuln_id', None)
        data = args.get('data/json', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')

        # data1:
        # data2: [{sid: 3, vuln_id: '1,2,3'}, {sid: 5, vuln_id: '6,2,4'}]
        # ignored: 0

        if data is None:
            return public.error('缺少参数：data')
        if ignored is None:
            return public.error('缺少参数：ignored')

        # if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
        #     return public.error('参数：bug_id格式错误')

        ignore_num = {}  # 漏洞忽略数量  {sid: num, sid: num, ...}
        bugs_data = []
        sids = []
        # 漏洞数据 level_num [(sid,(等级,等级数量),忽略漏洞数量),(sid,(等级,等级数量),忽略漏洞数量),...]
        level_num = []
        # 处理data数据
        data = self.__data_merge(data)

        for i in data:
            sid = i['sid']
            sids.append(sid)
            if not re.match(r'^-?\d+(?:,-?\d+)*$', str(i['vuln_id'])):
                return public.error('参数：bug_id格式错误')
            vuln_id = i['vuln_id'].split(',')
            bugs_data.append({
                'sid': sid,
                'vuln_id': vuln_id
            })
            # 忽略漏洞数量
            num = len(vuln_id)
            ignore_num[sid] = num

        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where_in('sid', sids).column(None,
                                                                                                               'sid')

        for item in bugs_data:
            with monitor_db_manager.MonitorDbManager(item['sid']).db_mgr('server_bugs') as db_1:

                # 查询原来漏洞等级
                level_num_ = db_1.query() \
                    .name('server_bugs') \
                    .where_in('vuln_id', item['vuln_id']) \
                    .field('level', 'count(*) as `level_num`') \
                    .group('level') \
                    .select()
                level_num.append((item['sid'], level_num_, ignore_num[item['sid']]))

                # 忽略漏洞  ignored: 0 撤回忽略 1 忽略
                db_1.query() \
                    .name('server_bugs') \
                    .where_in('vuln_id', item['vuln_id']) \
                    .update({
                    'status': int(ignored),
                    'ignore_operator': uid,
                    'ignore_time': int(time.time())})

                # 记录日志
                server_bugs_info = db_1.query() \
                    .name('server_bugs') \
                    .where_in('vuln_id', item['vuln_id']) \
                    .field('vuln_name') \
                    .select()

            for info in server_bugs_info:
                public.WriteLog('安全监控漏洞扫描',
                                '忽略【%s（%s）】下的【%s】' % (
                                server_info[item['sid']]['ip'], server_info[item['sid']]['remark'], info['vuln_name']))

        with monitor_db_manager.db_mgr('server_bug_total') as db:
            # 开启事务
            db.autocommit(False)

            for item in level_num:
                # .increment('ignored', item[2])
                query = db.query() \
                    .name('server_bug_total') \
                    .where('sid', item[0])
                if ignored == '1':
                    query.increment('ignored', item[2])
                    for i in item[1]:
                        query.decrement('level_{}'.format(i['level']), i['level_num'])
                else:  # 撤回忽略
                    query.decrement('ignored', item[2])
                    for i in item[1]:
                        query.increment('level_{}'.format(i['level']), i['level_num'])

                query.update()

            db.commit()

        return public.success('操作成功')

    # 处理漏洞 整合
    def handle_bug_merge(self, args):
        '''
            @name 处理漏洞
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        # sid = args.get('sid', None)
        # vuln_id = args.get('vuln_id', None)

        data = args.get('data/json', '')
        remark = args.get('remark', '')
        handled = args.get('handled', None)
        uid = public.bt_auth('uid')
        if handled is None:
            return public.error('缺少参数：handled')
        # if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
        #     return public.error('参数：bug_id格式错误')
        #
        # vuln_id = str(vuln_id).split(',')

        handle_num = {}  # 漏洞数量  {sid: num, sid: num, ...}
        sids = []
        bugs_data = []
        # 处理data数据
        data = self.__data_merge(data)

        for i in data:
            sid = i['sid']
            sids.append(sid)
            if not re.match(r'^-?\d+(?:,-?\d+)*$', str(i['vuln_id'])):
                return public.error('参数：bug_id格式错误')

            vuln_id = i['vuln_id'].split(',')
            bugs_data.append({
                'sid': sid,
                'vuln_id': vuln_id
            })
            # 处理漏洞数量
            num = len(vuln_id)
            handle_num[sid] = num

        server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where_in('sid', sids).column(None,
                                                                                                               'sid')

        for item in bugs_data:
            with monitor_db_manager.MonitorDbManager(item['sid']).db_mgr('server_bugs') as db:
                db.query() \
                    .name('server_bugs') \
                    .where_in('vuln_id', item['vuln_id']) \
                    .update({
                    'status': 2 if int(handled) == 1 else 0,
                    'handle_operator': uid,
                    'fix_remark': remark,
                    'handled_time': int(time.time()),
                })

                # 记录日志
                server_bugs_info = db.query() \
                    .name('server_bugs') \
                    .where_in('vuln_id', item['vuln_id']) \
                    .field('vuln_name') \
                    .select()

                for info in server_bugs_info:  # 忽略【服务器IP(备注)】下的【漏洞名】
                    public.WriteLog('安全监控漏洞扫描',
                                    '处理【%s（%s）】下的【%s】' % (
                                    server_info[item['sid']]['ip'], server_info[item['sid']]['remark'], info['vuln_name']))

        # 同步统计表
        with monitor_db_manager.db_mgr('server_bug_total') as db:
            # 开启事务
            db.autocommit(False)
            for k, v in handle_num.items():
                query = db.query() \
                    .name('server_bug_total') \
                    .where('sid', k) \

                if int(handled) == 1:  # 处理   handled已处理数量增加
                    query.increment('handled', v)
                else:  # 撤回处理 已处理数量减少
                    query.decrement('handled', v)
                query.update()

            db.commit()

        return public.success('操作成功')

    # 重新扫描漏洞 整合
    def re_scan_bug_all_merge(self, args):
        '''
            @name 重新扫描漏洞(全部)
            @author Zhj<2023-03-22>
            @param  args<dict> 请求参数列表
            @return dict
        '''
        sids = args.get('sid', None)

        if sids is None:
            return public.error('缺少参数：sid')

        if sids == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sids.split(',')
            sids = [int(sid) for sid in sids]

        for sid in sids:
            res = public.send_agent_msg(
                public.get_serverid_bysid(sid),
                'vul_scan',
                'VulScan',
                timeout=60)

            data = public.get_agent_msg(res)

            if not data:
                return public.error('扫描失败，请重试~')

            # 更新主机漏洞列表
            basic_monitor_obj.update_server_bugs(sid, data.get('body', []))
            # 记录日志
            server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()
            public.WriteLog('安全监控漏洞扫描', '重新扫描【%s（%s）】下的全部漏洞' %
                            (server_info['ip'], server_info['remark']))
        return public.success('扫描成功')


    # 获取文件属性
    def __get_fileinfo(self, sid, file_path):
        return self.__send_agent_msg(sid, 'File', 'FileInfo', {
            'file': file_path,
        })

    # 获取文件属性
    def get_fileinfo(self, args):
        '''
            @name 获取文件属性
            @author law<2023-05-10>
            @return  bool  成功/失败
        '''
        sid = args.get('sid', None)
        file_path = args.get('file_path', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if file_path is None:
            return public.error('缺少参数：file_path')

        try:
            ret = self.__get_fileinfo(sid, file_path)
            if isinstance(ret, str):
                return public.success(json.loads(ret))
            else:
                return public.success(ret)
        except:
            pass

    # 查看文件内容
    def isolatore_file(self, args):
        '''
            @name 查看文件内容
            @author law<2023-05-10>
            @return  dict
        '''
        sid = args.get('sid', None)
        file_path = args.get('file_path', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if file_path is None:
            return public.error('缺少参数：file_path')

        file_info = self.__get_fileinfo(sid, file_path)

        # if isinstance(response,str):
        #     file_info = json.loads(response)
        # else:
        #     file_info = response

        if file_info is None:
            return public.error("文件不存在")

        is_dir = file_info.get('is_dir', None)

        if not is_dir:
            if file_info.get('size', None) > 1024 * 1024:
                return public.error("文件超出大小限制1MB，无法查看")
            # if 'x' in file_info.get('mode', None):
            #     return public.error("该文件为可执行文件，无法查看")
        else:
            return public.error("目标为文件路径，无法查看")

        ret = public.get_agent_file(sid, file_path)
        return public.success(ret)

    def __get_server_info(self, sid):
        """
        获取服务器信息 ip remark
        """
        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark') \
            .where('sid', sid) \
            .find()
        return server_info

    # 处理data数据 将sid相同的数据合并
    def __data_merge(self, data):
        # data1: [{sid: 3, vuln_id: '1'}, {sid: 5, vuln_id: '6'},{sid: 3, vuln_id: '2'}, {sid: 5, vuln_id: '2'}]
        # data2: [{sid: 3, vuln_id: '1,2'}, {sid: 5, vuln_id: '6,2'}]
        d = {}
        for item in data:
            if item["sid"] in d:
                d[item["sid"]] += "," + item["vuln_id"]
            else:
                d[item["sid"]] = item["vuln_id"]
        # 将字典转换为列表
        data = [{"sid": k, "vuln_id": v} for k, v in d.items()]
        return data

    # ssh登录日志
    def get_ssh_login_logs(self, args):
        '''
            @name 获取SSH登录日志列表
            @author Zhj<2022-06-28>
            @arg    status<?integer>    SSH登录状态 0-登录失败 1-登录成功
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @arg    sid<?integer>       主机ID[可选]
            @arg    keyword<?string>    关键字[可选]
            @return list
        '''

        status = args.get('status', None)
        sid = args.get('sid', None)
        keyword = args.get('keyword', None)
        query_date = args.get('query_date', None)
        # 全部所选主机
        ret_date = []

        if sid is None:
            return public.error('缺少参数：sid')

        # 选择了全部主机
        if sid == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sid.split(',')
            # 转换为int类型
            sids = list(map(lambda x: int(x), sids))

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', sids) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for sid in sids:
            # 选择了主机 则从数据库中获取 循环获取
            db_mgr = monitor_db_manager.MonitorDbManager(sid)

            with db_mgr.db_sgl('ssh_login_logs') as db:
                query = db.query().name('ssh_login_logs') \
                    .field('id', 'user', '{} as login_ip'.format("'****'" if basic_monitor_obj.in_demo() else 'ip'), 'port', 'ip_place', 'success', 'login_time',
                           '{} as `sid`'.format(int(sid))) \
                    .order('login_time', 'desc')\
                    .where_in('sid', sids)

                if status is not None and str(status) in ['0', '1']:
                    query.where('success', int(status))

                if keyword is not None:
                    tmp = '%{}%'.format(keyword)
                    query.where('user like ? OR ip like ?', [tmp, tmp])

                if query_date and len(query_date) > 0:  # 日期范围  yesterday today  l7
                    query.where('`login_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))
                # 分页
                # ret = public.simple_page(query, args)
                ret = query.select()
                login_ip_idx_map = {}
                i = 0

                for item in ret:
                    if item['ip_place'] == '' and item['login_ip'] != '':
                        if item['login_ip'] not in login_ip_idx_map:
                            login_ip_idx_map[item['login_ip']] = []

                        login_ip_idx_map[item['login_ip']].append(i)

                    server_info = servers.get(item['sid'], {})
                    item['ip'] = server_info.get('ip', '')
                    item['login_ip'] = '{}{}'.format(
                        item['login_ip'], ':{}'.format(item['port'])
                        if int(item['port']) > 0 else '')
                    item['remark'] = server_info.get('remark', '')
                    del (item['sid'])
                    del (item['port'])

                    i += 1

                # 查询IP信息
                if len(login_ip_idx_map.keys()) > 0:
                    ip_info_dict = basic_monitor_obj.search_ip_info(
                        list(login_ip_idx_map.keys()))

                    with monitor_db_manager.db_mgr('ssh_login_logs') as db:
                        try:
                            # 关闭自动提交事务
                            db.autocommit(False)

                            for (login_ip, idx_list) in login_ip_idx_map.items():
                                if login_ip not in ip_info_dict:
                                    continue

                                ip_place = ip_info_dict[login_ip][
                                               'country'] + ip_info_dict[login_ip]['province']

                                ids = []

                                for idx in idx_list:
                                    ret[idx]['ip_place'] = ip_place
                                    ids.append(ret[idx]['id'])

                                # 更新IP信息
                                db.query() \
                                    .name('ssh_login_logs') \
                                    .where_in('id', ids) \
                                    .update({
                                    'ip_place': ip_place,
                                })

                            # 提交事务
                            db.commit()
                        except BaseException as e:
                            # 回滚事务
                            db.rollback()

                            # 记录异常堆栈信息
                            public.print_exc_stack(e)

                ret_date.extend(ret)
        # 日志导出 export_log
        if args.get('export_log', None) == '1':
            if ret_date is None or len(ret_date) == 0:
                return public.error('没有可导出的数据')
            import pandas as pd
            # 处理数据
            for i in ret_date:
                i['login_time'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(i['login_time']))
                i['success'] = '成功' if i['success'] == 1 else '失败'

            # 将数据转换为DataFrame对象
            df = pd.DataFrame(ret_date)

            #  选择需要导出的字段
            selected_columns = {"id": "编号", "ip": "服务器", "login_ip": "登录IP", "login_time": "登录时间",
                                "user": "用户", "success": "状态"}

            selected_df = df[list(selected_columns.keys())].rename(columns=selected_columns)

            # # 导出数据到CSV文件中
            export_file_path = "/tmp/exported_ssh_login_logs.csv"
            selected_df.to_csv(export_file_path, index=False)
            from datetime import date
            return public.send_file('/tmp/exported_ssh_login_logs.csv', 'ssh_login_logs_{}.csv'.format(date.today()))

        # # 统计登录成功与失败次数
        # query = basic_monitor_obj.db_easy('ssh_login_total_daily') \
        #     .field('SUM(`success`) AS `success_cnt`', 'SUM(`fail`) AS `fail_cnt`') \
        #     .where_in('sid', sids)
        #
        # statistics_info = query.find()
        #
        # if statistics_info is None:
        #     statistics_info = {
        #         'success_cnt': 0,
        #         'fail_cnt': 0,
        #     }

        # 分页
        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(ret_date),
            'list': ret_date[(p - 1) * p_size:p * p_size],
            # 'success_cnt': statistics_info['success_cnt'],
            # 'fail_cnt': statistics_info['fail_cnt'],
        })
        # return public.success(ret)

    def get_command_execute_logs(self, args):
        '''
            @name 获取命令执行记录
            @author Zhj<2022-09-28>
            @arg    sid<string> 主机ID 可全选 可多选 可单选
            @arg    query_data<string> 查询日期范围
            @arg    keyword<string> 用户名 命令模糊查询
            @return dict
        '''
        # 获取主机ID
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        if sid is None:
            return public.error('缺少参数：sid')
        if sid == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sid.split(',')
            # 转换为int类型
            sids = list(map(lambda x: int(x), sids))

        # 组装查询构造器
        query = basic_monitor_obj.db_easy('command_execute_logs') \
            .where_in('sid', sids) \
            .field('user', '{} as command'.format("'****'" if basic_monitor_obj.in_demo() else 'command'),
                   'create_time', 'sid')

        # 添加关键字查询
        def query_handler(query, keyword):
            k = '%{}%'.format(keyword)
            query.where('user like ?', k) \
                .where_or('command like ?', k)
        public.add_retrieve_keyword_query(query, args, query_handler)

        if query_date and len(query_date) > 0:  # 日期范围  yesterday today  l7
            query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

        # 没有执行排序时的默认排序
        if 'sort' not in args:
            query.order('create_time', 'desc')

        # 添加排序
        public.add_retrieve_sort_query(query, args)

        # query = query.select()
        # 添加分页
        res = public.simple_page(query, args)
        # 服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', sids) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in res['list']:
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')



        # public.print_log('111111-----------{}'.format(res))

        return public.success(res)

        # p = int(args.get('p', 1))
        # p_size = int(args.get('p_size', 20))
        # return public.success({
        #     'total': len(query),
        #     'list': query[(p - 1) * p_size:p * p_size],
        # })

    # ssh登录日志 聚合
    def ssh_login_logs_aggregation(self, args):
        status = args.get('status', None)
        sid = args.get('sid', '-1')
        keyword = args.get('keyword', None)
        query_date = args.get('query_date', None)
        type = args.get('type', None)

        # 选择了全部主机
        if sid == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sid.split(',')
            # 转换为int类型
            sids = list(map(lambda x: int(x), sids))


        # 查询本月数据库
        query = basic_monitor_obj.db_easy('ssh_login_logs_latest') \
            .field('sid', 'user', 'ip as login_ip', 'ip_place', 'login_time', 'success', 'port') \
            .order('login_time', 'desc') \
            .where_in('sid', sids)

        if status is not None and str(status) in ['0', '1']:
            query.where('success', int(status))

        if keyword is not None and len(keyword) > 0:
            tmp = '%{}%'.format(keyword)
            query.where('user like ? OR ip like ? OR ip_place like ? OR login_time like ?', [tmp, tmp, tmp, tmp])

        if query_date and len(query_date) > 0:  # 日期范围  yesterday today  l7
            query.where('`login_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))
        # ############
        import pandas as pd
        data = query.select()

        start_time, end_time = public.get_query_timestamp(query_date)
        # 转化为 Timestamp 对象
        start_time = pd.Timestamp.fromtimestamp(start_time)
        end_time = pd.Timestamp.fromtimestamp(end_time)

        # 建立时间索引序列
        if type == 'day':
            time_format = '%Y-%m-%d'
            date_range = pd.date_range(start=start_time.date(), end=end_time.date(), freq='D')
        elif type == 'hour':
            time_format = '%Y-%m-%d %H:00:00'
            date_range = pd.date_range(start=start_time.floor('H'), end=end_time.floor('H'), freq='H')
        elif type == 'minute':
            time_format = '%Y-%m-%d %H:%M:00'
            date_range = pd.date_range(start=start_time.floor('T'), end=end_time.floor('T'), freq='T')
        else:
            return None

        login_counts = {time.strftime(time_format): {'count': 0, 'fail': 0, 'success':0} for time in date_range}
        for login in data:
            login_time = pd.Timestamp.fromtimestamp(login['login_time'])
            if start_time <= login_time <= end_time:
                time_str = login_time.strftime(time_format)
                login_counts[time_str]['count'] += 1
                if login['success'] == 0:
                    login_counts[time_str]['fail'] += 1
                else:
                    login_counts[time_str]['success'] += 1

        count_data = []
        for time_str, counts in login_counts.items():
            d = {'time': time_str, 'count': counts['count'], 'fail': counts['fail'], 'success': counts['success']}
            count_data.append(d)

        # 按时间顺序排序
        count_data.sort(key=lambda x: x['time'])

        return public.success(count_data)

    # ssh执行命令 聚合
    def ssh_command_execute_logs_aggregation(self, args):
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        type = args.get('type', None)
        if sid is None:
            return public.error('缺少参数：sid')
        if sid == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sid.split(',')
            # 转换为int类型
            sids = list(map(lambda x: int(x), sids))

        # 组装查询构造器
        query = basic_monitor_obj.db_easy('command_execute_logs') \
            .where_in('sid', sids) \
            .field('user', '{} as command'.format("'****'" if basic_monitor_obj.in_demo() else 'command'),
                   'create_time', 'sid')

        # 添加关键字查询
        def query_handler(query, keyword):
            k = '%{}%'.format(keyword)
            query.where('user like ?', k) \
                .where_or('command like ?', k)
        public.add_retrieve_keyword_query(query, args, query_handler)

        if query_date and len(query_date) > 0:  # 日期范围  yesterday today  l7
            query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))


        # 统计--------------------------------
        import pandas as pd
        data = query.select()
        # 开始时间 结束时间
        start_time, end_time = public.get_query_timestamp(query_date)
        # 转化为 Timestamp 对象
        start_time = pd.Timestamp.fromtimestamp(start_time)
        end_time = pd.Timestamp.fromtimestamp(end_time)

        # 建立时间索引序列
        if type == 'day':
            time_format = '%Y-%m-%d'
            date_range = pd.date_range(start=start_time.date(), end=end_time.date(), freq='D')
        elif type == 'hour':
            time_format = '%Y-%m-%d %H:00:00'
            date_range = pd.date_range(start=start_time.floor('H'), end=end_time.floor('H'), freq='H')
        elif type == 'minute':
            time_format = '%Y-%m-%d %H:%M:00'
            date_range = pd.date_range(start=start_time.floor('T'), end=end_time.floor('T'), freq='T')
        else:
            return None

        # 生成时间序列对应的字典
        login_counts = {time.strftime(time_format): 0 for time in date_range}

        # 统计登录次数
        for login in data:
            create_time = pd.Timestamp.fromtimestamp(login['create_time'])
            if start_time <= create_time <= end_time:
                time_str = create_time.strftime(time_format)
                login_counts[time_str] += 1

        # 将结果转化
        count_data = []
        for time_str, count in login_counts.items():
            d = {'time': time_str, 'count': count}
            count_data.append(d)

        # 按时间顺序排序
        count_data.sort(key=lambda x: x['time'])

        return public.success(count_data)

    # 服务器sid 授权 linux
    def __get_server_sid(self):
        '''
            @name 获取服务器sid 未授权 linux
        '''
        sids = warning_obj.db_easy('servers') \
            .field('sid', ) \
            .where('is_authorized', 1) \
            .where('type', 0) \
            .column('sid')
        return sids

    # ssh登录日志
    def get_ssh_login_logs_new(self, args):
        '''
            @name 获取SSH登录日志列表
            @author Zhj<2022-06-28>
            @arg    status<?integer>    SSH登录状态 0-登录失败 1-登录成功
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @arg    sid<?integer>       主机ID[可选]
            @arg    keyword<?string>    关键字[可选]
            @return list
        '''

        status = args.get('status', None)
        sid = args.get('sid', '-1')
        keyword = args.get('keyword', None)
        query_date = args.get('query_date', None)

        # 选择了全部主机
        if sid == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sid.split(',')
            # 转换为int类型
            sids = list(map(lambda x: int(x), sids))

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', sids) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        # 查询本月数据库
        query = basic_monitor_obj.db_easy('ssh_login_logs_latest') \
            .field('id', 'sid', 'user', 'ip as login_ip', 'ip_place', 'login_time', 'success', 'port') \
            .order('login_time', 'desc') \
            .where_in('sid', sids)

        if status is not None and str(status) in ['0', '1']:
            query.where('success', int(status))

        if keyword is not None and len(keyword) > 0:
            tmp = '%{}%'.format(keyword)
            query.where('user like ? OR ip like ? OR ip_place like ? OR login_time like ?', [tmp, tmp, tmp, tmp])

        if query_date and len(query_date) > 0:  # 日期范围  yesterday today  l7
            query.where('`login_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

        # 导出用数据 备份条件
        ret_data_ = query.fork()
        # 分页
        ret = public.simple_page(query, args)

        login_ip_idx_map = {}
        i = 0

        for item in ret['list']:
            if item['ip_place'] == '' and item['login_ip'] != '':
                if item['login_ip'] not in login_ip_idx_map:
                    login_ip_idx_map[item['login_ip']] = []

                login_ip_idx_map[item['login_ip']].append(i)

            server_info = servers.get(int(item['sid']), {})

            item['ip'] = server_info.get('ip', '')
            item['login_ip'] = '{}{}'.format(
                item['login_ip'], ':{}'.format(item['port'])
                if int(item['port']) > 0 else '')
            item['remark'] = server_info.get('remark', '')
            del (item['port'])

            i += 1

        if args.get('export_log', None) == '1':
            ret_export_log = ret_data_.select()

            if ret_export_log is None or len(ret_export_log) < 1:
                return public.error('没有可导出的数据')

            for item in ret_export_log:
                server_info = servers.get(int(item['sid']), {})
                item['ip'] = server_info.get('ip', '')
                item['login_ip'] = '{}{}'.format(
                    item['login_ip'], ':{}'.format(item['port'])
                    if int(item['port']) > 0 else '')
                item['remark'] = server_info.get('remark', '')

            import pandas as pd
            # 处理数据
            for i in ret_export_log:
                i['login_time'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(i['login_time']))
                i['success'] = '成功' if i['success'] == 1 else '失败'

            # 将数据转换为DataFrame对象
            df = pd.DataFrame(ret_export_log)

            #  选择需要导出的字段
            selected_columns = {"id": "编号", "remark": "服务器", "ip": "服务器IP", "login_ip": "登录IP", "login_time": "登录时间",
                                "user": "用户", "success": "状态"}

            selected_df = df[list(selected_columns.keys())].rename(columns=selected_columns)

            # # 导出数据到CSV文件中
            export_file_path = "/tmp/exported_ssh_login_logs.csv"
            selected_df.to_csv(export_file_path, index=False)
            from datetime import date
            return public.send_file('/tmp/exported_ssh_login_logs.csv', 'ssh_login_logs_{}.csv'.format(date.today()))

        return public.success(ret)

    # 同步SSH登录日志----
    # 每三月ssh登录记录表
    def ssh_login_logs_latest_database(self):
        '''
            @name 初始化ssh登录日志数据库 用于存储最近三月的数据
            @return void
        '''
        path = '{}/data/monitor_databases/ssh_login_logs_latest.db'.format(public.get_panel_path())
        SshLoginLogsLatest = monitor_db_manager.SshLoginLogsLatest
        if not os.path.exists(path):
            # 不存在时 创建数据库
            SshLoginLogsLatest().init_ssh_login_logs_db()
        else:
            # 存在时 查看第一条数据是否在三月前 是-删除数据库 否-退出
            # 查询本月数据库
            login_time = basic_monitor_obj.db_easy('ssh_login_logs_latest') \
                .field('id', 'login_time',) \
                .value('min(`login_time`)')
            if (login_time or 0) < SshLoginLogsLatest().MONTH3_AGO:
                os.remove(path)
                # 创建数据库
                SshLoginLogsLatest().init_ssh_login_logs_db()
            else:
                return False

        # 同步三月内的数据
        SshLoginLogsLatest().sync_ssh_login_logs_database(True)
        # 记录同步时间
        SshLoginLogsLatest().record_sync_time(True)

    # 每20min同步一次
    def ssh_login_logs_latest_sync(self):
        '''
            @name ssh登录日志数据库20min同步一次
            @return void
        '''
        path = '{}/data/monitor_databases/ssh_login_logs_latest.db'.format(public.get_panel_path())
        SshLoginLogsLatest = monitor_db_manager.SshLoginLogsLatest
        if not os.path.exists(path):
            # 不存在时 创建数据库
            SshLoginLogsLatest().init_ssh_login_logs_db()

        # 存在时 更新20min内的数据
        SshLoginLogsLatest().sync_ssh_login_logs_database(False)
        # 记录同步时间
        SshLoginLogsLatest().record_sync_time(True)



    def __automatic_scan_help_v2(self, scan_dirs):
        """
        自动扫描帮助函数
        :param scan_dirs<list>:扫描目录列表
        """

        servers = warning_obj.db_easy('servers') \
            .field('sid', 'ip', 'remark') \
            .where('is_authorized', 1) \
            .where('type', 0) \
            .select()

        # 组装主机在线状态
        for server_info in servers:
            _, _, server_info['status'] = basic_monitor_obj.cache_server_status(server_info['sid'])

        # 过滤掉离线的主机
        sids = [info['sid'] for info in servers if info['status'] == 1]

        if len(sids) == 0:
            return public.error("请添加主机授权后进行设置！")
        task_dirs = []
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 查找扫描任务
            task_ids = db.query().name('malicious_scan_tasks').where('is_automatic', 1).column('id')
            # public.print_log('000 查找任务了 {}'.format(task_ids), _level='error')
            if not task_ids:
                # 创建新的任务 新关联表
                task_dirs = self.__add_scan_help(sids, scan_dirs, 2, 0, 1)
                # public.print_log('000 新建任务了', _level='error')
            else:
                # # 更新关联表
                # old_sid = db.query().name('server_malicious_scan_task').where_in('task_id', task_ids).column('sid')
                # diff = list(set(servers) - set(old_sid))
                # if len(diff) > 0:  # 中间表加新
                #     db.autocommit(False)
                #     try:
                #         insert_data = []
                #         for item in diff:
                #             for task in task_ids:
                #                 insert_data.append({
                #                     'task_id': task,
                #                     'sid': item,
                #                 })
                #
                #         db.query().name('server_malicious_scan_task').insert_all(insert_data)
                #
                #         # 提交事务
                #         db.commit()
                #
                #     except BaseException as e:
                #         # 回滚事务
                #         db.rollback()
                #
                #         # 打印异常堆栈
                #         public.print_exc_stack(e)
                #
                # 重组task_dirs
                for tid in task_ids:
                    for dr in scan_dirs:
                        task_dirs.append((tid, dr))

                # 关闭事务自动提交
                db.autocommit(False)
                try:
                    # 修改任务状态 进度
                    a = db.query() \
                        .name('malicious_scan_tasks') \
                        .where_in('id', task_ids) \
                        .update({
                            'status': 0,
                            'scan_progress': 0
                        })
                    # public.print_log('000 修改任务状态了  {}'.format(a), _level='error')

                    db.query().name('server_malicious_scan_task').where_in('task_id', task_ids).delete()  # 删掉之前关联表
                    # public.print_log('000 删除关联表了', _level='error')
                    insert_data = []
                    for sid in sids:
                        for task in task_ids:
                            insert_data.append({
                                'task_id': task,
                                'sid': sid,
                            })

                    c = db.query().name('server_malicious_scan_task').insert_all(insert_data)
                    # public.print_log('000 重建关联表了  {}'.format(c), _level='error')

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()
                    # 打印异常堆栈
                    public.print_exc_stack(e)


        # 调用被控执行
        self.__exec_task_help(sids, task_dirs)
        # public.print_log('000 调用被控执行了', _level='error')

        # with ThreadPoolExecutor(max_workers=10) as t:
        #     fs = []
        #
        #     id_list = []
        #     for item in servers:
        #         for ids, dirs in task_dirs:
        #             fs.append(t.submit(self.__scan_task_help, item, 'ScanDir', {
        #                 'dir': dirs,
        #                 'id': str(ids),
        #             }))
        #
        #             id_list.append(ids)
        #
        #     for f in fs:
        #         f.result()

        # 记录日志
        public.WriteLog('安全监控病毒扫描', '执行自动扫描任务')

    def __automatic_scan_help(self, scan_dirs, immediate=False):

        return self.__automatic_scan_help_v2(scan_dirs)

        servers = basic_monitor_obj.db_easy('servers') \
            .where('is_authorized = 1') \
            .where('type = 0') \
            .where('status = 1 ')\
            .field('sid', 'ip', 'remark') \
            .column('sid')

        if len(servers) == 0:
            return public.error("请添加主机授权后进行设置！")

        # 添加扫描任务
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            sql_sid = db.query().name('server_malicious_scan_task').column('sid')
            diff = list(set(servers) - set(sql_sid))
            flags = False
            if len(diff) > 0 or not flags:
                # 关闭事务自动提交
                db.autocommit(False)

                try:
                    i = 1
                    task_ids = []
                    for temp in scan_dirs:
                        task_id = db.query().name('malicious_scan_tasks').insert({
                            'scan_dir': temp,
                            'scan_type': int(2),
                            'name': '任务{}'.format(time.strftime('%Y_%m_%d_%H%M' + str(i))),
                        })
                        i += 1

                        task_ids.append((task_id, temp))

                    insert_data = []

                    for item in servers:
                        for task, _ in task_ids:
                            insert_data.append({
                                'task_id': task,
                                'sid': item,
                            })

                    db.query().name('server_malicious_scan_task').insert_all(insert_data)

                    # 提交事务
                    db.commit()
                    flags = True
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            id_list = []
            for item in servers:
                for ids, dirs in task_ids:
                    fs.append(t.submit(self.__scan_task_help, item, 'ScanDir', {
                        'dir': dirs,
                        'id': str(ids),
                    }))

                    id_list.append(ids)

            for f in fs:
                f.result()

        # 设置立即扫描任务状态
        if immediate:
            cache.set('immediate_scan_task', 1, 600)

        # 记录日志
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            name_list = db.query().name('malicious_scan_tasks').where_in('id', id_list).field('name',
                                                                                              'scan_dir').select()
            for temp in name_list:
                public.WriteLog('安全监控病毒扫描',
                                '添加扫描任务【{}】扫描目录【{}】'.format(temp['name'], temp['scan_dir']))

    # 病毒扫描-自动扫描
    def automatic_scan(self, args={}):
        scan_dirs = ['/www', '/root', '/tmp', '/home']
        now_exe = args.get('now_exe/d', 1)

        config = public.read_config('config')
        if not config['automatic_scan']:
            # public.print_log('自动扫描未开启', _level='error')
            return public.success("添加成功")

        if not now_exe:
            # public.print_log('自动扫描未立即执行', _level='error')
            return public.success("添加成功")

        from core.include.monitor_helpers import message_push_queue
        message_push_queue.add_task_easy(self.__automatic_scan_help, scan_dirs)
        # public.print_log('自动扫描 任务已推入队列', _level='error')
        return public.success("添加成功")

    # 病毒扫描-立即扫描
    def immediate_scan(self, args):
        scan_dirs = ['/www', '/root', '/tmp', '/home']
        # 加锁
        import core.include.Locker as Locker
        with Locker.acquire_with_file(timeout=60):
            flag = cache.get('immediate_scan_task')
            if flag is not None and flag == 0:
                return public.error("请求频繁，请稍后再试！")

            # 设置立即扫描任务状态
            cache.set('immediate_scan_task', 0, 600)
            from core.include.monitor_helpers import message_push_queue
            message_push_queue.add_task_easy(self.__automatic_scan_help, scan_dirs, immediate=True)

        return public.success("正在创建任务，请稍后...")


    # 入侵检测 加白 启停 删除 告警  操作(处理) 统计  设置开关和告警
    # 入侵检测统计
    def get_hids_count(self, args):
        """
        @name 入侵检测列表
        @author lt<2023-06-13>
        @return dict
        """
        # sid = args.get('sid', None)
        # if sid is None:
        #     return public.error('缺少参数：sid')
        #
        # # 选择了全部主机
        # if sid == '-1':
        #     sids = self.__get_server_sid()
        # else:
        #     sids = sid.split(',')
        #     # 转换为int类型
        #     sids = list(map(lambda x: int(x), sids))

        sids = self.__get_server_sid()

        conf_id = basic_monitor_obj.db_easy('warning_configurations') \
            .where('add_source', 2) \
            .value('max(`id`)')
        if conf_id:
            warning_tasks_num = basic_monitor_obj.db_easy('warning_tasks') \
                .where_in('sid', sids) \
                .where('conf_id', conf_id) \
                .where('status', 0) \
                .count()
        else:
            warning_tasks_num = 0

        #  'SUM(`white`!=0) AS `white_num`',
        with monitor_db_manager.db_mgr('hids') as db:
            query = db.query() \
                .name('hids_list') \
                .where_in('sid', sids)\
                .where('white', 0) \
                .field('count(*) as `total_num`',
                       'SUM(`status`=0) AS `unhandled_num`',
                       'SUM(`status`=1) AS `handled_num`',
                       'SUM(`level`=0) AS `level_0`',
                       'SUM(`level`=1) AS `level_1`',
                       'SUM(`level`=2) AS `level_2`',
                       'SUM(`level`=3) AS `level_3`',
                       'max(create_time) AS `last_scan_time`') \
                .find()
            white_rule_num = db.query().name('hids_white_list').count()
            query['white_rule_num'] = white_rule_num
            query['warning_tasks_num'] = warning_tasks_num

            return public.success(query)


    # 入侵检测列表
    def get_hids_list(self, args):
        """
        @name 入侵检测列表
        @author lt<2023-06-13>
        @param args<dict> 请求参数列表
        @return dict
        """
        # 筛选 搜索 分页
        sid = args.get('sid', None)
        data_type = args.get('data_type', None)
        level = args.get('level', None)
        status = args.get('status', None)
        query_date = args.get('query_date', None)

        if sid is None:
            return public.error('缺少参数：sid')

        # 选择了全部主机
        if sid == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sid.split(',')
            # 转换为int类型
            sids = list(map(lambda x: int(x), sids))

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', sids) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('hids') as db:
            settings_num = db.query().name('hids_setting').where_in('sid', sids).where('open', 1).count()

            query = db.query() \
                .name('hids_list') \
                .where_in('sid', sids)\
                .where_in('white', 0)\
                .order('create_time', 'desc')

            # 处理状态
            if status is not None and len(str(status)) > 0:
                query.where('status', int(status))
            # 等级
            if level is not None and len(str(level)) > 0:
                query.where('level', int(level))
            # 类型 数字
            if data_type is not None and len(str(data_type)) > 0:
                query.where('data_type', data_type)
            # 日期
            if query_date is not None and len(str(query_date)) > 0:
                query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询cve编号
                if re.match(r'^cve-\d+-\d+', keyword, flags=re.IGNORECASE):
                    query.where('`cve_id` like ?', '{}%'.format(keyword))
                    return

                # 名称 OR 进程二进制文件 OR 进程PID OR 进程命令行 OR 描述 OR 修复建议
                where_or = [
                    '`vulnname` like ?',
                    '`msg` like ?',
                    '`exe` like ?',
                    '`pid` like ?',
                    '`argv` like ?',
                    '`suggestions` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 添加排序
            public.add_retrieve_sort_query(query, args)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        handled_operators = None  # 处理人
        with monitor_db_manager.db_mgr('safety') as db:

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')

            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')

        ret['set'] = 1 if settings_num > 0 else 0
        return public.success(ret)

    # 入侵检测处理 撤回
    def set_hids_handle(self, args):
        '''
            @name 处理入侵检测
            @author lt<2023-06-13>
            @param args<dict> 请求参数
            @return dict
        '''
        # sid = args.get('sid', None)
        id = args.get('id', None)  # 可批量
        handled = args.get('handled', None)
        uid = public.bt_auth('uid')

        # if sid is None:
        #     return public.error('缺少参数：sid')
        if id is None:
            return public.error('缺少参数：id')
        if handled is None:
            return public.error('缺少参数：handled')

        vuln_id = str(id).split(',')

        with monitor_db_manager.db_mgr('hids') as db:
            # 开启事务
            db.autocommit(False)
            db.query() \
                .name('hids_list') \
                .where_in('id', vuln_id) \
                .update({
                    'status': int(handled),
                    'handle_operator': uid,
                    'handled_time': int(time.time()),
                })
            db.commit()

            # 记录日志
            sss = db.query().name('hids_list').where_in('id', vuln_id).field('vulnname').column('vulnname')
        # server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()
        handled_ = '处理' if handled == 1 else '撤回处理'
        for i in sss:
            public.WriteLog('安全监控入侵检测', '%s入侵检测【%s】' % (handled_, i))
        return public.success('操作成功')

    # 入侵检测删除
    def del_hids(self, args):
        '''
            @name 处理入侵删除检测记录 批量
            @author lt<2023-06-13>
            @param args<dict> 请求参数
            @return dict
        '''
        id = args.get('id', None)  # 可批量

        if id is None:
            return public.error('缺少参数：id')

        vuln_id = str(id).split(',')
        # 转换为int
        vuln_id = list(map(lambda x: int(x), vuln_id))

        with monitor_db_manager.db_mgr('hids') as db:
            # 记录日志
            sss = db.query().name('hids_list').where_in('id', vuln_id).field('vulnname').column('vulnname')

            # 开启事务
            db.autocommit(False)
            db.query() \
                .name('hids_list') \
                .where_in('id', vuln_id) \
                .delete()

            db.commit()

        # server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()

        for i in sss:
            public.WriteLog('安全监控入侵检测', '删除入侵检测记录【%s】' % i)
        return public.success('删除成功')

    # 入侵检测启停展示
    def get_hids_status(self, args):
        '''
            @name 入侵检测启停开关展示
            @author lt<2023-06-13>
            @param args<dict> 请求参数
            @return dict
        '''

        sids = self.__get_server_sid()

        with monitor_db_manager.db_mgr('hids') as db:
            # query = db.query().name('hids_setting').where_in('sid', sids).field('sid').select()
            sid_list = db.query().name('hids_setting').where_in('sid', sids).field('sid').column('sid')
            warning = db.query().name('hids_warning').where_in('sid', sids).field('sid', 'count').find()

        data = {
            'sid_list': sid_list,
            'count': warning['count'] if warning else 1
        }

        return public.success(data)

    # 入侵检测启停设置 批量
    def set_hids_status(self, args):
        '''
            @name 入侵检测启停设置 批量
            @author lt<2023-06-13>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)  # 可批量
        open = args.get('open/d', None)
        count = args.get('count/d', None)

        if sid is None or len(sid) == 0:
            return public.error('缺少参数：sid')


        sids = sid.split(',')
        # 转换为int类型
        sids = list(map(lambda x: int(x), sids))
        setting_insert_data = []
        warning_insert_data = []
        for i in sids:
            setting_insert_data.append({
                'sid': i,
                'open': int(open),
            })
            warning_insert_data.append({
                'sid': i,
                'open': int(open),
                'count': int(count),
            })


        server_infos = warning_obj.db_easy('servers') \
            .field('ip', 'remark', 'sid') \
            .where_in('sid', sids) \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('hids') as db:
            # 开启事务
            db.autocommit(False)
            # 先删除 再添加
            db.query().name('hids_setting').delete()
            db.query().name('hids_setting').insert_all(setting_insert_data)

            db.query().name('hids_warning').insert_all(warning_insert_data, option='replace')

            db.commit()
        # 推消息队列执行被控开关的方法
        from core.include.monitor_helpers import message_push_queue
        message_push_queue.add_task_easy(self._hids_automatic_switch_help, setting_insert_data)

        # 记录日志
        open_ = '开启' if open == 1 else '关闭'
        for i in sids:
            public.WriteLog('安全监控入侵检测', '设置%s 【%s（%s）】的入侵检测' % (open_,server_infos[i]['remark'],server_infos[i]['ip']))
        return public.success('设置成功')

    # 一键修改已设置的服务器 入侵检测开关
    def set_hids_status_simple(self, args):
        open = args.get('open/d', None)
        if open is None:
            return public.error('缺少参数：open')

        with monitor_db_manager.db_mgr('hids') as db:
            old_sid = db.query().name('hids_setting').field('sid').column('sid')

            if old_sid is None:
                return public.error('请先设置服务器的入侵检测开关')
            # 开启事务
            db.autocommit(False)
            db.query().name('hids_setting').where_in('sid', old_sid).update({'open': int(open)})
            db.query().name('hids_warning').where_in('sid', old_sid).update({'open': int(open)})
            db.commit()

        # 推消息队列执行被控开关的方法
        from core.include.monitor_helpers import message_push_queue
        open_data = []
        for i in old_sid:
            open_data.append({
                'sid': i,
                'open': int(open),
            })
        message_push_queue.add_task_easy(self._hids_automatic_switch_help, open_data)

        # 记录日志
        open_ = '开启' if open == 1 else '关闭'
        public.WriteLog('安全监控入侵检测', '修改已设置的服务器入侵检测为%s状态' % open_)

        return public.success('设置成功')

    # 入侵检测启停修改 批量
    def update_hids_status(self, args):
        '''
            @name 入侵检测启停设置 批量
            @author lt<2023-06-13>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)  # 可批量
        open = args.get('open/d', None)

        if sid is None:
            return public.error('缺少参数：sid')

        sids = sid.split(',')
        # 转换为int类型
        sids = list(map(lambda x: int(x), sids))

        server_infos = warning_obj.db_easy('servers') \
            .field('ip', 'remark', 'sid') \
            .where_in('sid', sids) \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('hids') as db:
            db.query().name('hids_setting').where_in('sid', sids).update({'open': int(open)})

        # 推消息队列执行被控开关的方法
        from core.include.monitor_helpers import message_push_queue
        open_data = []
        for i in sids:
            open_data.append({
                'sid': i,
                'open': int(open),
            })
        message_push_queue.add_task_easy(self._hids_automatic_switch_help, open_data)

        # 记录日志
        open_ = '开启' if open == 1 else '关闭'
        for i in sids:
            public.WriteLog('安全监控入侵检测', '%s 【%s（%s）】的入侵检测' % (open_,server_infos[i]['remark'],server_infos[i]['ip']))
        return public.success('修改成功')

    # 入侵检测加白规则  扫一下前面的是否有符合白名单的
    def add_hids_white_list(self, args):
        '''
            @name 添加入侵检测白名单
            @author lt<2023-06-14>
            @param args<dict> 请求参数
            @return dict
        '''
        type = args.get('data_type', None)
        ps = args.get('ps', None)
        vulnname = args.get('vulnname', None)
        # match_detail = args.get('match_detail', None)
        match_detail = args.get('match_detail/json', None)
        uid = public.bt_auth('uid')

        if type is None:
            return public.error('缺少参数：data_type')
        if ps is None:
            return public.error('缺少参数：ps')
        if vulnname is None:
            return public.error('缺少参数：vulnname')
        if match_detail is None:
            return public.error('缺少参数：match_detail')

        titles = {
            'pid_tree': '进程树',
            'username': '用户名',
            'dip': '目标IP',
            'sport': '监听端口',
            'ssh': '外联ssh登录信息',
            'socket_argv': '外联进程命令行',
            'run_path': '执行目录',
            'stdin': '进程输入',
            'stdout': '进程输出',
            'exe': '进程二进制文件',
            'pid ': '进程PID	',
            'argv': '进程命令行',
        }

        # match_detail = [{"key":"socket_argv","value":"/usr/local/btmonitoragent/BT-MonitorAgent"},{"key":"ssh","value":"-1"},{"key":"run_path","value":"/usr/local/btmonitoragent"},{"key":"stdin","value":"pipe:[105194]"},{"key":"stdout","value":"pipe:[105191]"},{"key":"sport","value":"53146"},{"key":"dip","value":"192.168.1.47"},{"key":"exe","value":"/usr/bin/grep"},{"key":"argv","value":"grep g.version ="},{"key":"username","value":"root"},{"key":"pid_tree","value":"18688.grep<18686.bash<18677.systeminfo<18265.BT-MonitorAgent<1.systemd"}]

        # 如果有相同key 添加失败
        repetition = self._check_white_list_repetition(match_detail)
        if repetition:
            return public.error('白名单条件不能重复添加')

        match_detail_ = []
        for item in match_detail:
            if item['key'] in titles:
                title = titles[item['key']]
                match_detail_.append({'key': item['key'], 'value': item['value'], 'title': title})

        with monitor_db_manager.db_mgr('hids') as db:

            white_id = db.query().name('hids_white_list').insert({
                'type': int(type),
                'ps': ps,
                'vulnname': vulnname,
                'match_detail': json.dumps(match_detail_, ensure_ascii=False),
                'create_time': int(time.time()),
                'creator': uid,
                'match_type': 1
            })

        # 检测之前是否有符合白名单的 有的话就修改白名单id
        self._check_white_list(match_detail_, type, white_id)

        # 记录日志
        public.WriteLog('安全监控入侵检测', '添加入侵检测白名单 【{}-{}】'.format(ps, vulnname))

        return public.success('添加规则成功')

    # 判断白名单是否有相同的key
    def _check_white_list_repetition(self, lst):
        """
        @name 判断添加的白名单是否有相同的key
        @param lst<list> 添加的白名单规则列表
        @return bool   True:有相同的key False:没有相同的key
        """
        keys = set()
        for item in lst:
            if item['key'] in keys:
                return True
            keys.add(item['key'])
        return False

    # 展示入侵检测白名单
    def get_hids_white_list(self, args):
        """
        @name 入侵检测白名单列表
        @author lt<2023-06-14>
        @param args<dict> 请求参数列表
        @return dict
        """
        query_date = args.get('query_date', None)

        with monitor_db_manager.db_mgr('hids') as db:
            query = db.query() \
                .name('hids_white_list') \
                .order('create_time', 'desc')

            # 日期
            if query_date is not None and len(str(query_date)) > 0:
                query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询cve编号
                if re.match(r'^cve-\d+-\d+', keyword, flags=re.IGNORECASE):
                    query.where('`cve_id` like ?', '{}%'.format(keyword))
                    return

                # 名称 OR 进程二进制文件 OR 进程PID OR 进程命令行 OR 描述 OR 修复建议
                where_or = [
                    '`vulnname` like ?',
                    '`ps` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        handled_operators = None  # 处理人
        with monitor_db_manager.db_mgr('safety') as db:

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['creator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['creator_username'] = handled_operators.get(item['creator'], '--')

        return public.success(ret)

    # 删除入侵检测白名单
    def del_hids_white_list(self, args):
        '''
            @name 删除入侵检测白名单  同时修改任务里面的白名单id 改为0
            @author lt<2023-06-14>
            @param args<dict> 请求参数
            @return dict
        '''
        id = args.get('id', None)  # 可批量

        if id is None:
            return public.error('缺少参数：id')

        vuln_id = str(id).split(',')
        # 转换为int
        vuln_id = list(map(lambda x: int(x), vuln_id))

        with monitor_db_manager.db_mgr('hids') as db:

            # 开启事务
            db.autocommit(False)
            query = db.query() \
                .name('hids_white_list') \
                .where_in('id', vuln_id) \
                .field('vulnname') \
                .column('vulnname')

            db.query() \
                .name('hids_white_list') \
                .where_in('id', vuln_id) \
                .delete()

            # 同时修改任务里面的白名单id 改为0
            db.query() \
                .name('hids_list') \
                .where_in('white', vuln_id) \
                .update({'white': 0})
            db.commit()

        for i in query:
            # 记录日志
            public.WriteLog('安全监控入侵检测', '删除入侵检测白名单【%s】' % i)

        return public.success('删除规则成功')


    # 入侵检测告警展示 列表
    def get_hids_warning(self, args):
        '''
            @name 入侵检测告警展示
            @author lt<2023-06-13>
            @param args<dict> 请求参数
            @return dict
        '''

        sids = self.__get_server_sid()

        with monitor_db_manager.db_mgr('hids') as db:
            query = db.query().name('hids_warning').where_in('sid', sids).select()

        return public.success(query)

    # 入侵检测告警设置 批量
    def set_hids_warning(self, args):
        '''
            @name 入侵检测启停设置 批量
            @author lt<2023-06-13>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)  # 可批量
        open = args.get('open/d', None)
        count = args.get('count/d', None)

        if sid is None:
            return public.error('缺少参数：sid')

        sids = sid.split(',')
        # 转换为int类型
        sids = list(map(lambda x: int(x), sids))
        insert_data = []
        for i in sids:
            insert_data.append({
                'sid': i,
                'open': int(open),
                'count': int(count),
            })

        server_infos = warning_obj.db_easy('servers') \
            .field('ip', 'remark', 'sid') \
            .where_in('sid', sids) \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('hids') as db:
            # 开启事务
            db.autocommit(False)
            # 先删除 再添加
            # db.query().name('hids_warning').delete()
            db.query().name('hids_warning').insert_all(insert_data, option='replace')
            db.commit()

        # 记录日志
        open_ = '开启' if open == 1 else '关闭'
        for i in sids:
            public.WriteLog('安全监控入侵检测', '设置%s 【%s（%s）】的入侵检测告警开关' % (open_,server_infos[i]['remark'],server_infos[i]['ip']))
        return public.success('设置成功')

    # 入侵检测告警修改
    def update_hids_warning(self, args):
        '''
            @name 入侵检测启停设置 批量
            @author lt<2023-06-13>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid/d', None)
        open = args.get('open/d', None)
        count = args.get('count/d', None)

        if sid is None:
            return public.error('缺少参数：sid')

        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark', 'sid') \
            .where('sid', sid) \
            .find()

        update_data = {
            'open': open,
            'count': count,
        }

        with monitor_db_manager.db_mgr('hids') as db:
            db.query().name('hids_warning').where('sid', sid).update(update_data)

        # 记录日志
        open_ = '开启' if open == 1 else '关闭'
        public.WriteLog('安全监控入侵检测', '修改【%s（%s）】的入侵检测告警设置' % (server_info['remark'],server_info['ip']))
        return public.success('修改成功')

    # # 入侵检测告警修改
    # def update_hids_warning(self, args):
    #     '''
    #         @name 入侵检测启停设置 批量
    #         @author lt<2023-06-13>
    #         @param args<dict> 请求参数
    #         @return dict
    #     '''
    #     sid = args.get('sid', None)  # 可批量
    #     open = args.get('open', None)
    #
    #     if sid is None:
    #         return public.error('缺少参数：sid')
    #
    #     sids = sid.split(',')
    #     # 转换为int类型
    #     sids = list(map(lambda x: int(x), sids))
    #
    #     server_infos = warning_obj.db_easy('servers') \
    #         .field('ip', 'remark', 'sid') \
    #         .where_in('sid', sids) \
    #         .column(None, 'sid')
    #
    #     with monitor_db_manager.db_mgr('hids') as db:
    #         db.query().name('hids_setting').where_in('sid', sids).update({'open': int(open)})
    #
    #     # 记录日志
    #     open_ = '开启' if open == 1 else '关闭'
    #     for i in sids:
    #         public.WriteLog('安全监控入侵检测', '%s 【%s（%s）】的入侵检测告警' % (open_,server_infos[i]['remark'],server_infos[i]['ip']))
    #     return public.success('修改成功')


    #  一键修改已设置的服务器 入侵检测告警
    def set_hids_warning_simple(self, args):
        '''
        一键修改已设置的服务器 入侵检测告警
        '''
        open = args.get('open/d', None)
        if open is None:
            return public.error('缺少参数：open')

        with monitor_db_manager.db_mgr('hids') as db:
            old_sid = db.query().name('hids_warning').field('sid').column('sid')
            if old_sid is None:
                return public.error('请先设置服务器的入侵检测告警')
            # 开启事务
            db.autocommit(False)
            db.query().name('hids_warning').where_in('sid', old_sid).update({'open': int(open)})
            db.commit()

        # 记录日志
        open_ = '开启' if open == 1 else '关闭'
        public.WriteLog('安全监控入侵检测', '修改已设置的服务器入侵检测告警状态为%s告警' % open_)

        return public.success('设置成功')

    # 添加告警设置 全部设置为开启
    def hids_warning_all(self, args):

        sids = warning_obj.db_easy('servers') \
            .field('sid', ) \
            .where('is_authorized', 1) \
            .where('type', 0) \
            .column('sid')

        insert_data = []
        for i in sids:
            insert_data.append({
                'sid': i,
                'open': 1,
                'count': 1,
            })

        with monitor_db_manager.db_mgr('hids') as db:
            # 开启事务
            db.autocommit(False)
            db.query().name('hids_warning').insert_all(insert_data, option='replace')
            db.commit()
        return public.success('告警设置成功')

    # 获取告警信息列表
    def get_hids_warning_tasks(self, args):
        '''
            @name 获取告警任务列表 仅入侵检测使用
            @arg    sid<?integer>       主机ID
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @return list
        '''
        sid = args.get('sid', None)
        keyword = args.get('keyword', None)
        query_date = args.get('query_date', None)
        server_list = g.get("server_list", [])
        with monitor_db_manager.db_mgr() as db:
            # 查询模版id
            # conf_id = basic_monitor_obj.db_easy('warning_configurations') \
            #     .where('add_source', 2) \
            #     .value('max(`id`)')

            # 查询告警规则信息
            warning_confs = basic_monitor_obj.db_easy('warning_configurations') \
                .where('add_source', 2) \
                .field('max(`id`)', 'title', 'scores') \
                .column(None, 'max(`id`)')

            if not warning_confs:
                data = {'total': 0, 'list': []}
                # public.print_log('退出1111111 没有告警规则'.format(), _level='error')
                return public.success(data)

            # 获取键值
            conf_id = list(warning_confs.keys())[0]

        query = basic_monitor_obj.db_easy('warning_tasks') \
            .field('id', 'sid', 'title', 'content', 'status', 'is_pushed', 'create_time', 'conf_id') \
            .where_in("sid", server_list) \
            .where('conf_id', conf_id) \
            .order('create_time', 'desc')

        if keyword is not None:
            tmp = '%{}%'.format(keyword)
            sid_list = basic_monitor_obj.db_easy('servers') \
                .where('ip like ? OR remark like ?', [tmp, tmp]) \
                .field('sid') \
                .column('sid')

            query.where_in('sid', sid_list)

        if query_date is not None and len(query_date) > 0:
            query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

        if sid is not None and len(sid) > 0:  # g对象里有服务器ip列表
            # query.where('sid=?', int(sid))

            sids = sid.split(',')
            # 转换为int类型
            sids = list(map(lambda x: int(x), sids))
            query.where_in('sid', sids)

        # data = query.fork()
        ret = public.simple_page(query, args)

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret['list']))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in ret['list']:
            warning_conf = warning_confs.get(item['conf_id'], {})
            server_info = servers.get(item['sid'], {})
            item['scores'] = warning_conf.get('scores', 0)
            item['rule_name'] = warning_conf.get('title', '')
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            del (item['conf_id'])
            # del (item['sid'])

        # # 日志导出 export_log
        # if args.get('export_log', None) == '1':
        #     data = data.select()
        #
        #     if data is None or len(data) == 0:
        #         return public.error('没有可导出的数据')
        #     # # 查询告警规则信息
        #     # warning_confs = basic_monitor_obj.db_easy('warning_configurations') \
        #     #     .where_in('id', list(map(lambda x: x['conf_id'], data))) \
        #     #     .field('id', 'title', 'scores') \
        #     #     .column(None, 'id')
        #     #
        #     # # 查询服务器信息
        #     # servers = basic_monitor_obj.db_easy('servers') \
        #     #     .where_in('sid', list(map(lambda x: x['sid'], data))) \
        #     #     .field('sid', 'ip', 'remark') \
        #     #     .column(None, 'sid')
        #
        #     for item in data:
        #         warning_conf = warning_confs.get(item['conf_id'], {})
        #         server_info = servers.get(item['sid'], {})
        #         item['scores'] = warning_conf.get('scores', 0)
        #         item['rule_name'] = warning_conf.get('title', '')
        #         item['ip'] = server_info.get('ip', '')
        #         item['remark'] = server_info.get('remark', '')
        #         del (item['conf_id'])
        #         del (item['sid'])
        #
        #     import pandas as pd
        #     # 处理数据
        #     for i in data:
        #         i['create_time'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(i['create_time']))
        #         i['status'] = '已处理' if i['status'] == 1 else '未处理'
        #         i['is_pushed'] = '已推送' if i['is_pushed'] == 1 else '未推送'
        #         score = i['scores']
        #         if 0 <= score < 30:
        #             i['score'] = '低'
        #         elif 30 <= score < 60:
        #             i['score'] = '中'
        #         elif 60 <= score <= 100:
        #             i['score'] = '高'
        #         else:
        #             i['score'] = '无效分数'
        #     # 将数据转换为DataFrame对象
        #     df = pd.DataFrame(data)
        #     #  选择需要导出的字段
        #     selected_columns = {"id": "编号", "ip": "服务器IP", "create_time": "告警时间",
        #                         "score": "等级", "rule_name": "任务名", "title": "标题", "content": "内容",
        #                         "status": "状态", "is_pushed": "是否推送", "remark": "备注", }
        #
        #     selected_df = df[list(selected_columns.keys())].rename(columns=selected_columns)
        #
        #     # # 导出数据到CSV文件中
        #     export_file_path = "/tmp/exported_data_warning.csv"
        #     selected_df.to_csv(export_file_path, index=False)
        #     from datetime import date
        #     return public.send_file('/tmp/exported_data_warning.csv', 'warning_tasks_{}.csv'.format(date.today()))

        if ret is None or len(ret) == 0:
            ret = {'total': 0, 'list': []}

        return public.success(ret)




    # 白名单测试
    def test_white_list(self, args):
        with monitor_db_manager.db_mgr('hids') as db:
            # 根据规则类型区分
            white_list = db.query() \
                .name('hids_white_list') \
                .column(None, 'type')

        # public.print_log('(((((((((((((((((((((((()))   {}'.format(white_list), _level='error')

        return public.success(white_list)

    # 添加开关设置 测试
    def test_hids_automatic_switch(self, args):

        sids = warning_obj.db_easy('servers') \
            .field('sid', ) \
            .where('is_authorized', 1) \
            .where('type', 0) \
            .column('sid')

        insert_data = []
        for i in sids:
            insert_data.append({
                'sid': i,
                'open': 1,
            })

        with monitor_db_manager.db_mgr('hids') as db:
            # 开启事务
            db.autocommit(False)
            db.query().name('hids_setting').insert_all(insert_data, option='replace')
            db.commit()
        # 推消息队列执行被控开关的方法
        from core.include.monitor_helpers import async_call_queue
        async_call_queue.add_task_easy(self._hids_automatic_switch_help, insert_data)

    # 入侵检测列表 测试 不隐藏白名单
    def get_hids_list_test(self, args):
        """
        @name 入侵检测列表
        @author lt<2023-06-13>
        @param args<dict> 请求参数列表
        @return dict
        """
        # 筛选 搜索 分页
        sid = args.get('sid', None)
        data_type = args.get('data_type/d', None)
        level = args.get('level', None)
        status = args.get('status', None)
        query_date = args.get('query_date', None)

        if sid is None:
            return public.error('缺少参数：sid')

        # 选择了全部主机
        if sid == '-1':
            sids = self.__get_server_sid()
        else:
            sids = sid.split(',')
            # 转换为int类型
            sids = list(map(lambda x: int(x), sids))

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', sids) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('hids') as db:
            settings_num = db.query().name('hids_setting').where_in('sid', sids).where('open', 1).count()

            query = db.query() \
                .name('hids_list') \
                .where_in('sid', sids)\
                .order('create_time', 'desc')

            # 处理状态
            if status is not None and len(str(status)) > 0:
                query.where('status', int(status))
            # 等级
            if level is not None and len(str(level)) > 0:
                query.where('level', int(level))
            # 类型 数字
            if data_type is not None and len(str(data_type)) > 0:
                query.where('data_type', data_type)
            # 日期
            if query_date is not None and len(str(query_date)) > 0:
                query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询cve编号
                if re.match(r'^cve-\d+-\d+', keyword, flags=re.IGNORECASE):
                    query.where('`cve_id` like ?', '{}%'.format(keyword))
                    return

                # 名称 OR 进程二进制文件 OR 进程PID OR 进程命令行 OR 描述 OR 修复建议
                where_or = [
                    '`vulnname` like ?',
                    '`msg` like ?',
                    '`exe` like ?',
                    '`pid` like ?',
                    '`argv` like ?',
                    '`suggestions` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 添加排序
            public.add_retrieve_sort_query(query, args)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        handled_operators = None  # 处理人
        with monitor_db_manager.db_mgr('safety') as db:

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')

            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')

        ret['set'] = 1 if settings_num > 0 else 0
        return public.success(ret)



    # 同步被控入侵检测开关
    def _hids_automatic_switch_help(self, open_data):

        # start 开启 stop停止
        title = {0: 'stop', 1: 'start'}
        for i in open_data:
            public.send_agent_msg(
                public.get_serverid_bysid(i['sid']),
                'intrusion_detection',
                'SetStartStop',
                pdata=public.g_pdata({
                    'action': title[i['open']],
                }))


    # 检测新加入的白名单是否符合已有的规则
    def _check_white_list(self, match_detail,type, white_id):
        '''
            @name 检测新加入的白名单是否符合已有的规则
            @author lt<2023-06-14>
            @param match_detail<dict> 白名单规则
            @param type<int> 规则类型
            @param white_id<int> 白名单id
            @param args<dict> 请求参数
            @return dict
        '''
        # 获取所有的规则
        match_detail_dict = {item['key']: item['value'] for item in match_detail}

        # 获取所有的入侵详情规则
        with monitor_db_manager.db_mgr('hids') as db:
            query = db.query() \
                .name('hids_list') \
                .where('white', 0) \
                .where('data_type', type) \
                .field('id', 'exe', 'data_type', 'pid', 'argv', 'other') \
                .select()
            if query is None:
                return False

        # 将所有的规则转换为字典
        hids = []
        for i in query:
            # 将所有的规则转换为字典
            other = json.loads(i['other'])
            # 数据转成普通字典
            hids_dict = {item['key']: item['value'] for item in other}
            a = {
                'id': i['id'],
                'exe': i['exe'],
                'data_type': i['data_type'],
                'pid': i['pid'],
                'argv': i['argv'],
            }
            hids_dict.update(a)
            hids.append(hids_dict)

        # 判断是否有符合规则的
        # id_list = [d['id'] for d in hids if all(k in d and d[k] == match_detail_dict[k] for k in match_detail_dict)]
        id_list = []
        for d in hids:
            # 白名单的key在入侵详情中存在 并且值相等 说明入侵详情属于白名单
            if all(k in d and d[k] == match_detail_dict[k] for k in match_detail_dict):
                id_list.append(d['id'])

        if len(id_list) > 0:
            # 更新详情的白名单id
            with monitor_db_manager.db_mgr('hids') as db:
                # 开启事务
                db.autocommit(False)
                db.query() \
                    .name('hids_list') \
                    .where_in('id', id_list) \
                    .update({'white': white_id})
                db.commit()

        return True




    # # 定期删除病毒扫描任务结果(手动添加的任务)
    # def remove_scan_task(self, args):
    #     # 昨天的时间戳
    #     yesterday = int(time.time()) - 86400
    #
    #     with monitor_db_manager.db_mgr('malicious_scan') as db:
    #         # 删除一天前的数据
    #         ids = db.query() \
    #             .name('malicious_scan_tasks') \
    #             .where('is_automatic', 0) \
    #             .where('create_time>?', yesterday) \
    #             .column('id')
    #
    #         db.query() \
    #             .name('malicious_scan_tasks') \
    #             .where_in('id', ids) \
    #             .delete()
    #
    #         db.query() \
    #             .name('server_malicious_scan_task') \
    #             .where_in('task_id', ids) \
    #             .delete()
    #
    #         db.query() \
    #             .name('malicious_scan_results') \
    #             .where_in('task_id', ids) \
    #             .delete()





