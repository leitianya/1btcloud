#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-
#
# sqlite服务端与客户端模块
# Author Zhj<2022-12-06>

# import tracemalloc
# import objgraph
import pickle
import json
import os, socket, struct, sqlite3, queue, threading, time, traceback, re, copy, uuid
# import glob
import gc
import weakref
from functools import reduce
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from collections import deque
# import hmac
import zlib


_BASE_DIR = '/www/server/bt-monitor'


try:
    import msgpack
except ImportError:
    os.system('{}/pyenv/bin/pip install msgpack > /dev/null 2>&1'.format(_BASE_DIR))
    try:
        import msgpack
    except: pass


# 获取序列化模块
def serialize_module():
    try:
        return msgpack
    except:
        return pickle


# varint编码 -> bytes
def _varint_encode(num):
    res = b''

    while num > 127:
        res += struct.pack('B', 0x80 | (num & 0x7f))
        num >>= 7

    res += struct.pack('B', num)

    return res


# varint解码 -> num, length
def _varint_decode(bs):
    res = 0
    n = 0
    for shift in range(0, 64, 7):
        if n > len(bs) - 1:
            break

        res |= (bs[n] & 0x7f) << shift
        if (bs[n] & 0x80) == 0:
            break

        n += 1

    return res, n + 1


# 存储所有已排序的线程锁
_local = threading.local()


@contextmanager
def acquire(*locks, timeout=-1):
    '''
        @name 避免死锁
        @author Zhj
        @param locks<[]threading.Lock> 线程锁
        @param timeout<integer> 最长阻塞时间/秒
        @return None
    '''
    # 升序排序
    locks = sorted(locks, key=lambda x: id(x))

    # 确保按顺序加锁
    acquired = getattr(_local, 'acquired', [])
    if timeout <= 0 and acquired and max(id(lock) for lock in acquired) >= id(locks[0]):
        raise RuntimeError('Lock Order Violation')

    # 加锁
    acquired.extend(locks)
    _local.acquired = acquired

    try:
        # 按顺序加锁
        for lock in locks:
            lock.acquire(timeout=timeout)

        # 转出程序控制权
        yield
    finally:
        # 倒序释放锁
        for lock in reversed(locks):
            try:
                lock.release()
            except: pass
        del (acquired[-len(locks):],)


_GC_DISABLE_COUNT = 0
_GC_DISABLE_COUNT_LOCK = threading.Lock()


# 停用GC
def gc_disable():
    with acquire(_GC_DISABLE_COUNT_LOCK, timeout=1):
        global _GC_DISABLE_COUNT
        _GC_DISABLE_COUNT += 1
        if _GC_DISABLE_COUNT > 1:
            return
    gc.disable()


# 启用GC
def gc_enable():
    with acquire(_GC_DISABLE_COUNT_LOCK, timeout=1):
        global _GC_DISABLE_COUNT
        _GC_DISABLE_COUNT -= 1
        if _GC_DISABLE_COUNT > 0:
            return
    gc.enable()


def _is_number(s):
    '''
        @name 判断输入参数是否一个数字
        @author Zhj<2022-07-18>
        @param  s<string|integer|float> 输入参数
        @return bool
    '''
    try:
        float(s)
        return True
    except ValueError:
        pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass

    return False


# 通过接收到的数据检查socket是否关闭
def _socket_is_closed(msg):
    if len(msg) == 0:
        return True

    if len(msg) < 3 and _is_number(msg) and int(msg) in [-1, 0]:
        return True

    return False


# recv_data() -> socket_obj: socket.socket -> None|dict
def recv_data(socket_obj):
    if not isinstance(socket_obj, ClientSocket):
        raise RuntimeError('socket_obj must be a ClientSocket.')

    # # 获取报头长度字节
    # header_len_bytes = socket_obj.recv(4)
    #
    # # 避免客户端暴力断开连接，导致服务端无限循环
    # if _socket_is_closed(header_len_bytes):
    #     return None
    #
    # recv_header_len_len = len(header_len_bytes)
    #
    # # 获取完整的报头长度
    # while recv_header_len_len < 4:
    #     recv_tmp = socket_obj.recv(min(4, max(0, 4 - recv_header_len_len)))
    #
    #     if _socket_is_closed(recv_tmp):
    #         return None
    #
    #     header_len_bytes += recv_tmp
    #     recv_header_len_len = len(header_len_bytes)
    #
    # # 获取报头长度
    # header_len = struct.unpack('I', header_len_bytes)[0]

    header_len_bytes = b''

    # 获取报头长度
    while True:
        recv_tmp = socket_obj.recv(1)

        if _socket_is_closed(recv_tmp):
            return None

        header_len_bytes += recv_tmp

        if (struct.unpack('B', recv_tmp)[0] & 0x80) == 0:
            break

    header_len, _ = _varint_decode(header_len_bytes)

    # 获取报头信息字节
    header_bytes = b''
    recv_header_len = 0

    while recv_header_len < header_len:
        recv_tmp = socket_obj.recv(min(10485760, max(0, header_len - recv_header_len)))

        if _socket_is_closed(recv_tmp):
            return None

        header_bytes += recv_tmp
        recv_header_len = len(header_bytes)

    try:
        # 获取报头信息
        # headers = json.loads(header_bytes)
        headers = serialize_module().loads(header_bytes)
    except UnicodeError as e:
        _log(header_len_bytes)
        _log(header_bytes)
        raise e

    # # 校验数据包签名
    # if 'signature' not in headers:
    #     raise RuntimeError('recv data from socket-{} failed: Missing signature in headers.'.format(id(socket_obj)))

    # 获取数据
    s_time = time.time()  # 记录读取数据包开始时间
    data = b''
    recv_len = 0

    while recv_len < headers['data_len']:
        recv_tmp = socket_obj.recv(min(10485760, max(0, headers['data_len'] - recv_len)))

        if _socket_is_closed(recv_tmp):
            return None

        data += recv_tmp
        recv_len = len(data)

    # # 校验数据包签名
    # if headers['signature'] != hmac.new(b'2b04c30c18e834f3', data[:1024], 'sha256').hexdigest():
    #     raise RuntimeError('recv data from socket-{} failed: Invalid signature.'.format(id(socket_obj)))

    # 检查是否需要解压
    if headers.get('compressed', False):
        data = zlib.decompress(data)

    e_time = time.time()  # 记录读取数据包到反序列化后的时间

    if e_time - s_time > 0.1:
        _log2('client-socket-{} recv data cost time: {}ms'.format(id(socket_obj), round((e_time - s_time) * 1000, 2)))

    gc_disable_flag = len(data) > 524288

    try:
        if gc_disable_flag:
            gc_disable()
        # return json.loads(data)
        # return pickle.loads(data)
        return serialize_module().loads(data)
    except:
        _log2(data)
        raise
    finally:
        if gc_disable_flag:
            gc_enable()


# send_data() -> socket_obj: socket.socket -> data: dict -> None
def send_data(socket_obj, data):
    if not isinstance(socket_obj, ClientSocket):
        raise RuntimeError('socket_obj must be a ClientSocket')

    if not isinstance(data, dict):
        raise RuntimeError('data must be a dict object.')

    # 序列化数据并转为字节
    # serialized_data_bytes = json.dumps(data).encode()
    # serialized_data_bytes = pickle.dumps(data, pickle.HIGHEST_PROTOCOL)
    serialized_data_bytes = serialize_module().dumps(data)

    # 计算序列化后的数据长度
    data_len = len(serialized_data_bytes)

    # # 判断数据是否要进行分包发送
    # if data_len > 51200:
    #     socket_obj.sendall_multi(serialized_data_bytes, data_len)
    #     return

    compressed = False

    # 判断数据是否需要进行压缩
    # if data_len > 262144:
    #     compressed = True
    #     serialized_data_bytes = zlib.compress(serialized_data_bytes)
    #     data_len = len(serialized_data_bytes)

    # 生成报头信息
    headers = {
        'compressed': compressed,  # 是否压缩
        'data_len': data_len,  # 数据包大小
        # 'signature': hmac.new(b'2b04c30c18e834f3', serialized_data_bytes[:1024], 'sha256').hexdigest(),  # 数据包签名
    }

    # 序列化报头信息并转为字节
    # serialized_headers_bytes = json.dumps(headers).encode()
    serialized_headers_bytes = serialize_module().dumps(headers)

    # 计算报头长度
    header_len = len(serialized_headers_bytes)

    # 计算报头长度并使用struct模块转换为固定长度的无符号整型(4字节)
    # header_len_bytes = struct.pack('I', header_len)

    # 将报头长度转为varint
    header_len_bytes = _varint_encode(header_len)

    # 发送消息
    socket_obj.sendall(header_len_bytes + serialized_headers_bytes + serialized_data_bytes)

    gc_collect_flag = len(serialized_data_bytes) > 524288

    data = None
    serialized_headers_bytes = None
    serialized_data_bytes = None
    data_len = None
    header_len = None
    header_len_bytes = None
    headers = None
    socket_obj = None
    del (data, serialized_data_bytes, data_len, headers, serialized_headers_bytes, header_len, header_len_bytes, socket_obj)

    if gc_collect_flag:
        del (gc.garbage[:],)
        gc.collect()


# @deprecated 未使用
# _build_send_data() -> data_bytes: byte -> header_extra: None|dict -> byte
def _build_send_data(data_bytes, header_extra=None):
    # 生成报头信息
    headers = {
        'data_len': len(data_bytes),
    }

    # 报头附加信息
    if header_extra is not None:
        headers.update(header_extra)

    # 序列化报头信息并转为字节
    # serialized_headers_bytes = json.dumps(headers).encode()
    serialized_headers_bytes = json.dumps(headers).encode()

    # 计算报头长度
    header_len = len(serialized_headers_bytes)

    # 计算报头长度并使用struct模块转换为固定长度的无符号整型(4字节)
    header_len_bytes = struct.pack('I', header_len)

    return header_len_bytes + serialized_headers_bytes + data_bytes


# 记录错误日志
def _log(e):
    if isinstance(e, HintException):
        return

    # 日志目录
    log_dir = '/www/server/bt-monitor/logs/sqlite_server/{}'.format(time.strftime('%Y%m'))

    # 确保目录已创建
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, 0o600)

    # 记录错误日志
    with open('{}/{}.log'.format(log_dir, time.strftime('%d')), 'a') as fp:
        fp.write('[{}]{}\n'.format(time.strftime('%Y-%m-%d %X'), str(e)))

        # 如果是异常，打印异常堆栈信息
        if isinstance(e, BaseException):
            fp.write('{}\n'.format(traceback.format_exc()))


def _to_tuple(p):
    '''
        @name 将输入参数转为元组
        @author Zhj<2022-07-16>
        @param  p<mixed> 输入参数
        @return tuple
    '''
    # 输入参数为元组时 直接返回
    if isinstance(p, tuple):
        return p

    # 输入参数为列表时 转为元组
    if isinstance(p, list):
        return tuple(p)

    # 其他情况 直接创建一个元组 并将参数放入其中
    return (p,)


# 正则表达式列表
# 匹配SQL字段名称的正则表达式
match_field_reg = re.compile(r'^(?:`?(\w+)`?\.)?`?(\w+)`?$', flags=re.IGNORECASE)

# 匹配表名的正则表达式
match_table_name_reg = re.compile(r'^([\w`]+)(?:(?:\s+AS\s+|\s+)([\w`]+))?$', flags=re.IGNORECASE)

# 匹配【?】号的正则表达式
search_question_reg = re.compile(r'\?')

# 匹配查询字段名称的正则表达式
match_row_key_reg = re.compile(r'^(?:[\w`]+\.)?([\w`]+)(?:(?:\s+AS\s+|\s+)([\w`]+))?$', flags=re.IGNORECASE)

# 匹配查询字段别名的正则表达式
search_row_key_reg = re.compile(r'(?:\s+AS\s+|\s+)([\w`]+)$', flags=re.IGNORECASE)

# 匹配SQL逻辑操作符【AND】【OR】的正则表达式
search_logic_opt_reg = re.compile(r'\s+(?:AND|OR)\s+', flags=re.IGNORECASE)

# 匹配以【1 AND 】开头的WHERE语句的正则表达式
match_where_str_begin_reg = re.compile(r'^1\s+(?:AND|OR)\s+', flags=re.IGNORECASE)

# 匹配引号【'】【"】的正则表达式
search_quote_reg = re.compile(r'(?<!\\)([\'"])')


def _add_backtick_for_field(field):
    '''
        @name 给字段名添加反引号
        @author Zhj<2022-07-16>
        @param  field<string> 字段名
        @return string
    '''
    return match_field_reg.sub(lambda m: '{}{}'.format(
        '' if m.group(1) is None else '`%s`.' % m.group(1),
        '`%s`' % m.group(2)
    ), str(field).strip())


def _dict_factory(cursor, row):
    '''
        @name   将元组数据行转换为字典
        @author Zhj<2022-07-16>
        @param  cursor<sqlite3.Cursor>  游标对象
        @param  row<tuple>              数据行元组
        @return dict
    '''
    d = {}

    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]

    return d


def _format_cursor(cursor):
    '''
        @name 将cursor对象转换为list对象
        @author Zhj<2023-04-25>
        @param  cursor<sqlite.Cursor> 游标对象
        @return list
    '''
    gc_disable()
    cols = tuple(map(lambda x: x[0], cursor.description))
    data = []
    for row in cursor:
        d = {}
        i = 0
        for col in cols:
            d[col] = row[i]
            i += 1
        data.append(d)
        # yield d
    cursor.close()
    gc_enable()
    return data


@contextmanager
def _auto_repair_context(db_path):
    '''
        @name 自动修复sqlite数据库的上下文环境
        @author Zhj<2023-03-15>
        @param  db_path<string> sqlite数据库绝对路径
        @return void
    '''

    # os.chdir('/www/server/bt-monitor')
    # sys.path.insert(0, "/www/server/bt-monitor")
    #
    # import core.include.public as public
    # path = os.getcwd()
    # monitor_backpath = path + '/backupDB/monitor_mgr_bak.db'
    # safety_backpath = path + '/backupDB/safety_bak.db'
    try:
        yield
    except BaseException as e:
        if str(db_path).startswith(':memory:'):
            raise e

        if str(e) in ['database disk image is malformed', 'file is not a database']:
            # TODO 修复数据库
            # public.ExecShell('\cp -rf %s %s' % (monitor_backpath,db_path))
            # public.ExecShell('\cp -rf %s %s' % (safety_backpath,db_path))
            pass

        raise e


# 日志打印(/www/server/bt-monitor/logs/sqlite_client.log)
def _log2(s, log_file='sqlite_client.log'):
    log_dir = '/www/server/bt-monitor/logs'

    # 确保目录已创建
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, 0o600)

    with open('{}/{}'.format(log_dir, log_file), 'a') as fp:
        fp.write('[{}]{}\n'.format(time.strftime('%Y-%m-%d %X'), s))

# _LAST_LOG_MALLOC = 0
# def log_malloc():
#     global _LAST_LOG_MALLOC
#
#     cur_time = int(time.time())
#     if _LAST_LOG_MALLOC == 0 or _LAST_LOG_MALLOC < cur_time - 60:
#         snapshot = tracemalloc.take_snapshot()
#         top_stats = snapshot.statistics('lineno')
#
#         s = 'TOP 50 difference (traced_memory: {} tracemalloc_memory: {})\n'.format(tracemalloc.get_traced_memory(), tracemalloc.get_tracemalloc_memory())
#         for stat in top_stats[:50]:
#             s += '{}\n'.format(stat)
#
#         _log2(s, 'malloc.log')
#
#         _LAST_LOG_MALLOC = cur_time
#
#
# def objgraph_log():
#     with open('/www/server/bt-monitor/logs/objgraph.log', 'a') as fp:
#         fp.write('[{}]\n'.format(time.strftime('%Y-%m-%d %X')))
#         fp.write('-------------------- SHOW GROWTH --------------------\n')
#         objgraph.show_growth(limit=50, file=fp)
#         fp.write('\n\n')
#
#         fp.write('-------------------- SHOW MOST COMMON TYPES --------------------\n')
#         objgraph.show_most_common_types(limit=50, file=fp)
#         fp.write('\n\n')


# 常量列表
_TYPE_CONNECT = 'connect'  # 连接数据库
_TYPE_CLOSE = 'close'  # 关闭数据库连接
_TYPE_QUERY = 'query'  # 查询
_TYPE_EXECUTE = 'execute'  # 执行sql语句
_TYPE_EXECUTE_MANY = 'execute_many'  # 批量插入
_TYPE_EXECUTE_SCRIPT = 'execute_script'  # 批量执行sql语句
_TYPE_START_TRANSACTION = 'start_transaction'  # 开启事务
_TYPE_COMMIT_TRANSACTION = 'commit_transaction'  # 提交事务
_TYPE_ROLLBACK_TRANSACTION = 'rollback_transaction'  # 回滚事务
_TYPE_VACUUM = 'vacuum'  # 整理数据库空间
_TYPE_BACKUP = 'backup'  # 备份数据库

# Unix Socket 连接文件
_SOCK_FILE = '{}/logs/sqlite_server.sock'.format(_BASE_DIR)
_READ_SOCKET_FILE = _SOCK_FILE
_WRITE_SOCKET_FILE = '{}/logs/sqlite_server_w.sock'.format(_BASE_DIR)


class MainExecuteTask:
    '''
        @name 主队列任务
        @author Zhj<2023-03-30>
    '''
    __slots__ = ['queue', 'lock', 'db_name']

    def __init__(self, q, lck, db_name):
        self.queue = q
        self.lock = lck
        self.db_name = db_name


class ExecuteTask:
    '''
        @name 执行队列任务
        @author Zhj<2023-03-30>
    '''
    __slots__ = [
        'sock_file', 'conn', 'func_name', 'args',
        'data_type', 'client_socket',
    ]

    def __init__(self, sock_file, conn, func_name, args, data_type, client_socket):
        self.sock_file = sock_file
        self.conn = conn
        self.func_name = func_name
        self.args = args
        self.data_type = data_type
        self.client_socket = client_socket


class MyThreadTask:
    '''
        @name 线程执行任务类
        @author Zhj<2023-04-15>
    '''
    __slots__ = ['fn', 'args', 'kwargs']

    def __init__(self, fn, *args, **kwargs):
        self.fn = fn
        self.args = args
        self.kwargs = kwargs

    def run(self):
        return self.fn(*self.args, **self.kwargs)


class MyCoroutine:
    __slots__ = ['__gen', '__is_stop', '__lock']

    def __init__(self, gen):
        self.__gen = gen
        self.__is_stop = False
        self.__lock = threading.Lock()

    def schedule(self, main_queue=None):
        if not self.__lock.acquire(False):
            return

        exec_status = 0

        try:
            exec_status = next(self.__gen)
        except StopIteration:
            self.__is_stop = True
        finally:
            self.__lock.release()

        if main_queue is not None and not self.__is_stop:
            # 当需要等待新任务时，等待1ms
            if exec_status == 1:
                time.sleep(0.001)
            main_queue.put_nowait(self)

    def is_stop(self):
        return self.__is_stop


class SqliteServer:
    '''
        sqlite服务类
        @author Zhj<2022-12-06>
    '''

    __slots__ = ['__weakref__', '__IS_RUNNING', '__SERVER_SOCKET', '__CONNECTIONS', '__UPDATE_CONNECTIONS_LOCK',
                 '__EXECUTE_QUEUES', '__UPDATE_EXECUTE_QUEUES_LOCK', '__HANDLERS', '__CLOSE_CONNECTIONS',
                 '__UPDATE_CLOSE_CONNECTIONS_LOCK', '__READ_QUEUE', '__WRITE_QUEUE', '__MAIN_QUEUE',
                 '__LAST_GC_TIME', '__GC_INTERVAL', '__THREAD_EXT', '__GEN_CONN_ID_RLOCK', '__READ_SERVER_SOCKET',
                 '__WRITE_SERVER_SOCKET']

    # 构造函数
    def __init__(self):
        self.__READ_SERVER_SOCKET = None
        self.__WRITE_SERVER_SOCKET = None
        # self.__CONNECT_QUEUE = queue.Queue()  # 连接数据库任务队列
        self.__LAST_GC_TIME = int(time.time())  # 上一次gc时间
        self.__GC_INTERVAL = 900  # gc间隔/秒
        self.__THREAD_EXT = []  # 额外线程
        self.__IS_RUNNING = False  # 服务运行中
        self.__SERVER_SOCKET = None  # socket对象
        self.__CONNECTIONS = {}  # sqlite连接池
        self.__UPDATE_CONNECTIONS_LOCK = threading.Lock()  # sqlite连接池更新锁
        self.__EXECUTE_QUEUES = {}  # 执行队列(写入操作){ 数据库名称(全路径 不包含.db): queue.Queue, ... }
        self.__UPDATE_EXECUTE_QUEUES_LOCK = threading.Lock()  # 执行队列表更新锁
        self.__HANDLERS = {}  # 处理函数注册表
        # self.__DB_CONNECTION = {}  # 数据库名称与连接ID映射表
        # self.__UPDATE_DB_CONNECTION_LOCK = threading.Lock()  # 数据库名称与连接ID映射表更新锁
        # self.__CONNECTION_REFERENCE_COUNT = {}  # 连接ID引用次数
        # self.__UPDATE_CONNECTION_REFERENCE_COUNT_LOCK = threading.Lock()  # 连接ID引用次数更新锁

        # self.__CONNECTED_SOCKETS = 0            # 当前已建立的客户端socket数量
        # self.__UPDATE_CONNECTED_SOCKETS_LOCK = threading.Lock() # 当前已建立连接的客户端数量更新锁
        # self.__CLOSE_CONNECTIONS = {}  # 待关闭的数据库连接
        # self.__UPDATE_CLOSE_CONNECTIONS_LOCK = threading.Lock()  # 待关闭的数据库连接更新锁

        # self.__RESCHEDULE_QUEUE = queue.Queue()  # 等待重新调度的队列

        # self.__REMOVE_EXECUTE_QUEUES = set()  # 待删除的执行队列集合
        # self.__UPDATE_REMOVE_EXECUTE_QUEUES = threading.Lock()  # 待删除的执行队列集合更新锁

        # self.__HANDING_QUEUES = 0  # 当前处理中的执行任务数
        # self.__HANDING_QUEUE_TASKS = {}  # 当前处理中的执行任务列表
        # self.__UPDATE_HANDING_QUEUES = threading.Lock()  # 当前处理中的执行任务数更新锁
        # self.__UPDATE_HANDING_QUEUE_TASKS = threading.Lock()  # 当前处理中的执行任务列表更新锁

        self.__GEN_CONN_ID_RLOCK = threading.RLock()

        self.__READ_QUEUE = queue.Queue()
        self.__WRITE_QUEUE = queue.Queue()

        # self.__READ_THREAD_POOL = None  # 读操作线程池
        # self.__WRITE_THREAD_POOL = None  # 写操作线程池
        # self.__PROCESS_POOL = None  # 进程池

        # 注册处理函数
        self.__register_handlers()

    # 注册不同类型的处理函数
    def __register_handlers(self):
        self.__HANDLERS = {
            _TYPE_CONNECT: self.__connect_handler,
            _TYPE_CLOSE: self.__close_handler,
            _TYPE_QUERY: self.__query_handler,
            _TYPE_EXECUTE: self.__execute_handler,
            _TYPE_EXECUTE_MANY: self.__execute_many_handler,
            _TYPE_EXECUTE_SCRIPT: self.__execute_script_handler,
            _TYPE_START_TRANSACTION: self.__start_transaction_handler,
            _TYPE_COMMIT_TRANSACTION: self.__commit_transaction_handler,
            _TYPE_ROLLBACK_TRANSACTION: self.__rollback_transaction_handler,
            _TYPE_VACUUM: self.__vacuum_handler,
            _TYPE_BACKUP: self.__backup_handler,
        }

    # 析构函数
    # def __del__(self):
    #     print('sqlite_server is stop...\n', end='')
    #     try:
    #         self.__IS_RUNNING = False
    #         if self.__SERVER_SOCKET is not None:
    #             self.__SERVER_SOCKET.close()
    #     except:
    #         pass

    def __send_data(self, sock_file, data, client_socket=None):
        '''
            @name 发送数据
            @author Zhj<2022-12-11>
            @param sock_file<string>                回包地址
            @param data<dict>                       数据包
            @return void
        '''
        # s_time = time.time()

        try:
            if client_socket is None:
                # print('connecting to {}...\n'.format(sock_file), end='')
                client_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                client_socket.connect(sock_file)
                # _log2('connected {}\n'.format(sock_file))

                # print('connected {}\n'.format(sock_file), end='')
                # print('sending data to {}...\n'.format(sock_file), end='')
                send_data(ClientSocket(client_socket), data)

                # print('data sent {}\n'.format(sock_file), end='')
                # print('closing connection {}...\n'.format(sock_file), end='')
                client_socket.close()
                # print('closed {}\n'.format(sock_file), end='')

                return

            data['sock_file'] = sock_file
            send_data(client_socket, data)
        except BaseException as e:
            # 记录sock文件与发送数据
            _log('{} {}'.format(sock_file, data))

            # 记录异常堆栈信息
            _log(e)

            e = None
            del (e,)

            # 抛出异常
            # raise
        # finally:
        #     print('{}ms sent data {} {}\n'.format(int((time.time() - s_time) * 1000), data['type'], sock_file), end='')

    # 启动服务
    def run(self):
        if self.__IS_RUNNING:
            raise RuntimeError('sqlite server is running.')

        try:
            # 获取系统当前设置的socket缓冲区最大值
            with os.popen('sysctl -a |grep "net\.core\.[rw]mem_max"') as p:
                sys_rw_mem_max_list = map(lambda x: tuple(map(lambda y: y.strip(), x.split('='))), p.read().split('\n')[:-1])

            # 修改系统socket缓冲区最大值
            for sys_rw_mem_max in sys_rw_mem_max_list:
                if int(sys_rw_mem_max[1]) < 524288:
                    os.system('sysctl -w {}=524288 > /dev/null'.format(sys_rw_mem_max[0]))
        except: pass

        # sock文件存在时将其删除
        if os.path.exists(_READ_SOCKET_FILE):
            os.remove(_READ_SOCKET_FILE)

        if os.path.exists(_WRITE_SOCKET_FILE):
            os.remove(_WRITE_SOCKET_FILE)

        # 创建读socket对象并指定协议
        self.__READ_SERVER_SOCKET = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.__READ_SERVER_SOCKET.bind(_READ_SOCKET_FILE)
        self.__READ_SERVER_SOCKET.listen(500)

        # 创建写socket对象并指定协议
        self.__WRITE_SERVER_SOCKET = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.__WRITE_SERVER_SOCKET.bind(_WRITE_SOCKET_FILE)
        self.__WRITE_SERVER_SOCKET.listen(500)

        # 设置服务运行状态
        self.__IS_RUNNING = True

        print('sqlite_server is running...\n', end='')

        [threading.Thread(target=self.__thread_handler, args=(self.__READ_QUEUE,), daemon=True).start() for _ in range(1)]
        [threading.Thread(target=self.__thread_handler, args=(self.__WRITE_QUEUE,), daemon=True).start() for _ in range(1)]

        # 启动接受读连接的线程
        threading.Thread(target=self.__accept_handler, args=(self.__READ_SERVER_SOCKET,), daemon=True).start()
        # 启动接受写连接的线程
        threading.Thread(target=self.__accept_handler, args=(self.__WRITE_SERVER_SOCKET,), daemon=True).start()

        while self.__IS_RUNNING:
            time.sleep(1)

    # 接受连接请求
    def __accept_handler(self, server_socket):
        while self.__IS_RUNNING:
            # 接受连接请求
            client_socket, addr = server_socket.accept()

            # 设置缓冲区大小
            client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 5242880)
            client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 5242880)

            # 在子线程中处理请求
            threading.Thread(target=self.handler, args=(ClientSocket(client_socket),), daemon=True).start()

            client_socket = None
            addr = None
            del (client_socket, addr,)

    # 处理客户端socket
    def handler(self, client_socket):
        _log2('handing client_socket {}'.format(id(client_socket)))

        # last_time = int(time.time())

        # data = None

        # 不断处理客户端信息，直到客户端主动关闭
        while self.__handle_client_socket(client_socket):
            pass

        # 关闭客户端连接
        try:
            # # 更新当前已连接的socket数量
            # with self.__UPDATE_CONNECTED_SOCKETS_LOCK:
            #     self.__CONNECTED_SOCKETS -= 1

            # 关闭数据库连接
            self.__remove_connection_when_client_socket_close(client_socket)

            # 关闭客户端连接
            client_socket.close()

            _log2('closed client_socket {}'.format(id(client_socket)))
        except:
            pass

        # 手动回收内存
        data = None
        client_socket = None
        del (client_socket, data)

        # 显式调用gc回收内存
        # gc.collect()

    # 接收消息并处理
    def __handle_client_socket(self, client_socket):
        data = None
        try:
            # print('recving data from client_socket-{} ......\n'.format(id(client_socket)), end='')

            # s_time = time.time()

            # 解析并获取数据
            data = recv_data(client_socket)

            # print('recv data from client_socket-{} {}\n'.format(id(client_socket), data), end='')

            # cur_time = int(time.time())
            #
            # if cur_time > last_time + 5:
            #     print('[{}]recv data from client_socket-{} {}\n'.format(time.strftime('%Y-%m-%d %X'), id(client_socket), data), end='')
            #     last_time = cur_time
            #
            # cur_time = None
            # del (cur_time,)

            # s_time = time.time()
            # print('recv data {}: {}\n'.format(id(client_socket), data), end='')

            # 检测到客户端暴力断开连接，结束循环
            if data is None:
                return False

            # 根据type值，确定操作
            stype = data.get('type', None)

            if stype is None:
                raise HintException('type is required.')

            # 转为小写
            stype = str(stype).lower()

            # 处理不同类型请求
            if stype not in self.__HANDLERS:
                raise HintException('cannot handle unknown type request.')

            # print('{}ms {} recv data {} {}\n'.format(int((time.time() - s_time) * 1000), id(client_socket), data['type'], data.get('sock_file', None)), end='')

            # 处理请求
            # 提交到线程池中处理
            if stype in [_TYPE_CONNECT, _TYPE_QUERY]:
                # self.__READ_THREAD_POOL.submit(self.__HANDLERS[stype], data, client_socket)
                # self.__READ_QUEUE.put(MyThreadTask(self.__HANDLERS[stype], data, client_socket))
                self.__add_read_task(MyThreadTask(self.__HANDLERS[stype], data, client_socket))
            else:
                # self.__WRITE_THREAD_POOL.submit(self.__HANDLERS[stype], data, client_socket)
                self.__WRITE_QUEUE.put_nowait(MyThreadTask(self.__HANDLERS[stype], data, client_socket))

            # 提交到进程池中处理
            # self.__PROCESS_POOL.submit(self.__HANDLERS[stype], data, client_socket)
            # self.__HANDLERS[stype](data, client_socket)

            # print('{}ms handled data {}: {}\n'.format(int((time.time() - s_time) * 1000), id(client_socket), data), end='')

            # 关闭数据库连接的同时关闭客户端连接
            # if type == _TYPE_CLOSE:
            #     break

            stype = None
            del (stype,)
        except BaseException as e:
            # 捕获到异常
            # 写错误日志
            _log(e)

            # 发送异常信息给客户端
            try:
                if data and 'sock_file' in data:
                    self.__send_data(data['sock_file'], {
                        'success': False,
                        'res': str(e),
                    }, client_socket)
            except:
                pass

            e = None
            del (e,)

            # if isinstance(e, ConnectionResetError):
            #     _log(self.__CONNECTED_SOCKETS)

            # if isinstance(e, TypeError):
            #     _log(data)

            # 非提示性异常时，断开客户端连接
            # if not isinstance(e, HintException):
            #     break

        # 每隔一段时间手动执行GC
        cur_time = int(time.time())
        if cur_time > self.__LAST_GC_TIME + self.__GC_INTERVAL:
            self.__LAST_GC_TIME = cur_time
            del (gc.garbage[:],)
            gc.collect()

        return True

    # 创建新的读任务
    def __add_read_task(self, my_thread_task):
        # 当队列存在堆积任务时，创建新的线程处理任务
        if len(self.__THREAD_EXT) < 1000 and self.__READ_QUEUE.qsize() > 10:
            # threading.Thread(target=getattr(my_thread_task, 'run'), daemon=True).start()
            # self.__THREAD_EXT.append(None)
            threading.Thread(target=self.__handle_read_task_with_thread, args=(my_thread_task,), daemon=True).start()
            return

        self.__READ_QUEUE.put_nowait(my_thread_task)

    # 在线程中处理读任务
    def __handle_read_task_with_thread(self, my_thread_task):
        try:
            self.__THREAD_EXT.append(None)
            my_thread_task.run()
        except BaseException as e:
            _log(e)
            e = None
            del (e,)
        finally:
            try:
                self.__THREAD_EXT.pop()
            except IndexError: pass

    # 生成全局唯一的数据库连接ID
    def gen_connection_id(self):
        conn_id = (int(time.time() * 1000 - 1681349558135) << 22) | (uuid.uuid4().int & ((1 << 22) - 1))

        with self.__GEN_CONN_ID_RLOCK:
            while conn_id in self.__CONNECTIONS:
                conn_id = (int(time.time() * 1000 - 1681349558135) << 22) | (uuid.uuid4().int & ((1 << 22) - 1))

        return conn_id

    # # 打印内存信息
    # def __show_objgraph(self):
    #     while self.__IS_RUNNING:
    #         objgraph_log()
    #         log_malloc()
    #         time.sleep(420)

    # 通过connection_id获取sqlite服务端连接
    def __get_sqlite_server_connection_by_id(self, connection_id=None):
        if connection_id is None:
            raise HintException('connection_id is required.')

        # 检查连接是否存在
        if connection_id not in self.__CONNECTIONS:
            raise HintException('connection {} is not exists.'.format(connection_id))

        return self.__CONNECTIONS[connection_id]

    # 当客户端socket关闭时，关闭数据库连接
    def __remove_connection_when_client_socket_close(self, client_socket):
        for conn_id in client_socket.get_conn_id_set():
            try:
                conn = self.__get_sqlite_server_connection_by_id(conn_id)
                # self.__WRITE_THREAD_POOL.submit(self.__add_task, None, conn, 'commit', data_type=_TYPE_COMMIT_TRANSACTION, client_socket=client_socket)
                self.__WRITE_QUEUE.put_nowait(MyThreadTask(self.__add_task, None, conn, 'commit', data_type=_TYPE_COMMIT_TRANSACTION, client_socket=client_socket))
                # self.__WRITE_THREAD_POOL.submit(self.__add_task, None, conn, 'close', data_type=_TYPE_CLOSE, client_socket=client_socket)
                self.__WRITE_QUEUE.put_nowait(MyThreadTask(self.__add_task, None, conn, 'close', data_type=_TYPE_CLOSE, client_socket=client_socket))
                # self.__add_task(None, conn, 'commit', data_type=_TYPE_COMMIT_TRANSACTION, client_socket=client_socket)
                # self.__add_task(None, conn, 'close', data_type=_TYPE_CLOSE, client_socket=client_socket)
            except: pass

    # 线程处理
    def __thread_handler(self, q):
        while self.__IS_RUNNING:
            try:
                q.get().run()
            except BaseException as e:
                _log(e)

                e = None
                del (e,)
            finally:
                q.task_done()

    # 添加SQL执行任务到队列中
    def __add_task(self, sock_file, conn, func_name, args=(), data_type=_TYPE_EXECUTE, client_socket=None):
        '''
            @name 添加SQL执行任务到队列中
            @author Zhj<2022-12-16>
            @param sock_file<string|None>           回包地址
            @param conn<SqliteServerConnection>     数据库连接对象
            @param func_name<string>                方法名称
            @param args<tuple>                      参数
            @param data_type<string>                数据包类型
            @return void
        '''
        conn.enqueue(ExecuteTask(sock_file, conn, func_name, args, data_type, client_socket))

        # if conn.db_name() != '/dev/shm/monitor_tmp':
        #     _log2('>>>> add task: {} {} {} {}'.format(conn.id(), conn.db_name(), func_name, args), 'xyz.log')

        # 将写入任务放入执行队列
        with acquire(self.__UPDATE_EXECUTE_QUEUES_LOCK, timeout=1):
            thread_running = True

            # 不存在队列时创建一个
            if conn.db_name() not in self.__EXECUTE_QUEUES:
                thread_running = False

                # 初始化队列
                # 为每个队列分配一把锁
                # self.__EXECUTE_QUEUES[conn.db_name()] = (queue.Queue(), threading.Lock())
                self.__EXECUTE_QUEUES[conn.db_name()] = (queue.Queue(), set())

                # 启动协程
                # self.__MAIN_QUEUE.put(MyCoroutine(self.__queue_handler_2(conn.db_name())))

            # # 将执行队列从待删除列表中移除
            # with acquire(self.__UPDATE_REMOVE_EXECUTE_QUEUES, timeout=3):
            #     self.__REMOVE_EXECUTE_QUEUES.discard(conn.db_name())

            # 首先将任务添加进连接对象的执行队列中
            # conn.enqueue((sock_file, conn, func_name, args, data_type, client_socket))


            # 将连接对象添加进数据库执行队列
            # q, lck = self.__EXECUTE_QUEUES[conn.db_name()]
            q, conn_id_set = self.__EXECUTE_QUEUES[conn.db_name()]

            # q.put(conn)
            # 使用set()确保队列中conn不重复出现
            if conn.id() not in conn_id_set:
                conn_id_set.add(conn.id())

            q.put_nowait(conn)

            if not thread_running:
                # 启动处理线程
                threading.Thread(target=self.__queue_handler_2, args=(conn.db_name(),), daemon=True).start()

            # 将执行队列添加进主队列
            # self.__MAIN_QUEUE.put((q, lck, conn.db_name()))
            # self.__MAIN_QUEUE.put(MainExecuteTask(q, lck, conn.db_name()))

        # if conn.db_name() == '/dev/shm/monitor_tmp':
        #     _log2('{} {}'.format(conn.id(), func_name), 'sqlite_task.log')

        # print('add task {} {}\n'.format(conn.db_name(), func_name), end='')

    # 已协程的方式处理任务(已弃用)
    def __queue_handler_3(self):
        while self.__IS_RUNNING:
            self.__MAIN_QUEUE.get().schedule(self.__MAIN_QUEUE)
            self.__MAIN_QUEUE.task_done()

    # 数据库写入任务队列处理线程
    def __queue_handler_2(self, db_name):
        # last_time = int(time.time())
        # cur_status = None  # 任务执行状态 0-执行成功 1-等待新任务
        # (queue, set<存储当前队列内的conn_id>)
        while self.__IS_RUNNING:
            q, conn_id_set = self.__EXECUTE_QUEUES.get(db_name, (None, set()))

            # 获取不到执行队列时，中断线程
            if q is None:
                q = None
                conn_id_set = None
                del (q, conn_id_set)
                return

            # cur_status = 0
            # cur_time = int(time.time())

            try:
                # 阻塞获取下一次写入任务，每隔20ms尝试获取一次
                conn = q.get(timeout=0.02)

                # conn.schedule(MyThreadTask(self.__execute_conn_tasks, conn))
                self.__execute_conn_tasks(conn)

                # # 当连接存在未处理的任务时，重新放回执行队列中
                # if conn.has_unfinished_task():
                #     # 当连接未处理任务超过1000个时，打印日志
                #     if conn.unfinished_task_num() > 999:
                #         _log2('{}<{}>: {}\nconn_id_set: {}'.format(db_name, conn.id(), conn.unfinished_task_num(), list(conn_id_set)))
                #
                #     q.put_nowait(conn)

                # 连接关闭时，将其从集合中移除
                if conn.is_closed():
                    with acquire(self.__UPDATE_EXECUTE_QUEUES_LOCK, timeout=1):
                        conn_id_set.discard(conn.id())

                q.task_done()

                # last_time = cur_time
            except queue.Empty:
                # if cur_time > last_time + 60:
                # 当执行队列空闲时间超过1分钟时，中断线程
                with acquire(self.__UPDATE_EXECUTE_QUEUES_LOCK, timeout=1):
                    if len(conn_id_set) == 0:
                        self.__EXECUTE_QUEUES.pop(db_name, None)
                        return
                # time.sleep(0.001)
                # continue
            finally:
                q = None
                conn_id_set = None
                conn = None
                del (q, conn_id_set, conn)

            # yield cur_status

    # 执行数据库连接的写入任务
    def __execute_conn_tasks(self, conn):
        in_transaction = False

        # 处理连接的执行队列
        if conn.has_unfinished_task():
            while True:
                try:
                    # 获取队列元素与事务状态
                    task, _in_transaction = conn.dequeue(in_transaction, 15)

                    if _in_transaction is not None:
                        in_transaction = _in_transaction

                    _in_transaction = None
                    del (_in_transaction,)

                    try:
                        # if task.conn.db_name() != '/dev/shm/monitor_tmp':
                        #     _log2('>>>> exec task: {} {} {} {} >>> start'.format(task.conn.id(), task.conn.db_name(), task.func_name, task.args), 'xyz.log')

                        # 执行任务
                        ret = getattr(task.conn, task.func_name)(*task.args)

                        # if task.conn.db_name() != '/dev/shm/monitor_tmp':
                        #     _log2('>>>> exec task: {} {} {} {} >>> end'.format(task.conn.id(), task.conn.db_name(),
                        #                                                   task.func_name, ret), 'xyz.log')

                        # 将执行结果发送给客户端
                        if task.sock_file:
                            self.__send_data(task.sock_file, {
                                'type': task.data_type,
                                'success': True,
                                'res': ret,
                            }, task.client_socket)

                        # 关闭数据库时，尝试将连接ID从client_socket中移除
                        if task.data_type == _TYPE_CLOSE:
                            task.client_socket.remove_conn_id(task.conn.id())

                        ret = None
                        del (ret,)
                    except BaseException as e:
                        # 捕获到异常
                        # 写错误日志
                        _log(e)

                        # 发送异常信息给客户端
                        try:
                            if task.sock_file:
                                self.__send_data(task.sock_file, {
                                    'type': task.data_type,
                                    'success': False,
                                    'res': str(e),
                                }, task.client_socket)
                        except: pass

                        e = None
                        del (e,)
                    finally:
                        # 回收变量，确保gc能正常工作
                        ret = None
                        task = None
                        del (ret, task)

                    # 标记队列任务已完成
                    conn.queue_task_done()

                    # 当结束事务时，处理其它连接的执行队列
                    if not in_transaction:
                        break
                except BaseException as e:
                    # 打印异常堆栈信息
                    if not isinstance(e, queue.Empty):
                        _log(e)

                    e = None
                    del (e,)

                    # 当连接处于事务中，且执行队列为空时，尝试提交事务
                    if in_transaction and not conn.is_closed():
                        # self.__add_task(None, conn, 'commit', data_type=_TYPE_COMMIT_TRANSACTION)
                        conn.commit()

                    break

        in_transaction = None
        del (in_transaction,)

    # 垃圾回收线程
    def __gc_handler(self):
        while self.__IS_RUNNING:
            # 休眠15分钟
            time.sleep(900)

            # # 获取当前时间
            # cur_time = int(time.time())
            #
            # # 待删除连接ID
            # remove_list = []
            #
            # # 上锁
            # with acquire(self.__UPDATE_CONNECTIONS_LOCK):
            #     for conn in self.__CONNECTIONS.values():
            #         if conn.is_lazy_connect() or conn.is_once():
            #             conn = None
            #             del (conn,)
            #             continue
            #         if conn.is_toolong_no_activate():
            #             remove_list.append(conn.id())
            #         conn = None
            #         del (conn,)
            #
            # if len(remove_list) > 0:
            #     # 将数据库连接ID添加进待关闭列表中，设置15秒后关闭，期间如果没有被重新连接则真正关闭数据库连接
            #     with acquire(self.__UPDATE_CLOSE_CONNECTIONS_LOCK):
            #         for conn_id in remove_list:
            #             self.__CLOSE_CONNECTIONS[conn_id] = cur_time + 15
            #             conn_id = None
            #             del (conn_id,)
            #
            # # 删除无用的执行队列
            # # remove_list = []
            #
            # # # 上锁
            # # with acquire(self.__UPDATE_REMOVE_EXECUTE_QUEUES):
            # #     for db_name in self.__REMOVE_EXECUTE_QUEUES:
            # #         remove_list.append(db_name)
            # #         self.__EXECUTE_QUEUE_WAIT.pop(db_name, None)
            # #         db_name = None
            # #         del (db_name,)
            # #
            # #     # 清空集合
            # #     self.__REMOVE_EXECUTE_QUEUES.clear()
            # #
            # # if len(remove_list) > 0:
            # #     with acquire(self.__UPDATE_EXECUTE_QUEUES_LOCK):
            # #         for db_name in remove_list:
            # #             if db_name in self.__EXECUTE_QUEUES:
            # #                 self.__EXECUTE_QUEUES.pop(db_name)
            # #             db_name = None
            # #             del (db_name,)
            #
            # # 主动回收内存
            # remove_list = None
            # del (remove_list,)
            #
            # # 清理无用的客户端回包sock文件
            # # for filename in glob.glob('{}/logs/sqlite_server_*.sock'.format(_BASE_DIR)):
            # #     # 删除创建超过15分钟sock文件
            # #     if int(filename[-15:-5]) < cur_time - 900:
            # #         os.remove(filename)
            # #     del (filename,)
            #
            # cur_time = None
            # del (cur_time,)

            # 显式调用gc回收内存
            del (gc.garbage[:],)
            gc.collect()

    # 关闭数据库连接线程
    def __close_db_handler(self):
        while self.__IS_RUNNING:
            # 休眠7秒
            time.sleep(7)

            # 获取当前时间
            cur_time = int(time.time())

            # 将要关闭的连接ID
            close_list = []

            with acquire(self.__UPDATE_CLOSE_CONNECTIONS_LOCK):
                for (conn_id, close_time) in self.__CLOSE_CONNECTIONS.items():
                    if close_time > cur_time:
                        conn_id = None
                        close_time = None
                        del (conn_id, close_time)
                        continue

                    close_list.append(conn_id)

                    conn_id = None
                    close_time = None
                    del (conn_id, close_time)

                for conn_id in close_list:
                    self.__CLOSE_CONNECTIONS.pop(conn_id, None)
                    conn_id = None
                    del (conn_id,)

            # 执行关闭连接操作
            for conn_id in close_list:
                try:
                    # 获取连接对象
                    conn = self.__get_sqlite_server_connection_by_id(conn_id)
                except:
                    conn = None
                    conn_id = None
                    del (conn_id, conn)
                    continue

                # # 清除数据库名称与连接ID映射关系
                # if not conn.is_lazy_connect() and not conn.is_once():
                #     with acquire(self.__UPDATE_DB_CONNECTION_LOCK):
                #         self.__DB_CONNECTION.pop(conn.db_name(), None)

                # 将数据库关闭任务添加进队列中执行
                self.__add_task(None, conn, 'close', data_type=_TYPE_CLOSE)

                # 主动回收内存
                conn = None
                conn_id = None
                del(conn, conn_id)

            # 主动回收内存
            close_list = None
            cur_time = None
            del(close_list, cur_time)

    # # 连接数据库线程
    # def __connect_queue_handler(self):
    #     while self.__IS_RUNNING:
    #         data, client_socket = self.__CONNECT_QUEUE.get()
    #
    #         with self.__handler_context(data, client_socket):
    #             # 可复用的连接ID
    #             conn_id = None
    #
    #             # 获取可复用连接ID
    #             if data['db_name'] in self.__DB_CONNECTION:
    #                 conn_id = self.__DB_CONNECTION[data['db_name']]
    #
    #             # 存在可复用ID时，检查是否可用
    #             if conn_id is not None:
    #                 # 检查连接是否已经确定即将被关闭
    #                 if conn_id in self.__CLOSE_CONNECTIONS and self.__CLOSE_CONNECTIONS[conn_id] < int(time.time()):
    #                     # 不复用已经确定要关闭的连接
    #                     conn_id = None
    #
    #             # 存在可复用连接ID且可用时，发送回客户端
    #             if conn_id is not None:
    #                 # 发送数据库连接ID给客户端
    #                 if 'sock_file' in data:
    #                     self.__send_data(data['sock_file'], {
    #                         'type': _TYPE_CONNECT,
    #                         'success': True,
    #                         'res': conn_id,
    #                     }, client_socket)
    #
    #                 # 连接引用次数+1
    #                 with acquire(self.__UPDATE_CONNECTION_REFERENCE_COUNT_LOCK):
    #                     self.__CONNECTION_REFERENCE_COUNT[conn_id] += 1
    #
    #                 # 将连接ID从待关闭列表中移除
    #                 with acquire(self.__UPDATE_CLOSE_CONNECTIONS_LOCK):
    #                     if conn_id in self.__CLOSE_CONNECTIONS:
    #                         self.__CLOSE_CONNECTIONS.pop(conn_id)
    #             else:
    #                 # 创建连接
    #                 conn = SqliteServerConnection(data['db_name'], self)
    #
    #                 # 直接连接到内存时不可复用(若希望复用可使用 ":memory:<别名>" 的命名方式实现复用)
    #                 if conn.db_name() != ':memory:':
    #                     with acquire(self.__UPDATE_DB_CONNECTION_LOCK):
    #                         self.__DB_CONNECTION[conn.db_name()] = conn.id()
    #
    #                 # 发送数据库连接ID给客户端
    #                 if 'sock_file' in data:
    #                     self.__send_data(data['sock_file'], {
    #                         'type': _TYPE_CONNECT,
    #                         'success': True,
    #                         'res': conn.id(),
    #                     }, client_socket)
    #
    #             conn_id = None
    #             conn = None
    #             del (conn_id, conn)
    #
    #         data = None
    #         client_socket = None
    #         del (data, client_socket)
    #
    #         self.__CONNECT_QUEUE.task_done()

    # 将sqlite连接从连接池中移除
    def remove_connection(self, conn):
        # 上锁
        with acquire(self.__UPDATE_CONNECTIONS_LOCK, timeout=3):
            # 将连接从连接池中移除
            self.__CONNECTIONS.pop(conn.id(), None)
            # _log2('remove conn {}'.format(conn.id()), 'conn.log')

    # 将sqlite连接添加到连接池中
    def add_connection(self, conn):
        # 记录连接
        with acquire(self.__UPDATE_CONNECTIONS_LOCK, timeout=3):
            self.__CONNECTIONS[conn.id()] = conn
            # _log2('add conn {}'.format(conn.id()), 'conn.log')

        # 仅当已可复用方式连接时记录引用次数
        if not conn.is_lazy_connect() and not conn.is_once():
            # 初始化连接引用次数
            with acquire(self.__UPDATE_CONNECTION_REFERENCE_COUNT_LOCK, timeout=3):
                self.__CONNECTION_REFERENCE_COUNT[conn.id()] = 1

    # 连接数据库
    def __connect_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 验证参数
            if 'db_name' not in data:
                raise HintException('db_name is required.')

            if len(data['db_name']) == 0:
                raise HintException('db_name cannot be empty.')

            connect_brandnew = False

            # 检查本次是否要打开一个全新的数据库连接(默认复用可用连接)
            if 'brandnew' in data and data['brandnew']:
                connect_brandnew = True

            # 全新连接
            if connect_brandnew:
                # # 创建连接(延迟连接数据库)
                # conn = SqliteServerConnection(data['db_name'], weakref.proxy(self), connect_immediate=False)
                #
                # # 添加到执行队列中连接数据库
                # if 'sock_file' in data:
                #     self.__add_task(data['sock_file'], conn, 'connect', data_type=_TYPE_CONNECT,
                #                     client_socket=client_socket)

                # 创建连接(直接连接)
                conn = SqliteServerConnection(data['db_name'], self, once=True, connect_immediate=False)

                # 记录数据库连接ID，当客户端socket关闭时，自动释放连接
                client_socket.add_conn_id(conn.id())

                # 将任务放入执行队列中
                self.__add_task(data.get('sock_file', None), conn, 'connect', data_type=_TYPE_CONNECT, client_socket=client_socket)

                # # 发送数据库连接ID给客户端
                # if 'sock_file' in data:
                #     self.__send_data(data['sock_file'], {
                #         'type': _TYPE_CONNECT,
                #         'success': True,
                #         'res': conn.id(),
                #     }, client_socket)

                return

            raise HintException('only support brandnew connection.')

            # 添加到连接队列中
            # self.__CONNECT_QUEUE.put((data, client_socket))

    # 关闭数据库连接
    def __close_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 已延迟方式连接的直接关闭
            # 一次性连接直接关闭
            if conn.is_lazy_connect() or conn.is_once():
                # 将数据库关闭任务添加进队列中执行
                self.__add_task(None, conn, 'close', data_type=_TYPE_CLOSE, client_socket=client_socket)
                # 将数据库连接ID添加进待关闭列表中，设置3秒后关闭，期间如果没有被重新连接则真正关闭数据库连接
                # with acquire(self.__UPDATE_CLOSE_CONNECTIONS_LOCK, timeout=3):
                #     self.__CLOSE_CONNECTIONS[conn.id()] = int(time.time()) + 3
                return

            # # 连接引用次数-1
            # with acquire(self.__UPDATE_CONNECTION_REFERENCE_COUNT_LOCK):
            #     self.__CONNECTION_REFERENCE_COUNT[conn.id()] -= 1
            #
            #     # if self.__CONNECTION_REFERENCE_COUNT[conn.id()] < 1:
            #     #     self.__CONNECTION_REFERENCE_COUNT.pop(conn.id())
            #
            # # 当引用次数为0时，关闭连接
            # if self.__CONNECTION_REFERENCE_COUNT.get(conn.id(), 0) < 1:
            #     # 当客户端强制立即执行关闭连接操作时，直接添加到任务队列中
            #     if 'immediate' in data and data['immediate']:
            #         # 将数据库关闭任务添加进队列中执行
            #         self.__add_task(None, conn, 'close', data_type=_TYPE_CLOSE, client_socket=client_socket)
            #         # 将数据库连接ID添加进待关闭列表中，设置3秒后关闭，期间如果没有被重新连接则真正关闭数据库连接
            #         # with acquire(self.__UPDATE_CLOSE_CONNECTIONS_LOCK, timeout=3):
            #         #     self.__CLOSE_CONNECTIONS[conn.id()] = int(time.time()) + 3
            #         return
            #
            #     # 将数据库连接ID添加进待关闭列表中，设置15秒后关闭，期间如果没有被重新连接则真正关闭数据库连接
            #     with acquire(self.__UPDATE_CLOSE_CONNECTIONS_LOCK, timeout=3):
            #         self.__CLOSE_CONNECTIONS[conn.id()] = int(time.time()) + 15

    # 查询
    def __query_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 验证参数
            if 'sql' not in data:
                raise HintException('sql is required.')

            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # s_time = time.time()

            # print('{} query start...\n'.format(conn.db_name()), end='')
            # 执行SQL查询
            ret = conn.query(data['sql'], data.get('params', ()), data.get('take_first', False))

            # print('{}ms {} query end\n'.format(int((time.time() - s_time) * 1000), conn.db_name()), end='')

            # 将查询结果发送给客户端
            if 'sock_file' in data:
                self.__send_data(data['sock_file'], {
                    'type': _TYPE_QUERY,
                    'success': True,
                    'res': ret,
                }, client_socket)

            # self.__add_task(data.get('sock_file', None), conn, 'query',
            #                 args=(data['sql'], data.get('params', ()), data.get('take_first', False)),
            #                 data_type=_TYPE_QUERY,
            #                 client_socket=client_socket)

    # 执行SQL语句
    def __execute_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 验证参数
            if 'sql' not in data:
                raise HintException('sql is required.')

            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 将任务放入执行队列中
            self.__add_task(data.get('sock_file', None), conn, 'execute',
                                (data['sql'], data.get('params', ()), data.get('get_rowid', False)),
                                data_type=_TYPE_EXECUTE, client_socket=client_socket)

            # print('{} add execute task to queue\n'.format(conn.db_name()), end='')

    # 执行SQL批量写入
    def __execute_many_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 验证参数
            if 'sql' not in data:
                raise HintException('sql is required.')

            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 将任务放入执行队列中
            self.__add_task(data.get('sock_file', None), conn, 'execute_many', (data['sql'], data.get('params', ())),
                                data_type=_TYPE_EXECUTE_MANY, client_socket=client_socket)

            # print('{} add execute_many task to queue\n'.format(conn.db_name()), end='')

    # 批量执行SQL语句
    def __execute_script_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 验证参数
            if 'sql' not in data:
                raise HintException('sql is required.')

            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 将任务放入执行队列中
            self.__add_task(data.get('sock_file', None), conn, 'execute_script', (data['sql'],), data_type=_TYPE_EXECUTE_SCRIPT, client_socket=client_socket)

    # 开启事务
    def __start_transaction_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 将任务放入执行队列中
            self.__add_task(data.get('sock_file', None), conn, 'start_transaction', data_type=_TYPE_START_TRANSACTION, client_socket=client_socket)

    # 提交事务
    def __commit_transaction_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 将任务放入执行队列中
            self.__add_task(data.get('sock_file', None), conn, 'commit', data_type=_TYPE_COMMIT_TRANSACTION, client_socket=client_socket)

            # print('{} add commit_transaction task to queue\n'.format(conn.db_name()), end='')

    # 回滚事务
    def __rollback_transaction_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 将任务放入执行队列中
            self.__add_task(data.get('sock_file', None), conn, 'rollback', data_type=_TYPE_ROLLBACK_TRANSACTION, client_socket=client_socket)

            # print('{} add rollback_transaction task to queue\n'.format(conn.db_name()), end='')

    # 整理数据库空间
    def __vacuum_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 将任务放入执行队列中
            self.__add_task(data.get('sock_file', None), conn, 'vacuum', data_type=_TYPE_VACUUM, client_socket=client_socket)

            # print('{} add vacuum task to queue\n'.format(conn.db_name()), end='')

    # 备份数据库
    def __backup_handler(self, data, client_socket):
        with self.__handler_context(data, client_socket):
            # 获取sqlite服务端连接对象
            conn = self.__get_sqlite_server_connection_by_id(data.get('connection_id', None))

            # 获取目标sqlite服务端连接对象
            try:
                dest_conn = self.__get_sqlite_server_connection_by_id(data.get('dest_connection_id', None))
            except HintException as e:
                raise HintException('dest_connection not found: {}'.format(str(e)))

            # 将任务放入执行队列中
            self.__add_task(data.get('sock_file', None), conn, 'backup', (dest_conn,), data_type=_TYPE_BACKUP, client_socket=client_socket)

            # # 执行数据库备份
            # ret = conn.backup(dest_conn)
            #
            # # 将执行结果发送回客户端
            # if 'sock_file' in data:
            #     self.__send_data(data['sock_file'], {
            #         'type': _TYPE_BACKUP,
            #         'success': True,
            #         'res': ret,
            #     }, client_socket)

    @contextmanager
    def __handler_context(self, data, client_socket):
        '''
            @name 处理函数上下文环境，提供统一的异常处理入口
            @author Zhj<2022-02-13>
            @param data<dict> 数据包
            @param client_socket<ClientSocket> 客户端socket对象
            @return None
        '''
        try:
            yield
        except BaseException as e:
            _log(e)

            # 发送异常信息给客户端
            try:
                if 'sock_file' in data:
                    self.__send_data(data['sock_file'], {
                        'success': False,
                        'res': str(e),
                    }, client_socket)
            except:
                pass


class SqliteClient:
    '''
        sqlite客户端类
        @author Zhj<2022-12-07>
    '''
    __LOCK = threading.Lock()  # 锁
    __INSTANCE_POOL = []  # 实例对象池 id
    __INSTANCES = {}  # 实例对象字典 id => 对象
    __CUR_IDX = 0  # 当前实例下标
    __MAX_INSTANCES = 1  # 最多存储的实例数量
    __READ_SOCKET_SIZE = 1  # 每个实例创建的读socket数量
    __WRITE_SOCKET_SIZE = 1  # 每个实例创建的写socket数量

    # # 构造函数 连接服务端
    # def __init__(self, sock_file=_SOCK_FILE):
    #     # 实例化后不执行初始化操作(单例/多例实现)
    #     return
    #     # self.__init(sock_file)

    # 初始化函数
    def __init(self, read_socket_file: str = _READ_SOCKET_FILE, write_socket_file: str = _WRITE_SOCKET_FILE):
        # 读写socket分离
        # 初始化读操作socket
        # 服务端socket连接地址
        self.__READ_SOCKET_FILE = read_socket_file
        self.__WRITE_SOCKET_FILE = write_socket_file

        # 写操作socket列表
        self.__WRITE_CLIENT_SOCKETS = []
        self.__CUR_WRITE_CLIENT_SOCKET_IDX = 0  # 当前的写socket下标
        self.__UPDATE_CUR_WRITE_CLIENT_SOCKET_IDX_LOCK = threading.Lock()  # 更新当前写socket下标锁

        # 等待100毫秒
        time.sleep(0.1)

        # 创建写socket
        for _ in range(self.__WRITE_SOCKET_SIZE):
            write_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            write_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 5242880)
            write_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 5242880)
            write_socket.connect(self.__WRITE_SOCKET_FILE)
            self.__WRITE_CLIENT_SOCKETS.append(ClientSocket(write_socket))

        # 读操作socket列表
        self.__READ_CLIENT_SOCKETS = []
        self.__CUR_READ_CLIENT_SOCKET_IDX = 0  # 当前的读socket下标
        self.__UPDATE_CUR_READ_CLIENT_SOCKET_IDX_LOCK = threading.Lock()  # 更新当前读socket下标锁

        # 创建读socket
        for _ in range(self.__READ_SOCKET_SIZE):
            read_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            read_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 5242880)
            read_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 5242880)
            read_socket.connect(self.__READ_SOCKET_FILE)
            self.__READ_CLIENT_SOCKETS.append(ClientSocket(read_socket))

        # 等待200毫秒
        time.sleep(0.1)

        self.__RET_RLOCK = threading.RLock()
        self.__RET_CONDITIONS = {}
        self.__RET = {}  # 数据包缓存
        self.__LAST_VACUUM_TIME = 0  # 上一次清理缓存时间
        self.__VACUUM_INTERVAL = 300  # 清理缓存间隔/秒

        self.__RECV_THREAD_RUNNING = True
        self.__RUNNING_THREAD_COUNT = len(self.__READ_CLIENT_SOCKETS) + len(self.__WRITE_CLIENT_SOCKETS)
        self.__UPDATE_RUNNING_THREAD_COUNT_LOCK = threading.Lock()

        # threading.Thread(target=self.__recv_thread, args=(self.__CLIENT_SOCKET,), daemon=True).start()
        self.__THREADS = [threading.Thread(target=self.__recv_thread, args=(read_socket,), daemon=True) for read_socket in self.__READ_CLIENT_SOCKETS]
        self.__THREADS.extend([threading.Thread(target=self.__recv_thread, args=(write_socket,), daemon=True) for write_socket in self.__WRITE_CLIENT_SOCKETS])

        # 启动线程
        [t.start() for t in self.__THREADS]

    # 析构函数
    def __del__(self):
        # print('SqliteClient __del__\n', end='')
        # _log2('SqliteClient __del__')
        # print('[{}]SqliteClient __del__'.format(time.strftime('%Y-%m-%d %X')))

        # 关闭所有数据库连接
        try:
            self.close()
        except:
            pass

        self.__RECV_THREAD_RUNNING = False

    # 重写实例化函数，实现单例/多例复用
    def __new__(cls, *args, **kwargs):
        try:
            with acquire(cls.__LOCK, timeout=15):
                ins_id = cls.__INSTANCE_POOL[cls.__CUR_IDX]
                ins = cls.__INSTANCES[ins_id]
        except IndexError:
            ins = None

        if ins is not None:
            with acquire(cls.__LOCK, timeout=15):
                cls.__CUR_IDX += 1
                cls.__CUR_IDX %= cls.__MAX_INSTANCES
            return ins

        # 加锁
        with acquire(cls.__LOCK, timeout=15):
            try:
                ins_id = cls.__INSTANCE_POOL[cls.__CUR_IDX]
                ins = cls.__INSTANCES[ins_id]
            except IndexError:
                ins = None

            if ins is None:
                # 实例化
                ins = super(SqliteClient, cls).__new__(cls)

                # 初始化
                ins.__init(*args, **kwargs)

                # 放入对象池
                cls.__INSTANCE_POOL.append(id(ins))
                cls.__INSTANCES[id(ins)] = ins

            cls.__CUR_IDX += 1
            cls.__CUR_IDX %= cls.__MAX_INSTANCES

            return ins

        return None

    # 数据接收线程
    def __recv_thread(self, client_socket):
        while self.__RECV_THREAD_RUNNING:
            try:
                result = recv_data(client_socket)

                # 检测到socket断开连接
                if result is None:
                    _log2('client_socket[{}] peer closed.'.format(id(client_socket)))
                    with acquire(self.__UPDATE_RUNNING_THREAD_COUNT_LOCK, timeout=1):
                        self.__RUNNING_THREAD_COUNT -= 1

                        # 当所有连接断开时
                        # 退出线程
                        if self.__RUNNING_THREAD_COUNT <= 0:
                            self.__RECV_THREAD_RUNNING = False
                            self.__remove_self()

                    # 关闭客户端socket
                    try:
                        client_socket.close()
                    except: pass

                    break

                self.__save_result(result)
            except BaseException as e:
                _log2(e)
                del (e,)
            finally:
                result = None
                del (result,)

    # 发送数据
    def __send_data(self, data, recv_response=True):
        '''
            @name 发送数据
            @author Zhj<2022-12-11>
            @param data<dict>           数据
            @param recv_response<>bool  是否接收回包数据
            @return string|int|list|dict|None
        '''
        client_socket = None
        sock_file = None

        if recv_response:
            cur_time = int(time.time())

            # 启动一个接收回包的unix socket
            sock_file = '{}/logs/sqlite_server_{}_{}_{}.sock'.format(_BASE_DIR, id(self), (int(time.time() * 1000 - 1681349558135) << 22) | (uuid.uuid4().int & ((1 << 22) - 1)), cur_time)

            with self.__RET_RLOCK:
                while sock_file in self.__RET:
                    sock_file = '{}/logs/sqlite_server_{}_{}_{}.sock'.format(_BASE_DIR, id(self), (int(time.time() * 1000 - 1681349558135) << 22) | (uuid.uuid4().int & ((1 << 22) - 1)), cur_time)

            # 创建socket对象并指定协议
            # server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            # server_socket.bind(sock_file)
            #
            # # 开始监听
            # server_socket.listen(1)
            #
            # # 记录socket信息，用于对象销毁时自动断开连接
            # with self.__UPDATE_SERVER_SOCKETS_LOCK:
            #     self.__SERVER_SOCKETS[sock_file] = server_socket

            # 附加回包sock地址
            data.update({
                'sock_file': sock_file,
            })

        # 读操作(查询)
        if data['type'] in [_TYPE_QUERY]:
            # client_socket = self.__READ_CLIENT_SOCKET
            with acquire(self.__UPDATE_CUR_READ_CLIENT_SOCKET_IDX_LOCK, timeout=1):
                client_socket = self.__READ_CLIENT_SOCKETS[self.__CUR_READ_CLIENT_SOCKET_IDX]
                self.__CUR_READ_CLIENT_SOCKET_IDX = (self.__CUR_READ_CLIENT_SOCKET_IDX + 1) % self.__READ_SOCKET_SIZE
        # 写操作
        else:
            # client_socket = self.__CLIENT_SOCKET
            with acquire(self.__UPDATE_CUR_WRITE_CLIENT_SOCKET_IDX_LOCK, timeout=1):
                client_socket = self.__WRITE_CLIENT_SOCKETS[self.__CUR_WRITE_CLIENT_SOCKET_IDX]
                self.__CUR_WRITE_CLIENT_SOCKET_IDX = (self.__CUR_WRITE_CLIENT_SOCKET_IDX + 1) % self.__WRITE_SOCKET_SIZE

        # 发送数据
        send_data(client_socket, data)

        # 接收数据
        if recv_response:
            # print('{} sent data {}\n'.format(sock_file, data['type']), end='')
            # _log2('{} sent data {}'.format(sock_file, data['type']))
            self.__RET_CONDITIONS[sock_file] = threading.Condition(self.__RET_RLOCK)
            return self.__recv_data2(sock_file)
            # return self.__recv_data(sock_file, server_socket)

        return None

    # 接收数据(采用临时socket接收，存在性能问题，磁盘IO开销大，有死锁风险)
    def __recv_data(self, sock_file, server_socket):
        if sock_file is None or server_socket is None:
            return None

        client_socket = None

        try:
            # s_time = time.time()
            # print('accepting response socket {}\n'.format(sock_file), end='')

            client_socket, addr = server_socket.accept()

            # cur_time = time.time()
            # print('{} accept consume: {}ms\n'.format(sock_file, int((cur_time - s_time) * 1000)), end='')

            # print('accepted response socket {}\n'.format(sock_file), end='')
            # print('recving data {}\n'.format(sock_file), end='')

            ret = recv_data(ClientSocket(client_socket))

            # print('{} recv consume: {}ms\n'.format(sock_file, int((time.time() - s_time) * 1000)), end='')

            # print('recv data {} {}\n'.format(sock_file, ret), end='')

            ok, err_msg = self.__is_successfully(ret)

            if not ok:
                _log(ret)
                raise Exception(err_msg or '执行失败')

            # if ret['type'] == _TYPE_CONNECT:
            #     _log2('recv {} {}'.format(sock_file, ret['res']))

            return ret['res']
        except BaseException as e:
            _log(e)
            raise
        finally:
            # print('close response socket {}\n'.format(sock_file), end='')
            # 关闭客户端连接
            if client_socket:
                try:
                    client_socket.close()
                except:
                    pass

            try:
                # 关闭服务端连接
                server_socket.close()
                # _log2('[{}]closed server side: {} rest: {}'.format(time.strftime('%Y-%m-%d %X'), sock_file, len(self.__SERVER_SOCKETS.keys())))
            except:
                pass

            # 删除sock文件
            if os.path.exists(sock_file):
                os.remove(sock_file)

            # 删除记录
            with acquire(self.__UPDATE_SERVER_SOCKETS_LOCK):
                if sock_file in self.__SERVER_SOCKETS:
                    self.__SERVER_SOCKETS.pop(sock_file)

    # 接收数据(采用本地缓存接收，性能较好)
    def __recv_data2(self, sock_file):
        return self.__recv_data3(sock_file)

        try:
            # 毫秒
            wait_time = 0
            while self.__RECV_THREAD_RUNNING:
                if sock_file in self.__RET:
                    ok, data = self.__RET[sock_file]

                    if not ok:
                        raise Exception(data or '执行失败')

                    return data

                time.sleep(0.02)
                wait_time += 20

                if wait_time >= 300000:
                    break

            raise Exception('执行失败')
        finally:
            self.__RET.pop(sock_file, None)

    # 接收数据(采用本地缓存接收，性能较好) V3版本采用Condition进行阻塞
    def __recv_data3(self, sock_file):
        try:
            cond = self.__RET_CONDITIONS.get(sock_file, None)

            if cond is None:
                raise Exception('执行失败')

            with cond:
                cond.wait()

            ok, data = self.__RET.get(sock_file, (False, None))

            if not ok:
                raise Exception(data or '执行失败')

            return data
        finally:
            self.__RET.pop(sock_file, None)
            self.__RET_CONDITIONS.pop(sock_file, None)

    # 连接数据库
    def connect(self, db_name, brandnew=False):
        '''
            @name 连接数据库
            @author Zhj<2022-12-13>
            @param db_name<string>  数据库名称(全路径 不包含.db)
            @param brandnew<bool>   是否打开一个全新连接
            @return int|string
        '''
        # 记录请求开始时间
        s_time = time.time()

        # 连接数据库
        try:
            # 获取数据库连接ID
            conn_id = self.__send_data({
                'type': _TYPE_CONNECT,
                'db_name': db_name,
                'brandnew': brandnew,
            })

            if not isinstance(conn_id, str) and not isinstance(conn_id, int):
                _log('recv confused connection_id sqlite_server_{} {}'.format(id(self), conn_id))

            # 返回数据库连接ID
            return conn_id
        except BaseException as e:
            # 记录日志
            _log('{} 连接数据库失败，用时：{}ms'.format(db_name, int((time.time() - s_time) * 1000)))

            _log(e)

            # 抛出异常
            raise

    # 关闭数据库连接或socket连接
    def close(self, conn_id=None, immediate=False):
        '''
            @name 关闭数据库连接或socket连接
            @author Zhj<2022-12-14>
            @param conn_id<int|string|None> 数据库连接ID 为None时表示关闭socket连接
            @param immediate<bool>          是否立即关闭数据库连接
            @return void
        '''
        # conn_id为None时表示关闭socket连接
        if conn_id is None:
            try:
                self.__RECV_THREAD_RUNNING = False

                # 关闭socket连接
                # try:
                #     self.__CLIENT_SOCKET.close()
                # except BaseException as e:
                #     _log2('closed write client socket: {}'.format(e))

                for read_socket in self.__READ_CLIENT_SOCKETS:
                    try:
                        read_socket.close()
                    except BaseException as e:
                        _log2('closed read client socket: {}'.format(e))

                for write_socket in self.__WRITE_CLIENT_SOCKETS:
                    try:
                        write_socket.close()
                    except BaseException as e:
                        _log2('closed write client socket: {}'.format(e))

                # # 关闭读socket
                # try:
                #     self.__READ_CLIENT_SOCKET.close()
                # except:
                #     pass
                #
                # # 关闭写socket
                # try:
                #     self.__WRITE_CLIENT_SOCKET.close()
                # except:
                #     pass
                #
                # # 关闭事务socket
                # try:
                #     self.__TRANSACTION_CLIENT_SOCKET.close()
                # except:
                #     pass
                #
                # try:
                #     # 上锁
                #     with self.__UPDATE_SERVER_SOCKETS_LOCK:
                #         # 关闭所有用于回包的socket
                #         for (sock_file, server_socket) in self.__SERVER_SOCKETS.items():
                #             try:
                #                 # 关闭socket连接
                #                 server_socket.close()
                #             except BaseException as e:
                #                 _log(e)
                #
                #             del (server_socket,)
                #
                #             # 删除sock文件
                #             if os.path.exists(sock_file):
                #                 os.remove(sock_file)
                #
                #             # 清空
                #             self.__SERVER_SOCKETS = {}
                # except:
                #     pass
                #
                # # 关闭连接数据库socket
                # try:
                #     self.__CONNECTION_CLIENT_SOCKET.close()
                # except:
                #     pass

                # 从实例池中移除
                self.__remove_self()

                # print('client socket closed\n', end='')
                # _log2('client socket closed')
            finally:
                # 等待线程退出
                [t.join() for t in self.__THREADS]

            return

        # 关闭数据库连接
        self.__send_data({
            'type': _TYPE_CLOSE,
            'connection_id': conn_id,
            'immediate': immediate,
        }, False)

    # 将自身实例从实例池中移除
    def __remove_self(self):
        with acquire(self.__LOCK, timeout=3):
            try:
                SqliteClient._SqliteClient__INSTANCE_POOL.remove(id(self))
            except ValueError: pass
            SqliteClient._SqliteClient__INSTANCES.pop(id(self), None)

    # 查询
    def query(self, conn_id, sql, params=(), take_first=False):
        '''
            @name 查询
            @author Zhj<2022-12-13>
            @param conn_id<int|string>  连接ID
            @param sql<string>          sql语句
            @param params<tuple|list>   绑定参数
            @param take_first<bool>     是否获取一行数据
            @return dict|list|None
        '''
        return self.__send_data({
            'type': _TYPE_QUERY,
            'connection_id': conn_id,
            'sql': sql,
            'params': params,
            'take_first': take_first,
        })

    # 执行单条SQL语句
    def execute(self, conn_id, sql, params=(), get_rowid=False, recv_response=True):
        '''
            @name 执行单条SQL语句
            @author Zhj<2022-12-13>
            @param conn_id<int|string>  连接ID
            @param sql<string>          sql语句
            @param params<tuple|list>   绑定参数
            @param get_rowid<bool>      是否获取插入ID
            @param recv_response<bool>  是否阻塞获取结果
            @return int
        '''
        return self.__send_data({
            'type': _TYPE_EXECUTE,
            'connection_id': conn_id,
            'sql': sql,
            'params': params,
            'get_rowid': get_rowid,
        }, recv_response)

    # 执行批量写入
    def execute_many(self, conn_id, sql, params=(), recv_response=True):
        '''
            @name 执行批量写入
            @author Zhj<2022-12-13>
            @param conn_id<int|string>  连接ID
            @param sql<string>          sql语句
            @param params<list[tuple]>  绑定参数
            @param recv_response<bool>  是否阻塞获取结果
            @return int
        '''
        return self.__send_data({
            'type': _TYPE_EXECUTE_MANY,
            'connection_id': conn_id,
            'sql': sql,
            'params': params,
        }, recv_response)

    # 执行多条SQL语句
    def execute_script(self, conn_id, sql, recv_response=True):
        '''
            @name 执行多条SQL语句
            @author Zhj<2022-12-13>
            @param conn_id<int|string>  连接ID
            @param sql<string>          sql语句
            @param recv_response<bool>  是否阻塞获取结果
            @return bool
        '''
        return self.__send_data({
            'type': _TYPE_EXECUTE_SCRIPT,
            'connection_id': conn_id,
            'sql': sql,
        }, recv_response)

    # 开启事务
    def start_transaction(self, conn_id, recv_response=True):
        '''
            @name 开启事务
            @author Zhj<2022-12-13>
            @param conn_id<int|string> 连接ID
            @param recv_response<bool>  是否阻塞获取结果
            @return bool
        '''
        return self.__send_data({
            'type': _TYPE_START_TRANSACTION,
            'connection_id': conn_id,
        }, recv_response)

    # 提交事务
    def commit(self, conn_id, recv_response=True):
        '''
            @name 提交事务
            @author Zhj<2022-12-13>
            @param conn_id<int|string> 连接ID
            @param recv_response<bool>  是否阻塞获取结果
            @return bool
        '''
        return self.__send_data({
            'type': _TYPE_COMMIT_TRANSACTION,
            'connection_id': conn_id,
        }, recv_response)

    # 回滚事务
    def rollback(self, conn_id, recv_response=True):
        '''
           @name 回滚事务
           @author Zhj<2022-12-13>
           @param conn_id<int|string> 连接ID
           @param recv_response<bool>  是否阻塞获取结果
           @return bool
        '''
        return self.__send_data({
            'type': _TYPE_ROLLBACK_TRANSACTION,
            'connection_id': conn_id,
        }, recv_response)

    # 整理数据库空间
    def vacuum(self, conn_id, recv_response=True):
        '''
            @name 整理数据库空间
            @author Zhj<2022-12-21>
            @param conn_id<int|string> 连接ID
            @param recv_response<bool>  是否阻塞获取结果
            @return int
        '''
        return self.__send_data({
            'type': _TYPE_VACUUM,
            'connection_id': conn_id,
        }, recv_response)

    # 备份数据库
    def backup(self, conn_id, dest_conn_id, recv_response=True):
        '''
            @name 备份数据库
            @author Zhj<2022-12-22>
            @param conn_id<int|string>      数据库连接ID
            @param dest_conn_id<int|string> 目标数据库连接ID
            @param recv_response<bool>  是否阻塞获取结果
        '''
        return self.__send_data({
            'type': _TYPE_BACKUP,
            'connection_id': conn_id,
            'dest_connection_id': dest_conn_id,
        }, recv_response)

    # 检查请求是否成功
    # __is_successfully() -> dict|None: ret -> tuple: (bool: ok, string: err_msg)
    def __is_successfully(self, ret):
        if ret is None or not isinstance(ret, dict):
            return False, None

        if not ret.get('success', False):
            return False, ret.get('res', None)

        return True, None

    # 暂存数据包
    def __save_result(self, ret):
        if ret is None or not isinstance(ret, dict):
            return

        if 'sock_file' not in ret:
            return

        self.__RET[ret['sock_file']] = (ret.get('success', False), ret.get('res', None))

        cond = self.__RET_CONDITIONS.get(ret['sock_file'], None)

        if cond:
            with cond:
                cond.notify()

        # 每隔一段时间清理无用缓存
        cur_time = int(time.time())

        if cur_time > self.__LAST_VACUUM_TIME + self.__VACUUM_INTERVAL:
            self.__LAST_VACUUM_TIME = cur_time

            ks = list(self.__RET.keys())
            for i in range(len(ks) - 1, -1, -1):
                k = ks[i]
                if int(k[-15:-5]) < cur_time - self.__VACUUM_INTERVAL:
                    self.__RET.pop(k, None)


class SqliteServerConnection:
    '''
        sqlite服务端连接类
        @author Zhj<2022-12-06>
    '''
    __slots__ = [
        '__ID', '__DB_NAME', '__DB_PATH', '__CONN', '__LAST_ACTIVE_TIME',
        '__SQLITE_SERVER', '__EXECUTE_QUEUE', '__LAZY_CONNECT', '__IS_CLOSED', '__STATE_LOCK',
        '__ONCE', '__REF_COUNT', '__UPDATE_REF_COUNT_LOCK', '__DB_CONN_READ'
    ]

    # __MAX_ID = 1
    # __MAX_ID_LOCK = threading.Lock()

    # 构造函数
    def __init__(self, db_name, sqlite_server, connect_immediate=True, once=False):
        # with acquire(self.__MAX_ID_LOCK, timeout=15):
            # SqliteServerConnection._SqliteServerConnection__MAX_ID += 1
        # self.__ID = id(self)   # 生成连接ID
        self.__ID = sqlite_server.gen_connection_id()  # 生成连接ID
        self.__EXECUTE_QUEUE = queue.Queue()  # 执行队列
        self.__DB_NAME = db_name  # 数据库名称(全路径，不包含.db)
        self.__DB_PATH = '{}.db'.format(db_name)  # 数据库绝对路径
        if str(db_name).startswith(':memory:'):
            self.__DB_PATH = ':memory:'
        self.__CONN = None  # sqlite连接对象(写操作)
        self.__LAST_ACTIVE_TIME = int(time.time())  # 最近一次活动时间
        self.__SQLITE_SERVER = weakref.proxy(sqlite_server)  # SqliteServer对象
        self.__LAZY_CONNECT = not connect_immediate  # 是否以懒连接模式打开数据库(表示不需要延迟关闭数据库)
        self.__IS_CLOSED = False  # 连接是否已经关闭
        self.__STATE_LOCK = threading.Lock()  # 更新连接状态锁
        self.__ONCE = once  # 是否一次性连接(不可复用)
        self.__REF_COUNT = 0  # 可复用连接的复用次数(连接次数)
        self.__UPDATE_REF_COUNT_LOCK = threading.Lock()  # 连接复用次数更新锁

        self.__DB_CONN_READ = None  # sqlite连接对象(读操作)

        # 添加到sqlite连接池中
        self.__SQLITE_SERVER.add_connection(self)

        # 立即连接数据库
        if connect_immediate:
            # 连接sqlite数据库
            self.connect()

    # 注册析构函数
    # def __del__(self):
    #     # _log2('SqliteServerConnection {} __del__'.format(self.__ID), 'kkkk.log')
    #     try:
    #         self.close()
    #     except: pass

    def __update_last_update_time(self):
        '''
            @name 更新最近一次活动时间
            @return bool
        '''
        self.__LAST_ACTIVE_TIME = int(time.time())
        return True

    def is_toolong_no_activate(self):
        '''
            @name 检查该连接是否长时间未活动
            @return bool
        '''
        return int(time.time()) - 900 > self.__LAST_ACTIVE_TIME

    # 检查是否一次性连接
    def is_once(self):
        return self.__ONCE

    def is_lazy_connect(self):
        '''
            @name 是否是以懒连接模式打开连接
            @author Zhj<2023-01-10>
            @return bool
        '''
        return self.__LAZY_CONNECT

    # 连接是否关闭
    def is_closed(self):
        return self.__IS_CLOSED

    def id(self):
        '''
            @name 获取连接ID
            @return string
        '''
        # 更新最近一次活动时间
        self.__update_last_update_time()
        return self.__ID

    def db_name(self):
        '''
            @name 获取数据库名称(全路径 不包含.db)
            @return string
        '''
        # 更新最近一次活动时间
        self.__update_last_update_time()
        return self.__DB_NAME

    def conn_obj(self):
        '''
            @name 获取sqlite数据库连接对象<sqlite3.Connection>
            @author Zhj<2022-12-22>
            @return sqlite3.Connection|None
        '''
        return self.__CONN

    def unfinished_task_num(self):
        '''
            @name 获取当前未处理的任务数
            @return int
        '''
        return self.__EXECUTE_QUEUE.qsize()

    def has_unfinished_task(self):
        '''
            @name 检查是否存在未处理完成的任务
            @return bool
        '''
        return self.unfinished_task_num() > 0

    # 获取执行队列
    def get_execute_queue(self):
        return self.__EXECUTE_QUEUE

    def enqueue(self, task):
        '''
            @name 执行队列元素入队
            @author Zhj<2022-12-14>
            @param task<tuple> 任务元组
            @return void
        '''
        self.__EXECUTE_QUEUE.put_nowait(task)

    def dequeue(self, blocking=True, timeout=None):
        '''
            @name 执行队列元素出队
            @author Zhj<2022-12-14>
            @param blocking<bool>   是否阻塞
            @param timeout<?int>    阻塞时最大等待时间/秒
            @return (task<tuple>, in_transaction<bool|None>)
        '''
        # 获取队列元素
        task = self.__EXECUTE_QUEUE.get(blocking, timeout)

        # 当前是否处于事务中
        in_transaction = True

        # 当执行了commit/rollback/close/vacuum/execute_script操作后
        # 标记当前已经不在事务中
        if task.func_name in ['vacuum', 'commit', 'rollback', 'close', 'execute_script']:
            in_transaction = False

        # 执行connect/query/backup操作时
        # 不改变当前事务状态
        if task.func_name in ['connect', 'query', 'backup']:
            in_transaction = None

        return task, in_transaction

    def queue_task_done(self):
        '''
            @name 标记队列任务已完成
            @author Zhj<2022-12-15>
            @return void
        '''
        self.__EXECUTE_QUEUE.task_done()

    # 连接sqlite
    def connect(self):
        # 更新最近一次活动时间
        self.__update_last_update_time()

        if isinstance(self.__CONN, sqlite3.Connection):
            return self.__ID

        with acquire(self.__STATE_LOCK, timeout=15):
            if isinstance(self.__CONN, sqlite3.Connection):
                return self.__ID

            # 连接数据库(写)
            self.__CONN = sqlite3.connect(self.__DB_PATH, timeout=15, check_same_thread=False)
            # self.__CONN.row_factory = _dict_factory
            self.__CONN.text_factory = str
            self.__CONN.isolation_level = 'IMMEDIATE'

            # 连接数据库(读)
            # if not str(self.__DB_PATH).startswith(':memory:') and not str(self.__DB_PATH).startswith('/dev/shm'):
            # if not str(self.__DB_PATH).startswith(':memory:'):
            #     self.__DB_CONN_READ = sqlite3.connect(self.__DB_PATH, timeout=15, check_same_thread=False)
            #     self.__DB_CONN_READ.row_factory = _dict_factory
            #     self.__DB_CONN_READ.text_factory = str
            #     self.__DB_CONN_READ.isolation_level = None
            #     # self.__DB_CONN_READ.isolation_level = 'IMMEDIATE'
            #     self.__DB_CONN_READ.execute('PRAGMA QUERY_ONLY=1')

            self.__IS_CLOSED = False

        # 返回连接ID
        return self.__ID

    # 关闭连接
    def close(self):
        '''
            @name 关闭sqlite连接
            @return bool
        '''
        # 更新最近一次活动时间
        self.__LAST_ACTIVE_TIME = 0

        if self.__IS_CLOSED or self.__CONN is None:
            return True

        with acquire(self.__STATE_LOCK, timeout=15):
            if self.__IS_CLOSED:
                return True

            # 关闭sqlite数据库连接
            if isinstance(self.__CONN, sqlite3.Connection):
                try:
                    self.__CONN.close()
                except BaseException as e:
                    _log(e)

            if isinstance(self.__DB_CONN_READ, sqlite3.Connection):
                try:
                    self.__DB_CONN_READ.close()
                except BaseException as e:
                    _log(e)

            # 取消对sqlite数据库连接对象的引用
            self.__CONN = None
            self.__DB_CONN_READ = None

            self.__IS_CLOSED = True

        # 将连接从连接池中移除
        self.__SQLITE_SERVER.remove_connection(self)
        self.__SQLITE_SERVER = None

        # 处理所有剩余的任务
        try:
            while True:
                # sock_file, _, _, _, data_type, client_socket = self.__EXECUTE_QUEUE.get(False)
                task = self.__EXECUTE_QUEUE.get(False)
                self.__EXECUTE_QUEUE.task_done()
                if task.sock_file:
                    send_data(task.client_socket, {
                        'type': task.data_type,
                        'success': False,
                        'res': 'database connection was closed.',
                    })
        except queue.Empty: pass

        return True

    # 开启事务(sqlite自动开启，无需手动调用)
    def start_transaction(self):
        '''
            @name 开启事务
            @return bool
        '''
        # 更新最近一次活动时间
        self.__update_last_update_time()

        return True

    # 提交事务
    def commit(self):
        '''
            @name 提交事务
            @return bool
        '''
        if isinstance(self.__CONN, sqlite3.Connection) and self.__CONN.in_transaction:
            # 更新最近一次活动时间
            self.__update_last_update_time()

            # 提交事务
            with acquire(self.__STATE_LOCK, timeout=120):
                self.__CONN.commit()

            return True

        return False

    # 回滚事务
    def rollback(self):
        '''
            @name 回滚事务
            @return bool
        '''
        if isinstance(self.__CONN, sqlite3.Connection) and self.__CONN.in_transaction:
            # 更新最近一次活动时间
            self.__update_last_update_time()

            # 回滚事务
            with acquire(self.__STATE_LOCK, timeout=120):
                self.__CONN.rollback()

            return True

        return False

    # 重试辅助函数
    def __sqlite_retry_help(self, fn, *args, **kwargs):
        retries = 25  # 尝试最大次数
        retry_interval = 20  # 每次尝试间隔时间/ms

        while retries > 0:
            try:
                return fn(*args, **kwargs)
            except (SystemError, KeyError, sqlite3.InterfaceError, sqlite3.InternalError, sqlite3.OperationalError) as e:
                # 数据库操作错误，不是锁协议错误，直接抛出异常
                if isinstance(e, sqlite3.OperationalError) and str(e) not in ['locking protocol', 'database is locked']:
                    raise e

                # 最后一次尝试失败后直接raise异常
                if retries == 1:
                    raise e

                # 打印异常信息
                _log(e)
                e = None
                del (e,)

                time.sleep(retry_interval * 0.001)
            finally:
                retries -= 1

    # 查询
    def query(self, sql, params=(), take_first=False):
        '''
            @name 执行查询SQL
            @param sql<string>          sql语句
            @param params<list|tuple>   绑定参数[可选]
            @param take_first<bool>     是否只获取一行数据[可选 默认获取所有行]
            @return list|dict|None
        '''
        s_time = time.time()
        e_time = s_time

        try:
            # 更新最近一次活动时间
            self.__update_last_update_time()
            with acquire(self.__STATE_LOCK, timeout=120):
                ret = self.__sqlite_retry_help(self.__query_help, sql, params, take_first)
                e_time = time.time()
                return ret
        finally:
            # e_time = time.time()

            if e_time - s_time > 1:
                _log2('{}s {}'.format(round(e_time - s_time, 2),
                                      reduce(lambda x, y: search_question_reg.sub(str(y) if _is_number(y) else "'%s'" % y, x, 1), params, sql)), 'sqlite_slow.log')

    # 查询(辅助函数)
    def __query_help(self, sql, params=(), take_first=False):
        with _auto_repair_context(self.__DB_PATH):
            try:
                # 优先使用读数据库连接查询
                if self.__DB_CONN_READ is not None:
                    # 查询
                    cur = self.__DB_CONN_READ.execute(sql, _to_tuple(params))

                    # 获取所有行
                    # ret = cur.fetchall()

                    # 关闭游标
                    # cur.close()

                    ret = _format_cursor(cur)

                    # 获取首行数据
                    if take_first:
                        if len(ret) == 0:
                            return None

                        return ret[0]

                    # 获取所有行
                    return ret

                # 执行SQL
                # 获取游标对象
                cur = self.__CONN.execute(sql, _to_tuple(params))
            except:
                # 打印sql语句与绑定参数
                _log('{}\nbindings: {}\ndb: {}\nconn_id: {}'.format(sql, params, self.db_name(), self.id()))

                cur = None
                del (cur,)

                # 抛出异常
                raise

            try:
                # 获取所有行
                # ret = cur.fetchall()

                # 主动关闭Cursor
                # cur.close()

                s_time = time.time()

                ret = _format_cursor(cur)

                e_time = time.time()

                if e_time - s_time > 1:
                    _log2('{}s format_cursor'.format(round(e_time - s_time, 2)), 'sqlite_slow.log')

                del (cur,)

                # 只获取首行数据
                if take_first:
                    if len(ret) == 0:
                        return None
                    return ret[0]
                    # try:
                    #     return next(ret)
                    # except StopIteration:
                    #     return None

                # return ret
                return list(ret)
            except:
                # 打印sql语句与绑定参数
                _log('{}\nbindings: {}\ndb: {}\nconn_id: {}'.format(sql, params, self.db_name(), self.id()))

                cur = None
                del (cur,)

                raise

    # 执行单条SQL语句
    def execute(self, sql, params=(), get_rowid=False):
        '''
            @name 执行SQL
            @param sql<string>          sql语句
            @param params<tuple|list>   绑定参数
            @param get_rowid<bool>      获取插入ID
            @return int 影响行数或插入ID
        '''
        # 更新最近一次活动时间
        self.__update_last_update_time()
        with acquire(self.__STATE_LOCK, timeout=120):
            return self.__sqlite_retry_help(self.__execute_help, sql, params, get_rowid)

    # 执行单条SQL语句(辅助函数)
    def __execute_help(self, sql, params=(), get_rowid=False):
        with _auto_repair_context(self.__DB_PATH):
            try:
                # 获取游标对象
                cur = self.__CONN.cursor()

                # 执行SQL
                cur.execute(sql, _to_tuple(params))
            except:
                # 打印sql语句与绑定参数
                _log('{}\nbindings: {}\ndb: {}'.format(sql, params, self.db_name()))

                cur = None
                del (cur,)

                # 抛出异常
                raise

            try:
                # 获取新插入数据ID
                if get_rowid:
                    return cur.lastrowid

                # 返回受影响的行数
                return cur.rowcount
            finally:
                # 主动关闭Cursor
                cur.close()

                cur = None
                del (cur,)

    # 执行批量写入
    def execute_many(self, sql, params=()):
        '''
            @name 批量插入
            @param sql<string>          sql语句
            @param params<tuple|list>   绑定参数
            @return int 影响行数
        '''
        # 更新最近一次活动时间
        self.__update_last_update_time()
        with acquire(self.__STATE_LOCK, timeout=120):
            return self.__sqlite_retry_help(self.__execute_many_help, sql, params)

    # 执行批量写入(辅助函数)
    def __execute_many_help(self, sql, params=()):
        with _auto_repair_context(self.__DB_PATH):
            try:
                # 获取游标对象
                cur = self.__CONN.cursor()

                # 执行SQL
                cur.executemany(sql, params)
                # cur = self.__CONN.executemany(sql, list(map(lambda x: _to_tuple(x), params)))
            except:
                # 打印sql语句与绑定参数
                _log('{}\nbindings: {}\ndb: {}'.format(sql, params, self.db_name()))

                cur = None
                del (cur,)

                # 抛出异常
                raise

            rowcount = cur.rowcount

            # 主动关闭Cursor
            cur.close()

            cur = None
            del (cur,)

            return rowcount

    # 执行多条SQL语句
    def execute_script(self, sql):
        '''
            @name 批量执行SQL
            @param sql<string> sql语句集合
            @return bool
        '''
        # 更新最近一次活动时间
        self.__update_last_update_time()
        with acquire(self.__STATE_LOCK, timeout=120):
            return self.__sqlite_retry_help(self.__execute_script_help, sql)

    # 执行多条SQL语句(辅助函数)
    def __execute_script_help(self, sql):
        with _auto_repair_context(self.__DB_PATH):
            try:
                # 获取游标对象
                cur = self.__CONN.cursor()

                # 执行SQL
                cur.executescript(sql)
            except:
                # 打印sql语句与绑定参数
                _log('{}\ndb: {}'.format(sql, self.db_name()))

                cur = None
                del (cur,)

                # 抛出异常
                raise

            # 主动关闭Cursor
            cur.close()

            cur = None
            del (cur,)

            return True

    # 执行vacuum整理数据库空间
    def vacuum(self):
        '''
            @name 执行vaccum整理数据库空间
            @author Zhj<2022-12-22>
            @return int
        '''
        return self.execute('vacuum')

    # 备份数据库
    def backup(self, dest_conn):
        '''
            @name 将当前数据库备份到目标数据库
            @author Zhj<2022-12-22>
            @param dest_conn<SqliteServerConnection> 目标数据库连接对象
            @return bool
        '''
        # if not isinstance(dest_conn, SqliteServerConnection):
        #     raise HintException('dest_conn must a SqliteServerConnection object.')

        if dest_conn.conn_obj() is None:
            raise HintException('dest_conn not connect to sqlite.')

        # 更新最近一次活动时间
        self.__update_last_update_time()

        with _auto_repair_context(self.__DB_PATH):
            # 开始备份(全量备份)
            self.__CONN.backup(dest_conn.conn_obj())

            return True


class ClientSocket:
    '''
        @name 客户端socket包装类
        @author Zhj<2022-12-10>
    '''
    __slots__ = [
        '__SOCKET', '__CONNECTION_IDS', '__UPDATE_CONNECTION_IDS_LOCK',
        '__SENDALL_QUEUE', '__THREAD_RUNNING', '__THREAD_OBJ', '__MESSAGE_CONDITION'
    ]

    def __init__(self, client_socket):
        if not isinstance(client_socket, socket.socket):
            raise RuntimeError('socket_obj must be a socket object.')

        # 消息发送条件锁
        self.__MESSAGE_CONDITION = threading.Condition(threading.RLock())

        # Socket对象
        self.__SOCKET = client_socket

        self.__CONNECTION_IDS = set()  # 数据库连接ID集合
        self.__UPDATE_CONNECTION_IDS_LOCK = threading.Lock()  # 数据库连接ID集合更新锁

        self.__SENDALL_QUEUE = deque()  # sendall队列
        self.__THREAD_RUNNING = True

        # 开启一个线程处理sendall队列
        self.__THREAD_OBJ = threading.Thread(target=self.__thread, daemon=True)
        self.__THREAD_OBJ.start()

    # 消息发送线程
    def __thread(self):
        while self.__THREAD_RUNNING:
            try:
                s_time = time.time()
                data_bytes = self.__SENDALL_QUEUE.popleft()
                data_bytes_size = len(data_bytes)
                if data_bytes_size > 524288:
                    _log2('client-socket-{} send data exceed 512KB. byte size is: {}KB'.format(id(self), round(data_bytes_size / 1024, 2)))
                self.__SOCKET.sendall(data_bytes)
                e_time = time.time()
                if e_time - s_time > 0.1:
                    _log2('client-socket-{} send data cost time: {}ms'.format(id(self), round((e_time - s_time) * 1000, 2)))
            except IndexError:
                # 队列为空，等待
                with self.__MESSAGE_CONDITION:
                    self.__MESSAGE_CONDITION.wait()
            except ConnectionResetError:
                # 当对端socket连接重置时，等待10ms
                time.sleep(0.01)
            except (BrokenPipeError, OSError):
                break
            except BaseException as e:
                _log(e)
                del (e,)
            finally:
                data_bytes = None
                data_bytes_size = None
                s_time = None
                e_time = None
                del (data_bytes, data_bytes_size, s_time, e_time)

    def __del__(self):
        try:
            self.close()
        except: pass

    def accept(self):
        return self.__SOCKET.accept()

    def recv(self, size):
        return self.__SOCKET.recv(size)

    def send(self, data_bytes):
        return self.__SOCKET.send(data_bytes)

    def sendall(self, data_bytes):
        self.__SENDALL_QUEUE.append(data_bytes)

        # 通知消息发送线程可以继续处理消息
        with self.__MESSAGE_CONDITION:
            self.__MESSAGE_CONDITION.notify()

    # 使用多线程发送数据包
    def sendall_multi(self, data_bytes, data_len, chunk_size=51200):
        n = 0
        chunks = int(data_len / chunk_size) + int(data_len % chunk_size > 0)
        chunk_id = (int(time.time() * 1000 - 1681349558135) << 22) | (uuid.uuid4().int & ((1 << 22) - 1))
        self.sendall(_build_send_data(data_bytes[0:51200], {
            'chunk_id': chunk_id,
            'chunks': chunks,
            'n': n,
        }))

        n += 1
        with ThreadPoolExecutor(max_workers=min(chunks - 1, 16)) as t:
            while n < chunks:
                t.submit(self.__sendall_multi_help, data_bytes[chunk_size*n:chunk_size*(n+1)], {
                    'chunk_id': chunk_id,
                    'n': n,
                })
                n += 1

    # 使用短链接发送数据包
    def __sendall_multi_help(self, data_bytes, header_extra=None):
        client_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client_socket.connect(_SOCK_FILE)
        client_socket.sendall(_build_send_data(data_bytes, header_extra))
        client_socket.close()

    def close(self):
        try:
            self.__THREAD_RUNNING = False
            self.__CONNECTION_IDS.clear()
            self.__SENDALL_QUEUE.clear()
            self.__SOCKET.close()
        finally:
            # 通知消息发送线程可以继续处理消息
            with self.__MESSAGE_CONDITION:
                self.__MESSAGE_CONDITION.notify()

            # 等待线程退出
            self.__THREAD_OBJ.join()

    # 添加数据库连接ID
    def add_conn_id(self, conn_id):
        with acquire(self.__UPDATE_CONNECTION_IDS_LOCK, timeout=3):
            self.__CONNECTION_IDS.add(conn_id)

    # 移除数据库连接ID
    def remove_conn_id(self, conn_id):
        with acquire(self.__UPDATE_CONNECTION_IDS_LOCK, timeout=3):
            self.__CONNECTION_IDS.discard(conn_id)

    # 获取数据库连接ID集合
    def get_conn_id_set(self):
        return self.__CONNECTION_IDS

    def print_buf_size(self):
        _log2('client-socket-{} sndbuf: {}'.format(id(self), self.__SOCKET.getsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF)))
        _log2('client-socket-{} rcvbuf: {}'.format(id(self), self.__SOCKET.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)))

        self.__OPT_UPDATE.clear()


class HintException(Exception):
    '''
        @name 提示异常类
        @author Zhj<2022-12-07>
    '''

    def __init__(self, val):
        self.__VALUE = val

    def __str__(self):
        return str(self.__VALUE)


class Where:
    '''
        @name where条件收集类
        @author Zhj<2022-07-16>
    '''
    __slots__ = ['__WHERE_STR', '__BIND_PARAMS']

    def __init__(self):
        self.__WHERE_STR = '1'
        self.__BIND_PARAMS = ()

    # def __del__(self):
    #     self.clear()

    def add(self, condition, bind_params=(), logic='AND'):
        '''
            @name 添加where条件
            @author Zhj<2022-07-16>
            @param  condition<string>       where条件
            @param  bind_params<tuple|list> 绑定参数
            @param  logic<string>           逻辑运算符 AND|OR
            @return self
        '''
        # 当检测condition为字段名且存在参数绑定时，自动添加"=?"
        if match_field_reg.match(condition) and len(_to_tuple(bind_params)) > 0:
            condition = '{} = ?'.format(_add_backtick_for_field(condition))

        where_str = ' {} ({})' if search_logic_opt_reg.search(condition) else ' {} {}'
        self.__WHERE_STR += where_str.format(logic.upper(), str(condition))
        self.__BIND_PARAMS += _to_tuple(bind_params)
        return self

    def add_where_in(self, field, vals, logic='AND', not_in=False):
        '''
            @name 添加where IN查询条件
            @param  field<string>       字段名
            @param  vals<list|tuple>    查询条件
            @param  logic<string>       逻辑运算符 AND|OR
            @param  not_in<bool>        是否为NOT IN
            @return self
        '''
        if isinstance(vals, str) or isinstance(vals, int) or isinstance(vals, float):
            vals = [vals]

        # 空列表
        # (IN)构建where 0
        # (NOT IN)构建where 1
        if len(vals) == 0:
            self.__WHERE_STR += ' {} {}'.format(logic.upper(), 1 if not_in else 0)
            return self

        # 元组转列表
        if isinstance(vals, tuple):
            vals = list(vals)

        # 去重
        vals = list(set(vals))

        # 构造where条件
        tmp = []
        where_params = ()

        # 绑定参数过多时使用字符串拼接
        is_to_more_vals = len(vals) > 300

        if is_to_more_vals:
            for val in vals:
                if _is_number(val):
                    tmp.append(str(val))
                    continue

                tmp.append("'{}'".format(search_quote_reg.sub(r'\\\1', str(val))))
        else:
            for val in vals:
                tmp.append('?')
                where_params += (val,)

        self.__WHERE_STR += ' {} {} {} ({})'.format(
            logic.upper(),
            _add_backtick_for_field(field),
            'IN' if not not_in else 'NOT IN',
            ','.join(tmp)
        )
        self.__BIND_PARAMS += where_params

        return self

    def build(self):
        '''
            @name 获取where条件表达式和绑定参数
            @author Zhj<2022-07-16>
            @return (where条件<string>, 绑定参数<tuple>)
        '''
        where_str = match_where_str_begin_reg.sub('', self.__WHERE_STR)

        if len(where_str) == 0:
            return '', ()

        return ' WHERE {}'.format(where_str), self.__BIND_PARAMS

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-07-16>
            @return self
        '''
        self.__WHERE_STR = '1'
        self.__BIND_PARAMS = ()

        return self


class Limit:
    '''
        @name limit条件收集类
        @author Zhj<2022-07-16>
    '''
    __slots__ = ['__LIMIT', '__SKIP']

    def __init__(self):
        self.__LIMIT = None
        self.__SKIP = None

    # def __del__(self):
    #     self.clear()

    def set_limit(self, limit):
        '''
            @name 设置limit
            @author Zhj<2022-07-16>
            @param  limit<integer>  查询行数
            @return self
        '''
        self.__LIMIT = int(limit)
        return self

    def set_skip(self, skip):
        '''
            @name 设置skip
            @author Zhj<2022-07-16>
            @param  skip<integer> 跳过的行数
            @return self
        '''
        self.__SKIP = int(skip)
        return self

    def build(self):
        '''
            @name 获取limit条件表达式
            @author Zhj<2022-17-16>
            @return string
        '''
        if self.__LIMIT is None:
            return ''

        if self.__SKIP is None:
            return ' LIMIT {}'.format(str(self.__LIMIT))

        return ' LIMIT {},{}'.format(str(self.__SKIP), str(self.__LIMIT))

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-07-16>
            @return self
        '''
        self.__LIMIT = None
        self.__SKIP = None

        return self


class Order:
    '''
        @name order排序条件收集类
        @author ZHj<2022-07-16>
    '''
    __slots__ = ['__ORDERS', '__BIND_PARAMS']

    def __init__(self):
        self.__ORDERS = []
        self.__BIND_PARAMS = ()

    # def __del__(self):
    #     self.clear()

    def add_order(self, field, ordering='ASC', params=()):
        '''
            @name 添加排序条件
            @author Zhj<2022-07-16>
            @param  field<string>       字段名
            @param  ordering<string>    排序方式 ASC|DESC
            @param  params<list|tuple>  绑定参数
            @return self
        '''
        self.__ORDERS.append('{} {}'.format(
            _add_backtick_for_field(field),
            ordering.upper()
        ))
        self.__BIND_PARAMS += _to_tuple(params)
        return self

    def build(self):
        '''
            @name 获取排序条件表达式和绑定参数
            @author Zhj<2022-07-16>
            @return (排序条件表达式<string>, 绑定参数<tuple>)
        '''
        if len(self.__ORDERS) == 0:
            return '', ()

        return ' ORDER BY {}'.format(', '.join(self.__ORDERS)), self.__BIND_PARAMS

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-07-16>
            @return self
        '''
        self.__ORDERS = []
        self.__BIND_PARAMS = ()
        return self


class Field:
    '''
        @name 查询字段收集类
        @author Zhj<2022-07-16>
    '''
    __slots__ = ['__FIELDS']

    def __init__(self):
        self.__FIELDS = []

    # def __del__(self):
    #     self.clear()

    def set_fields(self, *fields):
        '''
            @name 设置查询字段
            @author Zhj<2022-07-17>
            @param  fields<tuple>   查询字段列表
            @return self
        '''
        self.__FIELDS = list(
            map(lambda field: _add_backtick_for_field(field),
                filter(lambda x: x is not None, fields)
                )
        )
        return self

    def add_fields(self, *fields):
        '''
            @name 添加查询字段
            @author Zhj<2022-07-16>
            @param  fields<tuple>   查询字段列表
            @return self
        '''
        self.__FIELDS += list(
            map(lambda field: _add_backtick_for_field(field),
                filter(lambda x: x is not None, fields)
                )
        )
        return self

    def build(self):
        '''
            @name 获取查询字段列表
            @author Zhj<2022-07-16>
            @return string
        '''
        if len(self.__FIELDS) == 0:
            return '*'

        return ', '.join(list(set(self.__FIELDS)))

    def is_empty(self):
        '''
            @name 检查是否为空
            @author Zhj<2022-07-20>
            @return bool
        '''
        return len(self.__FIELDS) == 0

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-07-16>
            @return self
        '''
        self.__FIELDS = []
        return self


class Group:
    '''
        @name 分组条件收集类
        @author Zhj<2022-07-16>
    '''
    __slots__ = ['__GROUPS', '__BIND_PARAMS']

    def __init__(self):
        self.__GROUPS = []
        self.__BIND_PARAMS = ()

    # def __del__(self):
    #     self.clear()

    def add_group(self, condition, params=()):
        '''
            @name 添加分组条件
            @author Zhj<2022-07-16>
            @param  condition<string>   分组条件
            @param  params<list|tuple>  绑定参数
            @return self
        '''
        self.__GROUPS.append(str(condition).strip())
        self.__BIND_PARAMS += _to_tuple(params)
        return self

    def build(self):
        '''
            @name 获取分组条件表达式和绑定参数
            @author Zhj<2022-07-16>
            @return (分组条件表达式<string>, 绑定参数<tuple>)
        '''
        if len(self.__GROUPS) == 0:
            return '', ()

        return ' GROUP BY {}'.format(', '.join(self.__GROUPS)), self.__BIND_PARAMS

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-07-16>
            @return self
        '''
        self.__GROUPS = []
        self.__BIND_PARAMS = ()
        return self


class Having:
    '''
        @name 分组筛选条件收集类
        @author Zhj<2022-07-16>
    '''
    __slots__ = ['__HAVINGS', '__BIND_PARAMS']

    def __init__(self):
        self.__HAVINGS = []
        self.__BIND_PARAMS = ()

    # def __del__(self):
    #     self.clear()

    def add_having(self, condition, params=()):
        '''
            @name 添加分组筛选条件
            @author Zhj<2022-07-16>
            @param  condition<string>   分组筛选条件
            @param  params<list|tuple>  绑定参数
            @return self
        '''
        self.__HAVINGS.append(str(condition).strip())
        self.__BIND_PARAMS += _to_tuple(params)
        return self

    def build(self):
        '''
            @name 获取分组筛选条件表达式和绑定参数
            @author Zhj<2022-07-16>
            @return (分组筛选条件表达式<string>, 绑定参数<tuple>)
        '''
        if len(self.__HAVINGS) == 0:
            return '', ()

        return ' HAVING {}'.format(', '.join(self.__HAVINGS)), self.__BIND_PARAMS

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-07-16>
            @return self
        '''
        self.__HAVINGS = []
        self.__BIND_PARAMS = ()
        return self


class Join:
    '''
        @name 关联条件收集类
        @author Zhj<2022-07-16>
    '''
    __slots__ = ['__JOINS']

    def __init__(self):
        self.__JOINS = []

    # def __del__(self):
    #     self.clear()

    def add_join(self, expression, condition, join_type='INNER', table_prefix=''):
        '''
            @name 添加关联条件
            @author Zhj<2022-07-16>
            @param  expression<string>      表达式
            @param  condition<string>       关联条件
            @param  join_type<string>       关联方式 INNER|LEFT|RIGHT
            @param  table_prefix<string>    表前缀
            @return self
        '''
        m = match_table_name_reg.match(expression)

        if m:
            expression = '{}{}'.format(
                _add_backtick_for_field('{}{}'.format(table_prefix, m.group(1).strip('`'))),
                '' if m.group(2) is None else ' AS {}'.format(_add_backtick_for_field(m.group(2)))
            )

        self.__JOINS.append('{} JOIN {} ON {}'.format(
            join_type.upper(),
            str(expression).strip(),
            str(condition).strip()
        ))
        return self

    def build(self):
        '''
            @name 获取关联条件表达式
            @author Zhj<2022-07-16>
            @return string
        '''
        if len(self.__JOINS) == 0:
            return ''

        return ' ' + ' '.join(self.__JOINS)

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-07-16>
            @return self
        '''
        self.__JOINS = []
        return self


class Update:
    '''
        @name Update条件
        @author Zhj<2022-07017>
    '''
    __slots__ = ['__UPDATES', '__BIND_PARAMS']

    def __init__(self):
        self.__UPDATES = []
        self.__BIND_PARAMS = ()

    # def __del__(self):
    #     self.clear()

    def add(self, field, value):
        '''
            @name 添加更新条件
            @author Zhj<2022-07-17>
            @param  field<string>           字段名
            @param  value<integer|string>   值
            @return self
        '''
        self.__UPDATES.append('{} = ?'.format(_add_backtick_for_field(field)))
        self.__BIND_PARAMS += _to_tuple(value)
        return self

    def increment(self, field, step=1):
        '''
            @name 自增
            @author Zhj<2022-07-17>
            @param  field<string>    字段名
            @param  step<integer>    值
            @return self
        '''
        self.__UPDATES.append('{field} = {field} + {step}'.format(
            field=_add_backtick_for_field(field),
            step=str(int(step))
        ))
        return self

    def decrement(self, field, step=1):
        '''
            @name 自减
            @author Zhj<2022-07-17>
            @param  field<string>    字段名
            @param  step<integer>    值
            @return self
        '''
        self.__UPDATES.append('{field} = {field} - {step}'.format(
            field=_add_backtick_for_field(field),
            step=str(int(step))
        ))
        return self

    def exp(self, field, exp):
        '''
            @name 添加原生表达式
            @author Zhj<2022-12-08>
            @param field<string>  字段名
            @param exp<string>    原生表达式
            @return:
        '''
        self.__UPDATES.append('{field} = {exp}'.format(
            field=_add_backtick_for_field(field),
            exp=str(exp)
        ))
        return self

    def build(self):
        '''
            @name 获取更新表达式和绑定参数
            @author Zhj<2022-07-17>
            @return self
        '''
        if self.is_empty():
            return '', ()

        return ', '.join(self.__UPDATES), self.__BIND_PARAMS

    def is_empty(self):
        '''
            @name 检查update条件是否为空
            @author Zhj<2022-07-17>
            @return bool
        '''
        return len(self.__UPDATES) == 0

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-07-17>
            @return self
        '''
        self.__UPDATES = []
        self.__BIND_PARAMS = ()
        return self


class AlterTable:
    __slots__ = ['__weakref__', '__QUERY', '__COLUMNS', '__RENAME_TABLE', '__ALTERS']

    def __init__(self, query):
        if not isinstance(query, SqliteEasy):
            raise RuntimeError('参数query必须是一个SqliteEasy类型')
        self.__QUERY = weakref.proxy(query)
        self.__COLUMNS = []
        self.__RENAME_TABLE = None
        self.__ALTERS = []

    # def __del__(self):
    #     self.clear()
    #     self.__COLUMNS = []
    #     self.__ALTERS = []
    #     self.__QUERY = None

    def rename_table(self, new_table_name):
        '''
            @name 更新表名
            @author Zhj<2022-09-21>
            @param  new_table_name<string> 新表名
            @return self
        '''
        self.__RENAME_TABLE = ' RENAME TO {}'.format(_add_backtick_for_field(new_table_name))
        return self

    def rename_column(self, col_name, new_col_name):
        '''
            @name 更新字段名
            @author Zhj<2022-09-21>
            @param  col_name<string>        当前字段名
            @param  new_col_name<string>    新字段名
            @return self
        '''
        if self.__column_exists(col_name):
            self.__ALTERS.append(' RENAME COLUMN {} TO {}'.format(_add_backtick_for_field(col_name), _add_backtick_for_field(new_col_name)))
            self.__COLUMNS.remove(col_name)
            self.__COLUMNS.append(new_col_name)
        return self

    def add_column(self, col_name, prop, force=False):
        '''
            @name 新增字段
            @author Zhj<2022-09-21>
            @param  col_name<string> 字段名
            @param  prop<string>     字段属性
            @param  force<?bool>     是否强制新增(删除旧的字段)[可选]
            @return self
        '''
        if force:
            self.drop_column(col_name)

        if not self.__column_exists(col_name):
            self.__ALTERS.append(' ADD COLUMN {} {}'.format(_add_backtick_for_field(col_name), prop))
            self.__COLUMNS.append(col_name)

        return self

    def drop_column(self, col_name):
        '''
            @name 删除字段
            @author Zhj<2022-09-21>
            @param  col_name<string> 字段名
            @return self
        '''
        if self.__column_exists(col_name):
            self.__ALTERS.append(' DROP COLUMN {}'.format(_add_backtick_for_field(col_name)))
            self.__COLUMNS.remove(col_name)
        return self

    def __column_exists(self, col_name):
        '''
            @name 检查字段是否已经存在
            @author Zhj<2022-09-21>
            @param  col_name<string> 字段名
            @return bool
        '''
        if len(self.__COLUMNS) == 0:
            self.__COLUMNS = self.__QUERY.get_columns()

        return col_name in self.__COLUMNS

    def build(self, table_name):
        '''
            @name 构建语句
            @author Zhj<2022-09-21>
            @param  table_name<string> 表名
            @return string|None
        '''
        if self.is_empty():
            return None

        ret = "begin;\n"
        ret += "\n".join(list(map(lambda x: 'ALTER TABLE {}{};'.format(table_name, x), self.__ALTERS)))
        ret += "ALTER TABLE {}{};\n".format(table_name,
                                            self.__RENAME_TABLE) if self.__RENAME_TABLE is not None else "\n"
        ret += 'commit;'

        return ret

    def is_empty(self):
        '''
            @name 检查更新条件是否为空
            @author Zhj<2022-09-21>
            @return bool
        '''
        return self.__RENAME_TABLE is None and len(self.__ALTERS) == 0

    def clear(self):
        '''
            @name 清空收集数据
            @author Zhj<2022-09-21>
            @return self
        '''
        self.__ALTERS = []
        return self


class DbConnection:
    '''
        @name Sqlite数据库连接类(相比Db类更加底层)
        @author Zhj<2022-12-13>
    '''
    __slots__ = ['__DB_PATH', '__BLOCKING', '__CLIENT', '__CONN_ID', '__DB_CONN_READ', '__DEBUG_LOG']

    def __init__(self, db_name, brandnew=True):
        '''
            @name 初始化函数
            @author Zhj<2022-12-14>
            @param db_name<string>  数据库名称(全路径 不包含.db)
            @param brandnew<bool>   是否开启一个全新连接
            @return void
        '''
        self.__DB_PATH = '{}.db'.format(db_name)

        if str(db_name).startswith(':memory:'):
           self.__DB_PATH = ':memory:'

        self.__BLOCKING = True  # 是否阻塞模式 默认阻塞
        self.__CLIENT = SqliteClient()

        self.__CONN_ID = None  # 数据库连接ID
        self.__DB_CONN_READ = None  # 读数据库连接

        # 连接数据库
        self.__CONN_ID = self.__CLIENT.connect(db_name, brandnew)

        # if not str(db_name).startswith(':memory:'):
        #     self.__DB_CONN_READ = sqlite3.connect(self.__DB_PATH, timeout=15, check_same_thread=False)
        #     self.__DB_CONN_READ.row_factory = _dict_factory
        #     self.__DB_CONN_READ.text_factory = str
        #     self.__DB_CONN_READ.isolation_level = None
        #     # self.__DB_CONN_READ.isolation_level = 'IMMEDIATE'
        #     self.__DB_CONN_READ.execute('PRAGMA QUERY_ONLY=1')

    # # 析构函数
    # def __del__(self):
    #     try:
    #         # 关闭数据库连接
    #         self.close()
    #     except BaseException as e:
    #         _log(e)

    # 获取数据库连接ID
    def conn_id(self):
        return self.__CONN_ID

    # 设置阻塞模式
    def set_blocking(self, blocking=True):
        self.__BLOCKING = blocking
        return self

    # 查看当前是否是阻塞模式
    def is_blocking(self):
        return self.__BLOCKING

    # 关闭数据库连接
    def close(self, immediate=False):
        '''
            @name 关闭数据库连接
            @author Zhj<2022-12-14>
            @param immediate<bool> 是否立即关闭数据库连接
            @return void
        '''
        if self.__CONN_ID is None:
            return

        self.__CLIENT.close(self.__CONN_ID, immediate)
        self.__CONN_ID = None

        try:
            if self.__DB_CONN_READ is not None:
                self.__DB_CONN_READ.close()
        except: pass

        self.__DB_CONN_READ = None

    # 查询
    def query(self, sql, params=(), take_first=False):
        with _auto_repair_context(self.__DB_PATH):
            if self.__DB_CONN_READ is not None:
                retries = 25  # 尝试最大次数
                retry_interval = 20  # 每次尝试间隔时间/ms

                while retries > 0:
                    try:
                        # 优先使用读数据库连接查询
                        if self.__DB_CONN_READ is not None:
                            # 查询
                            cur = self.__DB_CONN_READ.execute(sql, _to_tuple(params))

                            # 获取所有行
                            ret = cur.fetchall()

                            # 关闭游标
                            cur.close()

                            # 获取首行数据
                            if take_first:
                                if len(ret) == 0:
                                    return None

                                return ret[0]

                            # 获取所有行
                            return ret
                    except (SystemError, KeyError, sqlite3.InterfaceError, sqlite3.InternalError, sqlite3.OperationalError) as e:
                        # 打印sql语句与绑定参数
                        _log('{}\nbindings: {}\ndb: {}\nconn_id: client'.format(sql, params, self.__DB_PATH))

                        # 数据库操作错误，不是锁协议错误，直接抛出异常
                        if isinstance(e, sqlite3.OperationalError) and str(e) not in ['locking protocol', 'database is locked']:
                            raise e

                        # 最后一次尝试失败后直接raise异常
                        if retries == 1:
                            raise e

                        # 打印异常信息
                        _log(e)
                        e = None
                        del (e,)

                        time.sleep(retry_interval * 0.001)
                    finally:
                        retries -= 1

            return self.__CLIENT.query(self.__CONN_ID, sql, params, take_first)

    # 执行一条sql语句
    def execute(self, sql, params, get_rowid=False, blocking=None):
        with _auto_repair_context(self.__DB_PATH):
            if blocking is None:
                blocking = self.__BLOCKING

            # 当指定获取插入ID时，需要阻塞获取结果（此时非阻塞选项失效）
            if get_rowid:
                blocking = True

            return self.__CLIENT.execute(self.__CONN_ID, sql, params, get_rowid, recv_response=blocking)

    # 执行批量写入
    def execute_many(self, sql, params, blocking=None):
        with _auto_repair_context(self.__DB_PATH):
            if blocking is None:
                blocking = self.__BLOCKING
            return self.__CLIENT.execute_many(self.__CONN_ID, sql, params, recv_response=blocking)

    # 执行多条sql语句
    def execute_script(self, sql, blocking=None):
        with _auto_repair_context(self.__DB_PATH):
            if blocking is None:
                blocking = self.__BLOCKING
            return self.__CLIENT.execute_script(self.__CONN_ID, sql, recv_response=blocking)

    # 开启事务
    def start_transaction(self, blocking=None):
        with _auto_repair_context(self.__DB_PATH):
            if blocking is None:
                blocking = self.__BLOCKING
            return self.__CLIENT.start_transaction(self.__CONN_ID, recv_response=blocking)

    # 提交事务
    def commit(self, blocking=None):
        with _auto_repair_context(self.__DB_PATH):
            if blocking is None:
                blocking = self.__BLOCKING
            return self.__CLIENT.commit(self.__CONN_ID, recv_response=blocking)

    # 回滚事务
    def rollback(self, blocking=None):
        with _auto_repair_context(self.__DB_PATH):
            if blocking is None:
                blocking = self.__BLOCKING
            return self.__CLIENT.rollback(self.__CONN_ID, recv_response=blocking)

    # 整理数据库空间
    def vacuum(self, blocking=None):
        with _auto_repair_context(self.__DB_PATH):
            if blocking is None:
                blocking = self.__BLOCKING
            return self.__CLIENT.vacuum(self.__CONN_ID, recv_response=blocking)

    # 备份数据库
    def backup(self, dest_db_connection, blocking=None):
        with _auto_repair_context(self.__DB_PATH):
            if blocking is None:
                blocking = self.__BLOCKING
            return self.__CLIENT.backup(self.__CONN_ID, dest_db_connection.conn_id(), recv_response=blocking)


class Db:
    '''
        @name Sqlite数据库连接类
        @author Zhj<2022-07-18>
    '''
    __slots__ = ['__DB_NAME', '__DB_CONN', '__AUTO_COMMIT', '__AUTO_VACUUM', '__NEED_VACUUM', '__DEBUG_LOG', '__BRANDNEW',
                 '__QUERIES']

    __DB_ROOT_DIR = '{}/data/'.format(_BASE_DIR)

    def __init__(self, db_name, brandnew=True):
        '''
            @name 初始化函数
            @author Zhj<2022-12-14>
            @param db_name<string>  数据库名称
            @param brandnew<bool>   是否开启一个全新连接
            @return void
        '''
        if str(db_name).startswith(':memory:'):
            self.__DB_NAME = db_name  # 内存数据库
        else:
            self.__DB_NAME = os.path.join(self.__DB_ROOT_DIR, re.sub(r'\.db$', '', db_name))  # 数据库名称(全路径 不带.db)
        self.__DB_CONN = None  # 数据库连接对象
        self.__AUTO_COMMIT = True  # 是否自动提交事务(默认自动提交)
        self.__AUTO_VACUUM = False  # 是否自动释放空间
        self.__NEED_VACUUM = False  # 事务提交后是否需要释放空间
        self.__DEBUG_LOG = False  # 是否开启调试日志
        self.__BRANDNEW = brandnew  # 是否开启全新数据库连接
        self.__QUERIES = []  # 查询构造器数量

        self.__connect()

    def __del__(self):
        self.close()
        del (self.__DB_CONN,)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_trackback):
        self.close()

    def __connect(self):
        '''
            @name   连接Sqlite数据库
            @author Zhj<2022-07-16>
            @return self
        '''
        self.__DB_CONN = DbConnection(self.__DB_NAME, self.__BRANDNEW)
        return self

    def close(self):
        '''
            @name 将数据库连接返回连接池
            @author Zhj<2022-07-16>
            @return self
        '''
        try:
            # 释放数据库连接
            if self.__DB_CONN is None:
                return
            self.__DB_CONN.close(self.__BRANDNEW)
            self.__DB_CONN = None
        except BaseException as e:
            _log(e)

    def client(self):
        '''
            @name 获取数据库连接对象
            @return SqliteClient
        '''
        return self.__DB_CONN

    def db_name(self):
        '''
            @name 获取数据库名称
            @author Zhj<2022-09-07>
            @return string
        '''
        return self.__DB_NAME

    def auto_vacuum(self, auto_vacuum=True):
        '''
            @name 设置是否自动释放空间
            @author Zhj<2022-09-27>
            @param  auto_vacuum<?bool> 是否自动释放空间
            @return self
        '''
        self.__AUTO_VACUUM = auto_vacuum
        return self

    def need_vacuum(self, need_vacuum=True):
        '''
            @name 设置是否需要清理空间
            @author Zhj<2022-09-02>
            @param need_vacuum<?bool> 是否需要清理空间
            @return self
        '''
        self.__NEED_VACUUM = need_vacuum
        return self

    def autocommit(self, autocommit=True):
        '''
            @name 设置自动提交事务状态
            @author Zhj<2022-07-17>
            @param  autocommit<bool>    是否自动提交事务
            @return self
        '''
        self.__AUTO_COMMIT = autocommit
        return self

    def is_autocommit(self):
        '''
            @name 是否自动提交事务
            @return bool
        '''
        return self.__AUTO_COMMIT

    def is_autovacuum(self):
        '''
            @name 是否自动释放空间
            @return bool
        '''
        return self.__AUTO_VACUUM

    def commit(self, blocking=None):
        '''
            @name 提交事务
            @author Zhj<2022-07-17>
            @param  blocking<?bool> 是否阻塞执行[可选 默认继承自DB连接对象]
            @return bool
        '''
        if self.__DB_CONN is None:
            return False

        # 记录commit语句执行开始时间
        s_time = time.time()

        # 提交事务
        ret = self.__DB_CONN.commit(blocking=blocking)

        # 写日志
        if self.is_debug():
            self.debug_log('commit', self.db_name(), time.time() - s_time)

        # 开启了自动释放空间时
        # 释放空间
        if self.__NEED_VACUUM and self.is_autovacuum():
            self.__NEED_VACUUM = False
            self.vacuum()

        return ret

    def rollback(self, blocking=None):
        '''
            @name 回滚事务
            @author Zhj<2022-07-17>
            @param  blocking<?bool> 是否阻塞执行[可选 默认继承自DB连接对象]
            @return bool
        '''
        if self.__DB_CONN is None:
            return False

        self.__NEED_VACUUM = False

        # 记录rollback语句执行开始时间
        s_time = time.time()

        ret = self.__DB_CONN.rollback(blocking=blocking)

        # 写日志
        if self.is_debug():
            self.debug_log('rollback', self.db_name(), time.time() - s_time)

        return ret

    def query(self):
        '''
            @name 获取查询构造器对象
            @author Zhj<2022-07-18>
            @return SqliteEasy
        '''
        self.__QUERIES.append(None)
        return SqliteEasy(self)

    def query_done(self):
        '''
            @name 标记查询构造器已关闭
            @author Zhj<2023-02-08>
            @return None
        '''
        del (self.__QUERIES[-1:],)

    def queries(self):
        '''
            @name 查看当前查询构造器数量
            @author Zhj<2023-02-08>
            @return int
        '''
        return len(self.__QUERIES)

    def vacuum(self, blocking=None):
        '''
            @name 释放空间
            @author Zhj<2022-12-22>
            @param  blocking<?bool> 是否阻塞执行[可选 默认继承自DB连接对象]
            @return int
        '''
        # 记录vacuum语句执行开始时间
        s_time = time.time()

        # 执行vacuum
        ret = self.__DB_CONN.vacuum(blocking=blocking)

        # 写日志
        if self.is_debug():
            self.debug_log('vacuum', self.db_name(), time.time() - s_time)

        return ret

    def backup(self, dest_db, blocking=None):
        '''
            @name 备份数据库(>=py3.7)
            @author Zhj<2022-12-22>
            @param  dest_db<Db>     目标数据库连接对象
            @param  blocking<?bool> 是否阻塞执行[可选 默认继承自DB连接对象]
            @return bool
        '''
        if not isinstance(dest_db, Db):
            raise Exception('dest_db must a Db object.')

        # 记录执行备份开始时间
        s_time = time.time()

        # 开始备份
        ret = self.__DB_CONN.backup(dest_db.client(), blocking=blocking)

        # 写日志
        if self.is_debug():
            self.debug_log('backup to {}'.format(dest_db.db_name()), self.db_name(), time.time() - s_time)

        return ret

    def debug(self, debug_state=True):
        '''
            @name 设置调试
            @param debug_state<bool> 调试状态
            @return self
        '''
        self.__DEBUG_LOG = debug_state
        return self

    def is_debug(self):
        '''
            @name 检查当前是否开启了调试日志
            @return bool
        '''
        return self.__DEBUG_LOG

    def debug_log(self, content, db_name, cost_time):
        '''
            @name 写查询日志
            @author Zhj<2022-09-27>
            @param  content<string>     sql语句
            @param  db_name<string>     数据库名称
            @param  cost_time<float>    执行耗时/s
            @return void
        '''
        # 获取当前日期时间
        cur_datetime = time.strftime('%Y-%m-%d %X')

        # sql查询日志目录
        log_dir = '/www/server/bt-monitor/logs/sql_log/{}'.format(time.strftime('%Y%m'))

        # 目录不存在时创建
        if not os.path.exists(log_dir):
            os.makedirs(log_dir, 0o600)

        with open('{}/{}.log'.format(log_dir, cur_datetime[8:10]), 'a') as fp:
            fp.write('[{}]{} {}ms {}\n'.format(cur_datetime, db_name, round(cost_time * 1000, 2), content))

    def synchronous_off(self):
        '''
            @name 关闭同步
            @author Zhj<2023-02-17>
            @return self
        '''
        self.__DB_CONN.execute_script('PRAGMA synchronous=0;')
        return self

    def synchronous_off_wal(self):
        '''
            @name 设置WAL日志模式并关闭同步
            @author Zhj<2023-02-17>
            @return self
        '''
        self.__DB_CONN.execute_script('PRAGMA journal_mode=wal;\nPRAGMA synchronous=0;\nPRAGMA temp_store=memory;\nPRAGMA mmap_size=30000000000;')
        return self

    # 设置阻塞模式
    def set_blocking(self, blocking=True):
        self.__DB_CONN.set_blocking(blocking)
        return self

    # 检查是否设置了阻塞模式
    def is_blocking(self):
        return self.__DB_CONN.is_blocking()

    def integrity_check(self):
        '''
            @name 检查数据库是否完整
            @author Zhj<2023-03-15>
            @return bool
        '''
        try:
            ret = self.__DB_CONN.query('PRAGMA integrity_check', take_first=True)
            return ret['integrity_check'] == 'ok'
        except:
            return False


class SqliteEasy:
    '''
        @name Sqlite查询类
        @author Zhj<2022-07-15>
    '''
    __slots__ = ['__weakref__', '__DB', '__DB_TABLE', '__FETCH_SQL', '__EXPLAIN', '__PK', '__OPT_PREFIX', '__OPT_ALIAS',
                 '__OPT_WHERE', '__OPT_LIMIT', '__OPT_ORDER', '__OPT_FIELD', '__OPT_GROUP', '__OPT_HAVING',
                 '__OPT_JOIN', '__OPT_UPDATE', '__OPT_ALTER_TABLE', '__FROM_SUB_QUERY', '__CONFLICT_OPTIONS']

    def __init__(self, db=None):
        self.__DB = None  # 数据库对象
        self.__DB_TABLE = None  # 表名(包含前缀)
        self.__FETCH_SQL = False  # 是否输出sql语句
        self.__EXPLAIN = False  # 分析sql语句
        self.__PK = None  # 主键字段名
        self.__OPT_PREFIX = 'bt_'  # 表前缀
        self.__OPT_ALIAS = None  # 表别名
        self.__OPT_WHERE = Where()  # where条件
        self.__OPT_LIMIT = Limit()  # limit条件
        self.__OPT_ORDER = Order()  # order条件
        self.__OPT_FIELD = Field()  # field条件
        self.__OPT_GROUP = Group()  # group条件
        self.__OPT_HAVING = Having()  # having条件
        self.__OPT_JOIN = Join()  # 联表条件
        self.__OPT_UPDATE = Update()  # update条件
        self.__OPT_ALTER_TABLE = AlterTable(self)  # 更新表结构条件
        self.__FROM_SUB_QUERY = False  # 是否通过子查询
        self.__CONFLICT_OPTIONS = (
            'ROLLBACK',     # 回滚
            'ABORT',        # 撤销
            'FAIL',         # 抛出失败异常
            'IGNORE',       # 忽略
            'REPLACE',      # 覆盖
        )  # 发生约束冲突时，额外的处理选项

        if db is not None:
            self.__DB = db

    def __del__(self):
        self.close()

        self.__OPT_WHERE = None
        self.__OPT_LIMIT = None
        self.__OPT_ORDER = None
        self.__OPT_FIELD = None
        self.__OPT_GROUP = None
        self.__OPT_HAVING = None
        self.__OPT_JOIN = None
        self.__OPT_UPDATE = None
        self.__OPT_ALTER_TABLE = None

        del (self.__OPT_WHERE,
             self.__OPT_LIMIT,
             self.__OPT_ORDER,
             self.__OPT_FIELD,
             self.__OPT_GROUP,
             self.__OPT_HAVING,
             self.__OPT_JOIN,
             self.__OPT_UPDATE,
             self.__OPT_ALTER_TABLE,)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        self.close()

    def set_db(self, db):
        '''
            @name 设置数据库对象
            @author Zhj<2022-07-18>
            @param  db<Db>  数据库对象
            @return self
        '''
        if not isinstance(db, Db):
            raise Exception('db must a instance of core.include.sqlite_server.Db')

        self.__DB = db
        return self

    def get_db(self):
        '''
            @name 获取数据库对象
            @author Zhj<2022-07-18>
            @return Db|None
        '''
        return self.__DB

    def set_pk(self, pk):
        '''
            @name 设置主键字段名
            @author Zhj<2022-07-19>
            @param  pk<string> 主键字段名
            @return self
        '''
        self.__PK = pk
        return self

    def set_where_obj(self, where_obj):
        '''
            @name 设置Where对象
            @author Zhj<2022-07-19>
            @param  where_obj<Where> Where对象
            @return self
        '''
        if not isinstance(where_obj, Where):
            raise Exception('where_obj must a instance of core.include.sqlite_server.Where')

        self.__OPT_WHERE = where_obj
        return self

    def set_limit_obj(self, limit_obj):
        '''
            @name 设置Limit对象
            @author Zhj<2022-07-19>
            @param  limit_obj<Limit> Limit对象
            @return self
        '''
        if not isinstance(limit_obj, Limit):
            raise Exception('limit_obj must a instance of core.include.sqlite_server.Limit')

        self.__OPT_LIMIT = limit_obj
        return self

    def set_order_obj(self, order_obj):
        '''
            @name 设置Order对象
            @author Zhj<2022-07-19>
            @param  order_obj<Order> Order对象
            @return self
        '''
        if not isinstance(order_obj, Order):
            raise Exception('order_obj must a instance of core.include.sqlite_server.Order')

        self.__OPT_ORDER = order_obj
        return self

    def set_field_obj(self, field_obj):
        '''
            @name 设置Field对象
            @author Zhj<2022-07-19>
            @param  field_obj<Field> Field对象
            @return self
        '''
        if not isinstance(field_obj, Field):
            raise Exception('field_obj must a instance of core.include.sqlite_server.Field')

        self.__OPT_FIELD = field_obj
        return self

    def set_group_obj(self, group_obj):
        '''
            @name 设置Field对象
            @author Zhj<2022-07-19>
            @param  field_obj<Field> Field对象
            @return self
        '''
        if not isinstance(group_obj, Group):
            raise Exception('group_obj must a instance of core.include.sqlite_server.Group')

        self.__OPT_GROUP = group_obj
        return self

    def set_having_obj(self, having_obj):
        '''
            @name 设置Having对象
            @author Zhj<2022-07-19>
            @param  having_obj<Having> Having对象
            @return self
        '''
        if not isinstance(having_obj, Having):
            raise Exception('having_obj must a instance of core.include.sqlite_server.Having')

        self.__OPT_HAVING = having_obj
        return self

    def set_join_obj(self, join_obj):
        '''
            @name 设置Field对象
            @author Zhj<2022-07-19>
            @param  join_obj<Join> Join对象
            @return self
        '''
        if not isinstance(join_obj, Join):
            raise Exception('join_obj must a instance of core.include.sqlite_server.Join')

        self.__OPT_JOIN = join_obj
        return self

    def set_update_obj(self, update_obj):
        '''
            @name 设置Field对象
            @author Zhj<2022-07-19>
            @param  update_obj<Update> Update对象
            @return self
        '''
        if not isinstance(update_obj, Update):
            raise Exception('update_obj must a instance of core.include.sqlite_server.Update')

        self.__OPT_UPDATE = update_obj
        return self

    def close(self):
        '''
            @name 关闭游标并将数据库连接返回连接池
            @author Zhj<2022-07-16>
            @return self
        '''
        try:
            self.__DB.query_done()
            self.__DB = None

            # 清理查询条件
            self.__clear()
        except:
            pass

    def autocommit(self, autocommit=True):
        '''
            @name 设置自动提交事务状态
            @author Zhj<2022-07-17>
            @param  autocommit<bool>    是否自动提交事务
            @return self
        '''
        if self.__DB is not None:
            self.__DB.autocommit(autocommit)

        return self

    def commit(self):
        '''
            @name 提交事务
            @author Zhj<2022-07-17>
            @return bool
        '''
        if self.__DB is None:
            return False

        # 提交事务
        return self.__DB.commit()

    def rollback(self):
        '''
            @name 回滚事务
            @author Zhj<2022-07-17>
            @return bool
        '''
        if self.__DB is None:
            return False

        # 回滚事务
        return self.__DB.rollback()

    def fetch_sql(self, fetch_sql=True):
        '''
            @name 设置是否输入sql原生语句
            @author Zhj<2022-07-18>
            @param  fetch_sql<bool> 是否输入sql原生语句
            @return self
        '''
        self.__FETCH_SQL = fetch_sql
        return self

    def explain(self, explain=True):
        '''
            @name 设置EXPLAIN
            @author Zhj<2022-07-20>
            @param  explain<bool>   是否开启EXPLAIN
            @return self
        '''
        self.__EXPLAIN = explain
        return self

    def prefix(self, prefix):
        '''
            @name 设置表前缀
            @author Zhj<2022-07-16>
            @param  prefix<string> 表前缀
            @return self
        '''
        self.__OPT_PREFIX = prefix
        return self

    def name(self, table_name):
        '''
            @name 设置表名(不包含前缀)
            @author Zhj<2022-07-16>
            @param  table_name<string>  表名(不包含前缀)
            @return self
        '''
        return self.table(table_name, False)

    def table(self, table_name, is_fullname=True):
        '''
            @name 设置表名(包含前缀)
            @param table_name<string>   表名
            @param is_fullname<bool>    是否完整表名(不包含前缀)
            @return self
        '''
        m = match_table_name_reg.match(table_name)

        if m is None or m.group(1) is None:
            raise Exception('无效表名：{}'.format(table_name))

        self.__DB_TABLE = m.group(1).strip('`')

        # 添加前缀
        if not is_fullname and self.__OPT_PREFIX is not None:
            self.__DB_TABLE = self.__OPT_PREFIX + self.__DB_TABLE

        if m.group(2) is not None:
            self.__OPT_ALIAS = m.group(2).strip('`')

        # 重置主键字段名
        self.__PK = None

        return self

    # 使用子查询
    def from_sub_query(self, sub_query):
        m = re.search(r'^(\([\s\S]+?\))(?:(?:\s+AS\s+|\s+)([\w`]+))?$', str(sub_query), flags=re.IGNORECASE)

        if m is None or m.group(1) is None:
            raise Exception('无效的子查询：{}'.format(sub_query))

        self.__DB_TABLE = m.group(1)

        if m.group(2) is not None:
            self.__OPT_ALIAS = m.group(2).strip('`')

        # 重置主键字段名
        self.__PK = None

        self.__FROM_SUB_QUERY = True

        return self

    def alias(self, alias):
        '''
            @name 设置表别名
            @author Zhj<2022-07-16>
            @param  alias<string> 表别名
            @return self
        '''
        self.__OPT_ALIAS = alias
        return self

    def field(self, *fields):
        '''
            @name 添加查询字段
            @author Zhj<2022-07-15>
            @param  fields<tuple>   查询字段列表
            @return self
        '''
        self.__OPT_FIELD.add_fields(*fields)
        return self

    def join(self, exp, condition, join_type='INNER', add_table_prefix=True):
        '''
            @name 添加关联条件
            @author Zhj<2022-07-17>
            @param  exp<string>             表达式
            @param  condition<string>       关联条件
            @param  join_type<string>       关联方式 INNER|LEFT|RIGHT
            @param  add_table_prefix<bool>  是否添加表前缀[可选 默认自动添加]
            @return self
        '''
        table_prefix = ''

        if add_table_prefix and self.__OPT_PREFIX is not None:
            table_prefix = self.__OPT_PREFIX

        self.__OPT_JOIN.add_join(exp, condition, join_type, table_prefix)
        return self

    def inner_join(self, exp, condition, add_table_prefix=True):
        '''
            @name 添加内连接关联条件
            @param  exp<string>          表达式
            @param  condition<string>    关联条件
            @param  add_table_prefix<bool>  是否添加表前缀[可选 默认自动添加]
            @return self
        '''
        return self.join(exp, condition, 'INNER', add_table_prefix)

    def left_join(self, exp, condition, add_table_prefix=True):
        '''
            @name 添加左连接关联条件
            @author Zhj<2022-07-17>
            @param  exp<string>          表达式
            @param  condition<string>    关联条件
            @param  add_table_prefix<bool>  是否添加表前缀[可选 默认自动添加]
            @return self
        '''
        return self.join(exp, condition, 'LEFT', add_table_prefix)

    def right_join(self, exp, condition, add_table_prefix=True):
        '''
            @name 添加右连接关联条件
            @author Zhj<2022-07-17>
            @param  exp<string>          表达式
            @param  condition<string>    关联条件
            @param  add_table_prefix<bool>  是否添加表前缀[可选 默认自动添加]
            @return self
        '''
        return self.join(exp, condition, 'RIGHT', add_table_prefix)

    def where(self, condition, params=()):
        '''
            @name 添加where条件 AND
            @author Zhj<2022-07-16>
            @param  condition<string>   where条件
            @param  params<list|tuple>  绑定参数
            @return self
        '''
        self.__OPT_WHERE.add(condition, params)
        return self

    def where_or(self, condition, params=()):
        '''
            @name 添加where条件 OR
            @author Zhj<2022-07-16>
            @param  condition<string>   where条件
            @param  params<list|tuple>  绑定参数
            @return self
        '''
        self.__OPT_WHERE.add(condition, params, 'OR')
        return self

    def where_in(self, field, vals, logic='AND'):
        '''
            @name 添加where条件 IN
            @author Zhj<2022-07-16>
            @param  field<string>       字段名
            @param  vals<list|tuple>    查询参数列表
            @param  logic<string>       逻辑运算符 AND|OR
            @return self
        '''
        self.__OPT_WHERE.add_where_in(field, vals, logic)
        return self

    def where_not_in(self, field, vals, logic='AND'):
        '''
            @name 添加where条件 IN
            @author Zhj<2022-07-16>
            @param  field<string>       字段名
            @param  vals<list|tuple>    查询参数列表
            @param  logic<string>       逻辑运算符 AND|OR
            @return self
        '''
        self.__OPT_WHERE.add_where_in(field, vals, logic, True)
        return self

    def group(self, condition, params=()):
        '''
            @name 添加分组条件
            @author Zhj<2022-07-17>
            @param  condition<string>   分组条件
            @param  params<list|tuple>  绑定参数
            @return self
        '''
        self.__OPT_GROUP.add_group(condition, params)
        return self

    def having(self, condition, params=()):
        '''
            @name 添加分组筛选条件
            @author Zhj<2022-07-17>
            @param  condition<string>   分组筛选条件
            @param  params<list|tuple>  绑定参数
            @return self
        '''
        self.__OPT_HAVING.add_having(condition, params)
        return self

    def order(self, field, ordering='ASC', params=()):
        '''
            @name 添加排序条件
            @author Zhj<2022-07-17>
            @param  field<string>       字段名
            @param  ordering<string>    排序方式 ASC|DESC
            @param  params<list|tuple>  绑定参数
            @return self
        '''
        self.__OPT_ORDER.add_order(field, ordering, params)
        return self

    def limit(self, limit, skip=None):
        '''
            @name 设置返回行数
            @author Zhj<2022-07-16>
            @param  limit<integer>  返回的行数
            @param  skip<?integer>  跳过的行数
            @return self
        '''
        self.__OPT_LIMIT.set_limit(limit)

        if skip is not None:
            self.__OPT_LIMIT.set_skip(skip)

        return self

    def skip(self, skip):
        '''
            @name 设置跳过的行数
            @author Zhj<2022-07-16>
            @param  skip<integer> 跳过的行数
            @return self
        '''
        self.__OPT_LIMIT.set_skip(skip)
        return self

    def query(self, raw_sql, params=(), take_first=False, clear_conditions=True):
        '''
            @name 查询
            @author Zhj<2022-07-17>
            @param  raw_sql<string>         sql语句
            @param  params<list|tuple>      绑定参数[可选]
            @param  take_first<bool>        是否只获取一行数据[可选 默认获取所有行]
            @param  clear_conditions<?bool> 是否清空查询条件[可选 默认清空]
            @return list|dict|None
        '''
        if self.__DB is None:
            return None

        # 记录语句执行开始时间
        s_time = time.time()

        # 执行sql语句
        ret = self.__DB.client().query(raw_sql, _to_tuple(params), take_first)

        # 写日志
        if self.__DB.is_debug():
            self.__DB.debug_log(self.__to_raw_sql(raw_sql, _to_tuple(params)), self.__DB.db_name(),
                                time.time() - s_time)

        # 自动提交事务
        # if self.__is_autocommit():
        #     self.commit()

        # 清空查询条件
        if clear_conditions:
            self.__clear()

        return ret

    def execute(self, raw_sql, params=(), get_rowid=False, clear_conditions=True, blocking=None):
        '''
            @name 执行一条sql语句并返回影响的行数
            @author Zhj<2022-07-18>
            @param  raw_sql<string>         sql语句
            @param  params<list|tuple>      绑定参数[可选]
            @param  get_rowid<bool>         获取插入ID[可选 默认返回影响的行数]
            @param  clear_conditions<?bool> 是否清空查询条件[可选 默认清空]
            @param  blocking<?bool>         是否阻塞执行[可选 默认继承自DB连接对象]
            @return integer
        '''
        if self.__DB is None:
            return 0

        # 记录语句执行开始时间
        s_time = time.time()

        # 执行sql语句
        ret = self.__DB.client().execute(raw_sql, _to_tuple(params), get_rowid, blocking=blocking)

        # 写日志
        if self.__DB.is_debug():
            self.__DB.debug_log(self.__to_raw_sql(raw_sql, _to_tuple(params)), self.__DB.db_name(),
                                time.time() - s_time)

        # 自动提交事务
        if self.__is_autocommit():
            self.commit()

        # 清空查询条件
        if clear_conditions:
            self.__clear()

        return ret

    def execute_script(self, sql_script, clear_conditions=True, blocking=None):
        '''
            @name 执行多条sql语句(注意：执行这个方法会自动提交之前的事务，本次执行不会加入事务，事务请编写在sql脚本中)
            @author Zhj<2022-07-18>
            @param  sql_script<string>      sql语句
            @param  clear_conditions<?bool> 是否清空查询条件[可选 默认清空]
            @param  blocking<?bool>         是否阻塞执行[可选 默认继承自DB连接对象]
            @return bool
        '''
        if self.__DB is None:
            return False

        # 记录语句执行开始时间
        s_time = time.time()

        # 执行sql语句
        self.__DB.client().execute_script(sql_script, blocking=blocking)

        # 写日志
        if self.__DB.is_debug():
            self.__DB.debug_log(sql_script, self.__DB.db_name(), time.time() - s_time)

        # 清空查询条件
        if clear_conditions:
            self.__clear()

        return True

    def insert(self, data, option=None, get_rowid=True, blocking=None):
        '''
            @name 插入一条数据
            @author Zhj<2022-07-17>
            @param  data<dict|list>     插入数据
            @param  option<?string>     额外选项[可选]
            @param  get_rowid<bool>     获取插入ID[可选 默认返回影响的行数]
            @param  blocking<?bool>     是否阻塞执行[可选 默认继承自DB连接对象]
            @return integer|string
        '''
        if self.__DB_TABLE is None:
            raise Exception('Insert failed: table name not provide.')

        # 传入dict类型之外的情况
        if not isinstance(data, dict):
            # list类型：尝试insert_all
            if isinstance(data, list):
                return self.insert_all(data, option=option)

            # 其它类型：抛出异常提示
            raise Exception('Insert failed: parameter "data" type must be dict.')

        # 检查冲突选项是否正确
        if option is not None and str(option).upper() not in self.__CONFLICT_OPTIONS:
            raise Exception('option must be one of: {}'.format(', '.join(self.__CONFLICT_OPTIONS)))

        placeholders = []
        ks = data.keys()
        params = ()

        for k in ks:
            placeholders.append('?')
            params += (data[k],)

        raw_sql = 'INSERT{} INTO {} ({}) VALUES ({})'.format(
            ' OR {}'.format(str(option).upper()) if option is not None else '',
            _add_backtick_for_field(self.__DB_TABLE),
            ', '.join(list(map(lambda x: _add_backtick_for_field(x), ks))),
            ','.join(placeholders)
        )

        # 输出sql原生语句
        if self.__FETCH_SQL:
            return self.__to_raw_sql(raw_sql, params)

        # 输出SQL语句分析信息
        if self.__EXPLAIN:
            return self.explain_raw_sql(raw_sql, params)

        # 执行sql语句
        return self.execute(raw_sql, params, get_rowid, blocking=blocking)

    def insert_all(self, data_list, clear_conditions=True, option=None, blocking=None):
        '''
            @name 批量插入数据
            @author Zhj<2022-07-17>
            @param  data_list<list>         批量插入数据
            @param  clear_conditions<?bool> 是否清空查询条件[可选 默认清空]
            @param  option<?string>         额外选项[可选]
            @param  blocking<?bool>         是否阻塞执行[可选 默认继承自DB连接对象]
            @return integer
        '''
        if self.__DB is None or len(data_list) == 0:
            return 0

        # 检查冲突选项是否正确
        if option is not None and str(option).upper() not in self.__CONFLICT_OPTIONS:
            raise Exception('option must be one of: {}'.format(', '.join(self.__CONFLICT_OPTIONS)))

        ks = data_list[0].keys()

        # 生成sql语句
        raw_sql = 'INSERT{} INTO {} ({}) VALUES ({})'.format(
            ' OR {}'.format(str(option).upper()) if option is not None else '',
            _add_backtick_for_field(self.__DB_TABLE),
            ', '.join(list(map(lambda x: _add_backtick_for_field(x), ks))),
            ','.join(list(map(lambda x: '?', ks)))
        )

        # 绑定参数
        params = list(map(lambda x: _to_tuple(list(map(lambda y: x[y], ks))), data_list))

        # 记录语句执行开始时间
        s_time = time.time()

        # 执行sql语句
        ret = self.__DB.client().execute_many(raw_sql, params, blocking=blocking)

        # 写日志
        if self.__DB.is_debug():
            # 构造一个真实的批量写入sql
            debug_raw_sql = raw_sql
            i = len(params) - 1
            pad_str = ', ({})'.format(','.join(list(map(lambda x: '?', ks))))

            while i:
                debug_raw_sql += pad_str
                i -= 1

            # 将绑定参数扁平化
            debug_params = ()
            for p in params:
                debug_params += p

            self.__DB.debug_log(self.__to_raw_sql(debug_raw_sql, _to_tuple(debug_params)), self.__DB.db_name(),
                                time.time() - s_time)

        # 自动提交事务
        if self.__is_autocommit():
            self.commit()

        # 清空查询条件
        if clear_conditions:
            self.__clear()

        # 返回新增的行数
        return ret

    def increment(self, field, step=1):
        '''
            @name 自增数值
            @author Zhj<2022-07-17>
            @param  field<string>   字段名
            @param  step<integer>   值
            @return self
        '''
        self.__OPT_UPDATE.increment(field, step)
        return self

    def decrement(self, field, step=1):
        '''
            @name 自减数值
            @author Zhj<2022-07-17>
            @param  field<string>   字段名
            @param  step<integer>   值
            @return self
        '''
        self.__OPT_UPDATE.decrement(field, step)
        return self

    def exp(self, field, exp):
        '''
            @name 使用原生表达式更新
            @param field<string>    字段名
            @param exp<string>      原生表达式
            @return self
        '''
        self.__OPT_UPDATE.exp(field, exp)
        return self

    def update(self, data=None, blocking=None):
        '''
            @name 更新表数据
            @author Zhj<2022-07-17>
            @param  data<?dict>     更新数据
            @param  blocking<?bool> 是否阻塞执行[可选 默认继承自DB连接对象]
            @return integer|string
        '''
        if data is not None:
            # 更新数据不是字典类型 返回0
            if not isinstance(data, dict):
                return 0

            for k, v in data.items():
                self.__OPT_UPDATE.add(k, v)

        # 更新条件为空 返回0
        if self.__OPT_UPDATE.is_empty():
            return 0

        update_str, update_params = self.__OPT_UPDATE.build()
        join_str = self.__OPT_JOIN.build()
        where_str, where_params = self.__OPT_WHERE.build()
        limit_str = self.__OPT_LIMIT.build()

        raw_sql = 'UPDATE {table_name}{join_condition} SET {exprission}' \
                  '{where_condition}{limit_condition}'.format_map({
            'table_name': self.__build_table_name(True),
            'join_condition': join_str,
            'exprission': update_str,
            'where_condition': where_str,
            'limit_condition': limit_str,
        })
        bind_params = update_params + where_params

        # 输出原生sql语句
        if self.__FETCH_SQL:
            return self.__to_raw_sql(raw_sql, bind_params)

        # 输出SQL语句分析信息
        if self.__EXPLAIN:
            return self.explain_raw_sql(raw_sql, bind_params)

        # 执行sql语句
        return self.execute(raw_sql, bind_params, blocking=blocking)

    def delete(self, blocking=None):
        '''
            @name 删除表数据
            @author Zhj<2022-07-17>
            @param  blocking<?bool> 是否阻塞执行[可选 默认继承自DB连接对象]
            @return integer|string
        '''
        join_str = self.__OPT_JOIN.build()
        where_str, where_params = self.__OPT_WHERE.build()
        limit_str = self.__OPT_LIMIT.build()

        raw_sql = 'DELETE FROM {table_name}{join_condition}{where_condition}{limit_condition}'.format(
            table_name=self.__build_table_name(True),
            join_condition=join_str,
            where_condition=where_str,
            limit_condition=limit_str
        )

        # 输出原生sql语句
        if self.__FETCH_SQL:
            return self.__to_raw_sql(raw_sql, where_params)

        # 输出SQL语句分析信息
        if self.__EXPLAIN:
            return self.explain_raw_sql(raw_sql, where_params)

        # 执行sql语句
        ret = self.execute(raw_sql, where_params, blocking=blocking)

        # 自动提交事务时
        # 且开启了自动释放空间时
        # 释放空间
        if self.__is_autocommit() and self.__is_autovacuum():
            self.__DB.vacuum()
        # 否则
        # 记录本次事务提交后需要释放空间
        else:
            self.__DB.need_vacuum()

        return ret

    def find(self):
        '''
            @name 查询一行数据
            @author Zhj<2022-07-17>
            @return dict|None|string
        '''
        self.__OPT_LIMIT.set_limit(1)

        # 构建sql语句和绑定参数
        raw_sql, bind_params = self.__build_sql()

        # 输出原生sql语句
        if self.__FETCH_SQL:
            return self.__to_raw_sql(raw_sql, bind_params)

        # 输出SQL语句分析信息
        if self.__EXPLAIN:
            return self.explain_raw_sql(raw_sql, bind_params)

        return self.query(raw_sql, bind_params, True)

    def select(self):
        '''
            @name 查询多行数据
            @author Zhj<2022-07-17>
            @return list|None|string
        '''
        # 构建sql语句和绑定参数
        raw_sql, bind_params = self.__build_sql()

        # 输出原生sql语句
        if self.__FETCH_SQL:
            return self.__to_raw_sql(raw_sql, bind_params)

        # 输出SQL语句分析信息
        if self.__EXPLAIN:
            return self.explain_raw_sql(raw_sql, bind_params)

        return self.query(raw_sql, bind_params)

    def value(self, field):
        '''
            @name 获取某个字段的值
            @author Zhj<2022-07-17>
            @param  field<string>   字段名
            @return string|integer|None
        '''
        self.__OPT_FIELD.set_fields(field)
        ret = self.find()

        # 输出原生sql语句或SQL语句分析信息
        if self.__FETCH_SQL or self.__EXPLAIN:
            return ret

        if ret is None:
            return None

        return ret.get(self.__get_row_key(field), None)

    def column(self, field, dict_key=None):
        '''
            @name 获取指定字段的值列表或字典
            @author Zhj<2022-07-17>
            @param  field<string|None>   字段名
            @param  dict_key<?string>               字典键(字段名)
            @return list|dict|string
        '''
        if self.__OPT_FIELD.is_empty() and field is not None:
            self.__OPT_FIELD.set_fields(*filter(lambda x: x is not None, [field, dict_key]))

        ret = self.select()

        # 输出原生sql语句或SQL语句分析信息
        if self.__FETCH_SQL or self.__EXPLAIN:
            return ret

        if ret is None:
            # 指定了键时 返回字典
            if dict_key is not None:
                return {}

            return []

        # 返回列表
        if dict_key is None:
            return list(map(lambda x: x.get(self.__get_row_key(field), None), ret))

        # 返回字典
        d = {}
        f_k = None if field is None else self.__get_row_key(field)
        d_k = self.__get_row_key(dict_key)

        for item in ret:
            k = item.get(d_k, None)

            if k is None:
                continue

            d[k] = item if f_k is None else item.get(f_k, None)

        return d

    def count(self):
        '''
            @name 统计行数
            @author Zhj<2022-07-17>
            @return integer
        '''
        ret = self.value('COUNT(*)')

        # 输出原生sql语句或SQL语句分析信息
        if self.__FETCH_SQL or self.__EXPLAIN:
            return ret

        if ret is None:
            ret = 0

        return int(ret)

    def avg(self, field, precsicion=None):
        '''
            @name 统计平均值
            @author Zhj<2022-07-17>
            @param  field<string>       字段名
            @param  precision<?integer> 小数点精度
            @return float
        '''
        field = 'AVG({})'.format(_add_backtick_for_field(field))

        if precsicion is not None and _is_number(precsicion):
            field = 'ROUND({},{})'.format(field, precsicion)

        ret = self.value(field)

        # 输出原生sql语句或SQL语句分析信息
        if self.__FETCH_SQL or self.__EXPLAIN:
            return ret

        if ret is None:
            ret = 0

        return float(ret)

    def sum(self, field, precsicion=None):
        '''
            @name 统计总和
            @author Zhj<2022-07-17>
            @param  field<string>       字段名
            @param  precision<?integer> 小数点精度
            @return integer
        '''
        field = 'SUM({})'.format(_add_backtick_for_field(field))

        if precsicion is not None and _is_number(precsicion):
            field = 'ROUND({},{})'.format(field, precsicion)

        ret = self.value(field)

        # 输出原生sql语句或SQL语句分析信息
        if self.__FETCH_SQL or self.__EXPLAIN:
            return ret

        if ret is None:
            ret = 0

        return int(ret)

    def exists(self):
        '''
            @name 检查数据是否存在
            @author Zhj<2022-07-18>
            @return bool
        '''
        self.__OPT_LIMIT.set_limit(1)

        # 构建sql语句和绑定参数
        raw_sql, bind_params = self.__build_sql()

        k = 'bt__exists'

        raw_sql = 'SELECT EXISTS({}) AS `{}`'.format(raw_sql, k)

        # 输出原生sql语句
        if self.__FETCH_SQL:
            return self.__to_raw_sql(raw_sql, bind_params)

        # 输出SQL语句分析信息
        if self.__EXPLAIN:
            return self.explain_raw_sql(raw_sql, bind_params)

        # 执行sql语句
        ret = self.query(raw_sql, bind_params, True)

        if ret is None or not isinstance(ret, dict):
            return False

        return True if int(ret.get(k, 0)) == 1 else False

    def build_sql(self, sub_query=False):
        '''
            @name 构建sql查询语句(合并绑定参数)
            @author Zhj<2022-07-17>
            @param  sub_query<bool> 是否为子查询
            @return string
        '''
        raw_sql = self.__to_raw_sql(*self.__build_sql())

        # 子查询
        if sub_query:
            raw_sql = '(%s)' % raw_sql

        return raw_sql

    def get_pk(self):
        '''
            @name 获取主键字段名
            @author Zhj<2022-07-18>
            @return string|None
        '''
        ret = self.query('PRAGMA TABLE_INFO({})'.format(self.__build_table_name(False)), take_first=True,
                         clear_conditions=False)

        if ret is None:
            return None

        return ret.get('name', None)

    def get_columns(self):
        '''
            @name 获取所有列名
            @author Zhj<2022-09-21>
            @return list
        '''
        ret = self.query('PRAGMA TABLE_INFO({})'.format(self.__build_table_name(False)), clear_conditions=False)

        return [column['name'] for column in ret]

    def add_column(self, col_name, prop, force=False):
        '''
            @name 新建字段
            @author Zhj<2022-09-21>
            @param  col_name<string> 字段名
            @param  prop<string>     字段属性
            @param  force<?bool>     是否强制新增(删除旧的字段)[可选]
            @return self
        '''
        self.__OPT_ALTER_TABLE.add_column(col_name, prop, force)
        return self

    def drop_column(self, col_name):
        '''
            @name 删除字段
            @author Zhj<2022-09-21>
            @param  col_name<string> 字段名
            @return self
        '''
        self.__OPT_ALTER_TABLE.drop_column(col_name)
        return self

    def rename_column(self, col_name, new_col_name):
        '''
            @name 更新字段名
            @author Zhj<2022-09-21>
            @param  col_name<string>        当前字段名
            @param  new_col_name<string>    新字段名
            @return self
        '''
        self.__OPT_ALTER_TABLE.rename_column(col_name, new_col_name)
        return self

    def alter_table(self):
        '''
            @name 更新表结构
            @author Zhj<2022-09-21>
            @return bool
        '''
        if self.__OPT_ALTER_TABLE.is_empty():
            return False

        raw_sql = self.__OPT_ALTER_TABLE.build(self.__build_table_name(False))

        self.execute_script(raw_sql)

        return True

    def add_index(self, idx_name, idx_col):
        '''
            @name 创建索引
            @author Zhj<2022-10-11>
            @param  idx_name<string>        索引名称
            @param  idx_col<string|list>    字段名称
            @return self
        '''
        if not isinstance(idx_col, list):
            idx_col = [idx_col]

        self.execute('CREATE INDEX IF NOT EXISTS {} ON {} ({})'.format(
            _add_backtick_for_field(idx_name),
            self.__build_table_name(False),
            ','.join(list(map(lambda x: _add_backtick_for_field(x), idx_col)))
        ))

        return self

    def drop_index(self, idx_name):
        '''
            @name 删除索引
            @author Zhj<2022-10-11>
            @param  idx_name<string> 索引名称
            @return self
        '''
        self.execute('DROP INDEX IF EXISTS {} ON {}'.format(
            _add_backtick_for_field(idx_name),
            self.__build_table_name(False)
        ))

        return self

    def fork(self):
        '''
            @name 克隆一个查询构造器
            @author Zhj<2022-07-19>
            @return SqliteEasy|None
        '''
        if self.__DB is None:
            return None

        query = self.__DB.query()
        query.set_pk(self.__PK)
        if self.__FROM_SUB_QUERY:
            query.from_sub_query(self.__DB_TABLE)
        else:
            query.table(self.__DB_TABLE)
        query.prefix(self.__OPT_PREFIX)
        query.alias(self.__OPT_ALIAS)
        query.set_where_obj(copy.deepcopy(self.__OPT_WHERE))
        query.set_limit_obj(copy.deepcopy(self.__OPT_LIMIT))
        query.set_order_obj(copy.deepcopy(self.__OPT_ORDER))
        query.set_field_obj(copy.deepcopy(self.__OPT_FIELD))
        query.set_group_obj(copy.deepcopy(self.__OPT_GROUP))
        query.set_having_obj(copy.deepcopy(self.__OPT_HAVING))
        query.set_join_obj(copy.deepcopy(self.__OPT_JOIN))
        query.set_update_obj(copy.deepcopy(self.__OPT_UPDATE))

        return query

    def explain_raw_sql(self, raw_sql, bind_params=()):
        '''
            @name 分析SQL语句
            @author Zhj<2022-07-21>
            @param  raw_sql<string>         SQL语句
            @param  bind_params<list|tuple> 绑定参数
            @return string|None
        '''
        ret = self.query('EXPLAIN QUERY PLAN {}'.format(raw_sql), _to_tuple(bind_params))

        if ret is None:
            return None

        return "\n".join(list(map(lambda x: x.get('detail', ''), ret)))

    def __to_raw_sql(self, raw_sql, bind_params=()):
        '''
            @name 将sql语句和绑定参数合并
            @author Zhj<2022-07-18>
            @param  raw_sql<string>     sql语句(含有参数绑定占位符)
            @param  bind_params<tuple>  绑定参数
            @return string
        '''
        return reduce(lambda x, y: search_question_reg.sub(str(y) if _is_number(y) else "'%s'" % y, x, 1), bind_params, repr(raw_sql)[1:-1])

    def __build_sql(self):
        '''
            @name 构建sql查询语句与绑定参数
            @author Zhj<2022-07-18>
            @return (sql语句<string>, 绑定参数<tuple>)
        '''
        fields = self.__OPT_FIELD.build()
        join_condition = self.__OPT_JOIN.build()
        where_condition, where_params = self.__OPT_WHERE.build()
        group_condition, group_params = self.__OPT_GROUP.build()
        having_condition, having_params = self.__OPT_HAVING.build()
        order_condition, order_params = self.__OPT_ORDER.build()
        limit_condition = self.__OPT_LIMIT.build()

        # 查询语句
        raw_sql = 'SELECT {fields} FROM {table_name}' \
                  '{join_condition}{where_condition}{group_condition}' \
                  '{order_condition}{having_condition}{limit_condition}'.format_map({
            'fields': fields,
            'table_name': self.__build_table_name(),
            'join_condition': join_condition,
            'where_condition': where_condition,
            'group_condition': group_condition,
            'having_condition': having_condition,
            'order_condition': order_condition,
            'limit_condition': limit_condition,
        })

        # 绑定参数
        bind_params = ()

        bind_params += where_params
        bind_params += group_params
        bind_params += having_params
        bind_params += order_params

        return raw_sql, bind_params

    def __build_table_name(self, contain_alias=True):
        '''
            @name 构建表名
            @author Zhj<2022-07-17>
            @param  contain_alias<bool> 是否包含别名
            @return string
        '''
        table_name = self.__DB_TABLE if self.__FROM_SUB_QUERY else _add_backtick_for_field(self.__DB_TABLE)
        table_alias = ''

        if contain_alias:
            table_alias = '' if self.__OPT_ALIAS is None else ' AS {}'.format(
                _add_backtick_for_field(self.__OPT_ALIAS)
            )

        return '{}{}'.format(table_name, table_alias)

    def __get_row_key(self, field):
        '''
            @name 获取字段名对应的字典键名
            @author Zhj<2022-07-18>
            @param  field<string>   字段名
            @return string|None
        '''
        # 移除字符串两段空白字符
        field = str(field).strip()

        m = match_row_key_reg.match(field)

        # 不符合字段规则
        # 返回None
        if m is None:
            # 检查有无设置别名
            m = search_row_key_reg.search(field)

            # 设置了别名
            if m:
                return m.group(1).strip('`')

            return field

        # 设置了别名时
        # 获取别名
        if m.group(2) is not None:
            return m.group(2).strip('`')

        # 获取字段名 不包含前缀表名
        return m.group(1).strip('`')

    def __is_autocommit(self):
        '''
            @name 检查是否自动提交事务
            @author Zhj<2022-07-18>
            @return bool
        '''
        if self.__DB is None:
            return False

        return self.__DB.is_autocommit()

    def __is_autovacuum(self):
        '''
            @name 检查是否自动释放空间
            @author Zhj<2022-09-27>
            @return bool
        '''
        if self.__DB is None:
            return False

        return self.__DB.is_autovacuum()

    def __clear(self):
        '''
            @name 清空查询条件
            @author Zhj<2022-07-17>
            @return void
        '''
        self.__PK = None
        self.__OPT_ALIAS = None
        self.__OPT_FIELD.clear()
        self.__OPT_JOIN.clear()
        self.__OPT_WHERE.clear()
        self.__OPT_GROUP.clear()
        self.__OPT_HAVING.clear()
        self.__OPT_ORDER.clear()
        self.__OPT_LIMIT.clear()
        self.__OPT_UPDATE.clear()
